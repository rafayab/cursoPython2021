```python
import pandas as pd
```


```python
pwd
```




    'D:\\Curso_Python\\Codigo\\cursoPython2021'




```python
# Se crea el dataframe
# Los datos han sido descargados de https://insights.stackoverflow.com/survey
# Pertenecen a la encuesta anual de desarrolladores año 2021
datos = pd.read_csv('survey_results_public.csv')
```


```python
datos
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ResponseId</th>
      <th>MainBranch</th>
      <th>Employment</th>
      <th>Country</th>
      <th>US_State</th>
      <th>UK_Country</th>
      <th>EdLevel</th>
      <th>Age1stCode</th>
      <th>LearnCode</th>
      <th>YearsCode</th>
      <th>...</th>
      <th>Age</th>
      <th>Gender</th>
      <th>Trans</th>
      <th>Sexuality</th>
      <th>Ethnicity</th>
      <th>Accessibility</th>
      <th>MentalHealth</th>
      <th>SurveyLength</th>
      <th>SurveyEase</th>
      <th>ConvertedCompYearly</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>Slovakia</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Secondary school (e.g. American high school, G...</td>
      <td>18 - 24 years</td>
      <td>Coding Bootcamp;Other online resources (ex: vi...</td>
      <td>NaN</td>
      <td>...</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>62268.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>I am a student who is learning to code</td>
      <td>Student, full-time</td>
      <td>Netherlands</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>7</td>
      <td>...</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>I am not primarily a developer, but I write co...</td>
      <td>Student, full-time</td>
      <td>Russian Federation</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>NaN</td>
      <td>...</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>Austria</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>11 - 17 years</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>I am deaf / hard of hearing</td>
      <td>NaN</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>United Kingdom of Great Britain and Northern I...</td>
      <td>NaN</td>
      <td>England</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>5 - 10 years</td>
      <td>Friend or family member</td>
      <td>17</td>
      <td>...</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>NaN</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>NaN</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>83434</th>
      <td>83435</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>United States of America</td>
      <td>Texas</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>6</td>
      <td>...</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>I have a concentration and/or memory disorder ...</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>160500.0</td>
    </tr>
    <tr>
      <th>83435</th>
      <td>83436</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>Benin</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>4</td>
      <td>...</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Black or of African descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>3960.0</td>
    </tr>
    <tr>
      <th>83436</th>
      <td>83437</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>United States of America</td>
      <td>New Jersey</td>
      <td>NaN</td>
      <td>Secondary school (e.g. American high school, G...</td>
      <td>11 - 17 years</td>
      <td>School</td>
      <td>10</td>
      <td>...</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>NaN</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>90000.0</td>
    </tr>
    <tr>
      <th>83437</th>
      <td>83438</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>Canada</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Online Courses or Certification;Books / Physic...</td>
      <td>5</td>
      <td>...</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>I have a mood or emotional disorder (e.g. depr...</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>816816.0</td>
    </tr>
    <tr>
      <th>83438</th>
      <td>83439</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>Brazil</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Professional degree (JD, MD, etc.)</td>
      <td>11 - 17 years</td>
      <td>School</td>
      <td>14</td>
      <td>...</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Hispanic or Latino/a/x</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>21168.0</td>
    </tr>
  </tbody>
</table>
<p>83439 rows × 48 columns</p>
</div>




```python
datos.shape
```




    (83439, 48)




```python
datos.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 83439 entries, 0 to 83438
    Data columns (total 48 columns):
     #   Column                        Non-Null Count  Dtype  
    ---  ------                        --------------  -----  
     0   ResponseId                    83439 non-null  int64  
     1   MainBranch                    83439 non-null  object 
     2   Employment                    83323 non-null  object 
     3   Country                       83439 non-null  object 
     4   US_State                      14920 non-null  object 
     5   UK_Country                    4418 non-null   object 
     6   EdLevel                       83126 non-null  object 
     7   Age1stCode                    83243 non-null  object 
     8   LearnCode                     82963 non-null  object 
     9   YearsCode                     81641 non-null  object 
     10  YearsCodePro                  61216 non-null  object 
     11  DevType                       66484 non-null  object 
     12  OrgSize                       60726 non-null  object 
     13  Currency                      61080 non-null  object 
     14  CompTotal                     47183 non-null  float64
     15  CompFreq                      52150 non-null  object 
     16  LanguageHaveWorkedWith        82357 non-null  object 
     17  LanguageWantToWorkWith        76821 non-null  object 
     18  DatabaseHaveWorkedWith        69546 non-null  object 
     19  DatabaseWantToWorkWith        58299 non-null  object 
     20  PlatformHaveWorkedWith        52135 non-null  object 
     21  PlatformWantToWorkWith        41619 non-null  object 
     22  WebframeHaveWorkedWith        61707 non-null  object 
     23  WebframeWantToWorkWith        52095 non-null  object 
     24  MiscTechHaveWorkedWith        47055 non-null  object 
     25  MiscTechWantToWorkWith        38021 non-null  object 
     26  ToolsTechHaveWorkedWith       72537 non-null  object 
     27  ToolsTechWantToWorkWith       65480 non-null  object 
     28  NEWCollabToolsHaveWorkedWith  81234 non-null  object 
     29  NEWCollabToolsWantToWorkWith  73022 non-null  object 
     30  OpSys                         83294 non-null  object 
     31  NEWStuck                      83052 non-null  object 
     32  NEWSOSites                    83171 non-null  object 
     33  SOVisitFreq                   82413 non-null  object 
     34  SOAccount                     82525 non-null  object 
     35  SOPartFreq                    67553 non-null  object 
     36  SOComm                        82319 non-null  object 
     37  NEWOtherComms                 82828 non-null  object 
     38  Age                           82407 non-null  object 
     39  Gender                        82286 non-null  object 
     40  Trans                         80678 non-null  object 
     41  Sexuality                     73366 non-null  object 
     42  Ethnicity                     79464 non-null  object 
     43  Accessibility                 77603 non-null  object 
     44  MentalHealth                  76920 non-null  object 
     45  SurveyLength                  81711 non-null  object 
     46  SurveyEase                    81948 non-null  object 
     47  ConvertedCompYearly           46844 non-null  float64
    dtypes: float64(2), int64(1), object(45)
    memory usage: 30.6+ MB
    


```python
# Muestra todas las columnas del fichero
pd.set_option('display.max_columns', 48)
pd.set_option('display.max_rows', 50)
```


```python
# Se crea el schema del dataframe
schema_datos = pd.read_csv('survey_results_schema.csv')
```


```python
datos
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ResponseId</th>
      <th>MainBranch</th>
      <th>Employment</th>
      <th>Country</th>
      <th>US_State</th>
      <th>UK_Country</th>
      <th>EdLevel</th>
      <th>Age1stCode</th>
      <th>LearnCode</th>
      <th>YearsCode</th>
      <th>YearsCodePro</th>
      <th>DevType</th>
      <th>OrgSize</th>
      <th>Currency</th>
      <th>CompTotal</th>
      <th>CompFreq</th>
      <th>LanguageHaveWorkedWith</th>
      <th>LanguageWantToWorkWith</th>
      <th>DatabaseHaveWorkedWith</th>
      <th>DatabaseWantToWorkWith</th>
      <th>PlatformHaveWorkedWith</th>
      <th>PlatformWantToWorkWith</th>
      <th>WebframeHaveWorkedWith</th>
      <th>WebframeWantToWorkWith</th>
      <th>MiscTechHaveWorkedWith</th>
      <th>MiscTechWantToWorkWith</th>
      <th>ToolsTechHaveWorkedWith</th>
      <th>ToolsTechWantToWorkWith</th>
      <th>NEWCollabToolsHaveWorkedWith</th>
      <th>NEWCollabToolsWantToWorkWith</th>
      <th>OpSys</th>
      <th>NEWStuck</th>
      <th>NEWSOSites</th>
      <th>SOVisitFreq</th>
      <th>SOAccount</th>
      <th>SOPartFreq</th>
      <th>SOComm</th>
      <th>NEWOtherComms</th>
      <th>Age</th>
      <th>Gender</th>
      <th>Trans</th>
      <th>Sexuality</th>
      <th>Ethnicity</th>
      <th>Accessibility</th>
      <th>MentalHealth</th>
      <th>SurveyLength</th>
      <th>SurveyEase</th>
      <th>ConvertedCompYearly</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>Slovakia</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Secondary school (e.g. American high school, G...</td>
      <td>18 - 24 years</td>
      <td>Coding Bootcamp;Other online resources (ex: vi...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Developer, mobile</td>
      <td>20 to 99 employees</td>
      <td>EUR European Euro</td>
      <td>4800.0</td>
      <td>Monthly</td>
      <td>C++;HTML/CSS;JavaScript;Objective-C;PHP;Swift</td>
      <td>Swift</td>
      <td>PostgreSQL;SQLite</td>
      <td>SQLite</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Laravel;Symfony</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>PHPStorm;Xcode</td>
      <td>Atom;Xcode</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>Multiple times per day</td>
      <td>Yes</td>
      <td>A few times per month or weekly</td>
      <td>Yes, definitely</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>62268.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>I am a student who is learning to code</td>
      <td>Student, full-time</td>
      <td>Netherlands</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>7</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>JavaScript;Python</td>
      <td>NaN</td>
      <td>PostgreSQL</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Angular;Flask;Vue.js</td>
      <td>NaN</td>
      <td>Cordova</td>
      <td>NaN</td>
      <td>Docker;Git;Yarn</td>
      <td>Git</td>
      <td>Android Studio;IntelliJ;Notepad++;PyCharm</td>
      <td>NaN</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Google it</td>
      <td>Stack Overflow</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>Daily or almost daily</td>
      <td>Yes, definitely</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>I am not primarily a developer, but I write co...</td>
      <td>Student, full-time</td>
      <td>Russian Federation</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Assembly;C;Python;R;Rust</td>
      <td>Julia;Python;Rust</td>
      <td>SQLite</td>
      <td>SQLite</td>
      <td>Heroku</td>
      <td>NaN</td>
      <td>Flask</td>
      <td>Flask</td>
      <td>NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>Keras;NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>IPython/Jupyter;PyCharm;RStudio;Sublime Text;V...</td>
      <td>IPython/Jupyter;RStudio;Sublime Text;Visual St...</td>
      <td>MacOS</td>
      <td>Visit Stack Overflow;Google it;Watch help / tu...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Multiple times per day</td>
      <td>Yes</td>
      <td>Multiple times per day</td>
      <td>Yes, definitely</td>
      <td>Yes</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>Austria</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>11 - 17 years</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Developer, front-end</td>
      <td>100 to 499 employees</td>
      <td>EUR European Euro</td>
      <td>NaN</td>
      <td>Monthly</td>
      <td>JavaScript;TypeScript</td>
      <td>JavaScript;TypeScript</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Angular;jQuery</td>
      <td>Angular;jQuery</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>Daily or almost daily</td>
      <td>Neutral</td>
      <td>No</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>I am deaf / hard of hearing</td>
      <td>NaN</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>United Kingdom of Great Britain and Northern I...</td>
      <td>NaN</td>
      <td>England</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>5 - 10 years</td>
      <td>Friend or family member</td>
      <td>17</td>
      <td>10</td>
      <td>Developer, desktop or enterprise applications;...</td>
      <td>Just me - I am a freelancer, sole proprietor, ...</td>
      <td>GBP\tPound sterling</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bash/Shell;HTML/CSS;Python;SQL</td>
      <td>Bash/Shell;HTML/CSS;Python;SQL</td>
      <td>Elasticsearch;PostgreSQL;Redis</td>
      <td>Cassandra;Elasticsearch;PostgreSQL;Redis</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Flask</td>
      <td>Flask</td>
      <td>Apache Spark;Hadoop;NumPy;Pandas</td>
      <td>Hadoop;NumPy;Pandas</td>
      <td>Docker;Git;Kubernetes;Yarn</td>
      <td>Docker;Git;Kubernetes;Yarn</td>
      <td>Atom;IPython/Jupyter;Notepad++;PyCharm;Vim</td>
      <td>Atom;IPython/Jupyter;Notepad++;PyCharm;Vim;Vis...</td>
      <td>Linux-based</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>A few times per week</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>NaN</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>NaN</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>83434</th>
      <td>83435</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>United States of America</td>
      <td>Texas</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>6</td>
      <td>5</td>
      <td>Developer, back-end</td>
      <td>20 to 99 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>160500.0</td>
      <td>Yearly</td>
      <td>Clojure;Kotlin;SQL</td>
      <td>Clojure</td>
      <td>Oracle;SQLite</td>
      <td>SQLite</td>
      <td>AWS</td>
      <td>AWS</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>Git;Kubernetes</td>
      <td>IntelliJ;Sublime Text;Vim;Visual Studio Code</td>
      <td>Sublime Text;Vim</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Google it</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>No</td>
      <td>NaN</td>
      <td>No, not at all</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>I have a concentration and/or memory disorder ...</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>160500.0</td>
    </tr>
    <tr>
      <th>83435</th>
      <td>83436</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>Benin</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>4</td>
      <td>2</td>
      <td>Developer, full-stack</td>
      <td>Just me - I am a freelancer, sole proprietor, ...</td>
      <td>XOF\tWest African CFA franc</td>
      <td>200000.0</td>
      <td>Monthly</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Firebase;MariaDB;MySQL;PostgreSQL;Redis;SQLite</td>
      <td>Firebase;MariaDB;MongoDB;MySQL;PostgreSQL;Redi...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Django;jQuery;Laravel;React.js;Ruby on Rails</td>
      <td>Django;Express;jQuery;Laravel;React.js;Ruby on...</td>
      <td>Flutter;Qt</td>
      <td>NaN</td>
      <td>Git;Unity 3D;Unreal Engine</td>
      <td>Docker;Git;Kubernetes</td>
      <td>Android Studio;Eclipse;Emacs;IntelliJ;NetBeans...</td>
      <td>Emacs;IntelliJ;PHPStorm;PyCharm;RStudio;Sublim...</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Multiple times per day</td>
      <td>Yes</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Black or of African descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>3960.0</td>
    </tr>
    <tr>
      <th>83436</th>
      <td>83437</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>United States of America</td>
      <td>New Jersey</td>
      <td>NaN</td>
      <td>Secondary school (e.g. American high school, G...</td>
      <td>11 - 17 years</td>
      <td>School</td>
      <td>10</td>
      <td>4</td>
      <td>Data scientist or machine learning specialist;...</td>
      <td>10,000 or more employees</td>
      <td>USD\tUnited States dollar</td>
      <td>1800.0</td>
      <td>Weekly</td>
      <td>Groovy;Java;Python</td>
      <td>Java;Python</td>
      <td>DynamoDB;Elasticsearch;MongoDB;PostgreSQL;Redis</td>
      <td>DynamoDB;Redis</td>
      <td>AWS;Google Cloud Platform</td>
      <td>AWS</td>
      <td>FastAPI;Flask</td>
      <td>FastAPI;Flask</td>
      <td>Hadoop;Keras;NumPy;Pandas</td>
      <td>Apache Spark;Hadoop;Keras;NumPy;Pandas;TensorFlow</td>
      <td>Ansible;Docker;Git;Terraform</td>
      <td>Docker;Git;Kubernetes;Terraform</td>
      <td>Android Studio;Eclipse;IntelliJ;IPython/Jupyte...</td>
      <td>IntelliJ;IPython/Jupyter;Notepad++;Vim</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>Yes</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>No, not really</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>NaN</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>90000.0</td>
    </tr>
    <tr>
      <th>83437</th>
      <td>83438</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>Canada</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Online Courses or Certification;Books / Physic...</td>
      <td>5</td>
      <td>3</td>
      <td>Developer, back-end</td>
      <td>20 to 99 employees</td>
      <td>CAD\tCanadian dollar</td>
      <td>90000.0</td>
      <td>Monthly</td>
      <td>Bash/Shell;JavaScript;Node.js;Python</td>
      <td>Go;Rust</td>
      <td>Cassandra;Elasticsearch;MongoDB;PostgreSQL;Redis</td>
      <td>NaN</td>
      <td>Heroku</td>
      <td>AWS;DigitalOcean</td>
      <td>Django;Express;Flask;React.js</td>
      <td>NaN</td>
      <td>NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>Ansible;Docker;Git;Terraform</td>
      <td>Kubernetes;Terraform</td>
      <td>PyCharm;Sublime Text</td>
      <td>NaN</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>A few times per month or weekly</td>
      <td>Yes</td>
      <td>Less than once per month or monthly</td>
      <td>No, not really</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>I have a mood or emotional disorder (e.g. depr...</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>816816.0</td>
    </tr>
    <tr>
      <th>83438</th>
      <td>83439</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>Brazil</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Professional degree (JD, MD, etc.)</td>
      <td>11 - 17 years</td>
      <td>School</td>
      <td>14</td>
      <td>4</td>
      <td>Developer, front-end;Developer, full-stack;Dev...</td>
      <td>I don’t know</td>
      <td>BRL\tBrazilian real</td>
      <td>7700.0</td>
      <td>Monthly</td>
      <td>Delphi;Elixir;HTML/CSS;Java;JavaScript</td>
      <td>Elixir;HTML/CSS;Java;JavaScript;Node.js;PHP;SQ...</td>
      <td>Oracle;PostgreSQL</td>
      <td>Elasticsearch;MongoDB;MySQL;Oracle;PostgreSQL;...</td>
      <td>Microsoft Azure</td>
      <td>AWS</td>
      <td>Angular;Spring</td>
      <td>Express;Laravel;Spring;Symfony</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>Docker;Git;Kubernetes</td>
      <td>IntelliJ;Visual Studio Code</td>
      <td>IntelliJ;PHPStorm;Visual Studio Code</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange;Stack Overflow f...</td>
      <td>A few times per week</td>
      <td>Yes</td>
      <td>A few times per week</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Hispanic or Latino/a/x</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>21168.0</td>
    </tr>
  </tbody>
</table>
<p>83439 rows × 48 columns</p>
</div>




```python
schema_datos
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>qid</th>
      <th>qname</th>
      <th>question</th>
      <th>force_resp</th>
      <th>type</th>
      <th>selector</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>QID16</td>
      <td>S0</td>
      <td>&lt;div&gt;&lt;span style="font-size:19px;"&gt;&lt;strong&gt;Hel...</td>
      <td>False</td>
      <td>DB</td>
      <td>TB</td>
    </tr>
    <tr>
      <th>1</th>
      <td>QID12</td>
      <td>MetaInfo</td>
      <td>Browser Meta Info</td>
      <td>False</td>
      <td>Meta</td>
      <td>Browser</td>
    </tr>
    <tr>
      <th>2</th>
      <td>QID1</td>
      <td>S1</td>
      <td>&lt;span style="font-size:22px; font-family: aria...</td>
      <td>False</td>
      <td>DB</td>
      <td>TB</td>
    </tr>
    <tr>
      <th>3</th>
      <td>QID2</td>
      <td>MainBranch</td>
      <td>Which of the following options best describes ...</td>
      <td>True</td>
      <td>MC</td>
      <td>SAVR</td>
    </tr>
    <tr>
      <th>4</th>
      <td>QID24</td>
      <td>Employment</td>
      <td>Which of the following best describes your cur...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>5</th>
      <td>QID6</td>
      <td>Country</td>
      <td>Where do you live? &lt;span style="font-weight: b...</td>
      <td>True</td>
      <td>MC</td>
      <td>DL</td>
    </tr>
    <tr>
      <th>6</th>
      <td>QID7</td>
      <td>US_State</td>
      <td>&lt;p&gt;In which state or territory of the USA do y...</td>
      <td>False</td>
      <td>MC</td>
      <td>DL</td>
    </tr>
    <tr>
      <th>7</th>
      <td>QID9</td>
      <td>UK_Country</td>
      <td>In which part of the United Kingdom do you liv...</td>
      <td>False</td>
      <td>MC</td>
      <td>DL</td>
    </tr>
    <tr>
      <th>8</th>
      <td>QID190</td>
      <td>S2</td>
      <td>&lt;span style="font-size:22px; font-family: aria...</td>
      <td>False</td>
      <td>DB</td>
      <td>TB</td>
    </tr>
    <tr>
      <th>9</th>
      <td>QID25</td>
      <td>EdLevel</td>
      <td>Which of the following best describes the high...</td>
      <td>False</td>
      <td>MC</td>
      <td>SAVR</td>
    </tr>
    <tr>
      <th>10</th>
      <td>QID149</td>
      <td>Age1stCode</td>
      <td>At what age did you write your first line of c...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>11</th>
      <td>QID276</td>
      <td>LearnCode</td>
      <td>How did you learn to code? Select all that apply.</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>12</th>
      <td>QID32</td>
      <td>YearsCode</td>
      <td>Including any education, how many years have y...</td>
      <td>False</td>
      <td>MC</td>
      <td>DL</td>
    </tr>
    <tr>
      <th>13</th>
      <td>QID34</td>
      <td>YearsCodePro</td>
      <td>NOT including education, how many years have y...</td>
      <td>False</td>
      <td>MC</td>
      <td>DL</td>
    </tr>
    <tr>
      <th>14</th>
      <td>QID31</td>
      <td>DevType</td>
      <td>Which of the following describes your current ...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>15</th>
      <td>QID29</td>
      <td>OrgSize</td>
      <td>Approximately how many people are employed by ...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>16</th>
      <td>QID50</td>
      <td>Currency</td>
      <td>Which currency do you use day-to-day? If your ...</td>
      <td>True</td>
      <td>MC</td>
      <td>SB</td>
    </tr>
    <tr>
      <th>17</th>
      <td>QID51</td>
      <td>CompTotal</td>
      <td>What is your current total compensation (salar...</td>
      <td>False</td>
      <td>TE</td>
      <td>SL</td>
    </tr>
    <tr>
      <th>18</th>
      <td>QID52</td>
      <td>CompFreq</td>
      <td>Is that compensation weekly, monthly, or yearly?</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>19</th>
      <td>QID61</td>
      <td>S3</td>
      <td>&lt;span style="font-size:22px; font-family: aria...</td>
      <td>False</td>
      <td>DB</td>
      <td>TB</td>
    </tr>
    <tr>
      <th>20</th>
      <td>QID233</td>
      <td>Language</td>
      <td>Which &lt;b&gt;programming, scripting, and markup la...</td>
      <td>False</td>
      <td>Matrix</td>
      <td>Likert</td>
    </tr>
    <tr>
      <th>21</th>
      <td>QID262</td>
      <td>Database</td>
      <td>Which &lt;b&gt;database environments &lt;/b&gt;have you do...</td>
      <td>False</td>
      <td>Matrix</td>
      <td>Likert</td>
    </tr>
    <tr>
      <th>22</th>
      <td>QID263</td>
      <td>Platform</td>
      <td>Which &lt;b&gt;cloud platforms&lt;/b&gt; have you done ext...</td>
      <td>False</td>
      <td>Matrix</td>
      <td>Likert</td>
    </tr>
    <tr>
      <th>23</th>
      <td>QID264</td>
      <td>Webframe</td>
      <td>Which &lt;strong&gt;web frameworks &lt;/strong&gt;&lt;span st...</td>
      <td>False</td>
      <td>Matrix</td>
      <td>Likert</td>
    </tr>
    <tr>
      <th>24</th>
      <td>QID265</td>
      <td>MiscTech</td>
      <td>Which &lt;b&gt;other frameworks and libraries&lt;/b&gt; ha...</td>
      <td>False</td>
      <td>Matrix</td>
      <td>Likert</td>
    </tr>
    <tr>
      <th>25</th>
      <td>QID275</td>
      <td>ToolsTech</td>
      <td>Which &lt;strong&gt;tools&lt;/strong&gt; have you done ext...</td>
      <td>False</td>
      <td>Matrix</td>
      <td>Likert</td>
    </tr>
    <tr>
      <th>26</th>
      <td>QID274</td>
      <td>NEWCollabTools</td>
      <td>Which &lt;strong&gt;development environments&lt;/strong...</td>
      <td>False</td>
      <td>Matrix</td>
      <td>Likert</td>
    </tr>
    <tr>
      <th>27</th>
      <td>QID71</td>
      <td>OpSys</td>
      <td>What is the primary operating system in which ...</td>
      <td>False</td>
      <td>MC</td>
      <td>SAVR</td>
    </tr>
    <tr>
      <th>28</th>
      <td>QID243</td>
      <td>NEWStuck</td>
      <td>What do you do when you get stuck on a problem...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>29</th>
      <td>QID91</td>
      <td>S4</td>
      <td>&lt;span style="font-size:22px; font-family: aria...</td>
      <td>False</td>
      <td>DB</td>
      <td>TB</td>
    </tr>
    <tr>
      <th>30</th>
      <td>QID266</td>
      <td>NEWSOSites</td>
      <td>Which of the following Stack Overflow sites ha...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>31</th>
      <td>QID100</td>
      <td>SOVisitFreq</td>
      <td>How frequently would you say you visit Stack O...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>32</th>
      <td>QID101</td>
      <td>SOAccount</td>
      <td>Do you have a Stack Overflow account?</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>33</th>
      <td>QID102</td>
      <td>SOPartFreq</td>
      <td>How frequently would you say you participate i...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>34</th>
      <td>QID106</td>
      <td>SOComm</td>
      <td>Do you consider yourself a member of the Stack...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>35</th>
      <td>QID267</td>
      <td>NEWOtherComms</td>
      <td>Are you a member of any other online developer...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>36</th>
      <td>QID268</td>
      <td>NEWOtherCommsNames</td>
      <td>Please name up to 5 other online developer com...</td>
      <td>False</td>
      <td>Matrix</td>
      <td>Likert</td>
    </tr>
    <tr>
      <th>37</th>
      <td>QID121</td>
      <td>S5</td>
      <td>&lt;span style="font-size:22px; font-family: aria...</td>
      <td>False</td>
      <td>DB</td>
      <td>TB</td>
    </tr>
    <tr>
      <th>38</th>
      <td>QID127</td>
      <td>Age</td>
      <td>What is your age?</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>39</th>
      <td>QID122</td>
      <td>Gender</td>
      <td>Which of the following describe you, if any? P...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>40</th>
      <td>QID153</td>
      <td>Trans</td>
      <td>Do you identify as transgender?</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>41</th>
      <td>QID136</td>
      <td>Sexuality</td>
      <td>Which of the following describe you, if any? P...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>42</th>
      <td>QID126</td>
      <td>Ethnicity</td>
      <td>Which of the following describe you, if any? P...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>43</th>
      <td>QID124</td>
      <td>Accessibility</td>
      <td>Which of the following describe you, if any? P...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>44</th>
      <td>QID125</td>
      <td>MentalHealth</td>
      <td>Which of the following describe you, if any? P...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>45</th>
      <td>QID131</td>
      <td>S6</td>
      <td>&lt;span style="font-size:22px;"&gt;&lt;strong&gt;Final Qu...</td>
      <td>False</td>
      <td>DB</td>
      <td>TB</td>
    </tr>
    <tr>
      <th>46</th>
      <td>QID132</td>
      <td>SurveyLength</td>
      <td>How do you feel about the length of the survey...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>47</th>
      <td>QID133</td>
      <td>SurveyEase</td>
      <td>How easy or difficult was this survey to compl...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Muestra los 5 primeros registros del dataframe
datos.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ResponseId</th>
      <th>MainBranch</th>
      <th>Employment</th>
      <th>Country</th>
      <th>US_State</th>
      <th>UK_Country</th>
      <th>EdLevel</th>
      <th>Age1stCode</th>
      <th>LearnCode</th>
      <th>YearsCode</th>
      <th>YearsCodePro</th>
      <th>DevType</th>
      <th>OrgSize</th>
      <th>Currency</th>
      <th>CompTotal</th>
      <th>CompFreq</th>
      <th>LanguageHaveWorkedWith</th>
      <th>LanguageWantToWorkWith</th>
      <th>DatabaseHaveWorkedWith</th>
      <th>DatabaseWantToWorkWith</th>
      <th>PlatformHaveWorkedWith</th>
      <th>PlatformWantToWorkWith</th>
      <th>WebframeHaveWorkedWith</th>
      <th>WebframeWantToWorkWith</th>
      <th>MiscTechHaveWorkedWith</th>
      <th>MiscTechWantToWorkWith</th>
      <th>ToolsTechHaveWorkedWith</th>
      <th>ToolsTechWantToWorkWith</th>
      <th>NEWCollabToolsHaveWorkedWith</th>
      <th>NEWCollabToolsWantToWorkWith</th>
      <th>OpSys</th>
      <th>NEWStuck</th>
      <th>NEWSOSites</th>
      <th>SOVisitFreq</th>
      <th>SOAccount</th>
      <th>SOPartFreq</th>
      <th>SOComm</th>
      <th>NEWOtherComms</th>
      <th>Age</th>
      <th>Gender</th>
      <th>Trans</th>
      <th>Sexuality</th>
      <th>Ethnicity</th>
      <th>Accessibility</th>
      <th>MentalHealth</th>
      <th>SurveyLength</th>
      <th>SurveyEase</th>
      <th>ConvertedCompYearly</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>Slovakia</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Secondary school (e.g. American high school, G...</td>
      <td>18 - 24 years</td>
      <td>Coding Bootcamp;Other online resources (ex: vi...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Developer, mobile</td>
      <td>20 to 99 employees</td>
      <td>EUR European Euro</td>
      <td>4800.0</td>
      <td>Monthly</td>
      <td>C++;HTML/CSS;JavaScript;Objective-C;PHP;Swift</td>
      <td>Swift</td>
      <td>PostgreSQL;SQLite</td>
      <td>SQLite</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Laravel;Symfony</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>PHPStorm;Xcode</td>
      <td>Atom;Xcode</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>Multiple times per day</td>
      <td>Yes</td>
      <td>A few times per month or weekly</td>
      <td>Yes, definitely</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>62268.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>I am a student who is learning to code</td>
      <td>Student, full-time</td>
      <td>Netherlands</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>7</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>JavaScript;Python</td>
      <td>NaN</td>
      <td>PostgreSQL</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Angular;Flask;Vue.js</td>
      <td>NaN</td>
      <td>Cordova</td>
      <td>NaN</td>
      <td>Docker;Git;Yarn</td>
      <td>Git</td>
      <td>Android Studio;IntelliJ;Notepad++;PyCharm</td>
      <td>NaN</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Google it</td>
      <td>Stack Overflow</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>Daily or almost daily</td>
      <td>Yes, definitely</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>I am not primarily a developer, but I write co...</td>
      <td>Student, full-time</td>
      <td>Russian Federation</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Assembly;C;Python;R;Rust</td>
      <td>Julia;Python;Rust</td>
      <td>SQLite</td>
      <td>SQLite</td>
      <td>Heroku</td>
      <td>NaN</td>
      <td>Flask</td>
      <td>Flask</td>
      <td>NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>Keras;NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>IPython/Jupyter;PyCharm;RStudio;Sublime Text;V...</td>
      <td>IPython/Jupyter;RStudio;Sublime Text;Visual St...</td>
      <td>MacOS</td>
      <td>Visit Stack Overflow;Google it;Watch help / tu...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Multiple times per day</td>
      <td>Yes</td>
      <td>Multiple times per day</td>
      <td>Yes, definitely</td>
      <td>Yes</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>Austria</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>11 - 17 years</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Developer, front-end</td>
      <td>100 to 499 employees</td>
      <td>EUR European Euro</td>
      <td>NaN</td>
      <td>Monthly</td>
      <td>JavaScript;TypeScript</td>
      <td>JavaScript;TypeScript</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Angular;jQuery</td>
      <td>Angular;jQuery</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>Daily or almost daily</td>
      <td>Neutral</td>
      <td>No</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>I am deaf / hard of hearing</td>
      <td>NaN</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>United Kingdom of Great Britain and Northern I...</td>
      <td>NaN</td>
      <td>England</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>5 - 10 years</td>
      <td>Friend or family member</td>
      <td>17</td>
      <td>10</td>
      <td>Developer, desktop or enterprise applications;...</td>
      <td>Just me - I am a freelancer, sole proprietor, ...</td>
      <td>GBP\tPound sterling</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bash/Shell;HTML/CSS;Python;SQL</td>
      <td>Bash/Shell;HTML/CSS;Python;SQL</td>
      <td>Elasticsearch;PostgreSQL;Redis</td>
      <td>Cassandra;Elasticsearch;PostgreSQL;Redis</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Flask</td>
      <td>Flask</td>
      <td>Apache Spark;Hadoop;NumPy;Pandas</td>
      <td>Hadoop;NumPy;Pandas</td>
      <td>Docker;Git;Kubernetes;Yarn</td>
      <td>Docker;Git;Kubernetes;Yarn</td>
      <td>Atom;IPython/Jupyter;Notepad++;PyCharm;Vim</td>
      <td>Atom;IPython/Jupyter;Notepad++;PyCharm;Vim;Vis...</td>
      <td>Linux-based</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>A few times per week</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>NaN</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>NaN</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Muestra los últimos 10 registros
datos.tail(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ResponseId</th>
      <th>MainBranch</th>
      <th>Employment</th>
      <th>Country</th>
      <th>US_State</th>
      <th>UK_Country</th>
      <th>EdLevel</th>
      <th>Age1stCode</th>
      <th>LearnCode</th>
      <th>YearsCode</th>
      <th>YearsCodePro</th>
      <th>DevType</th>
      <th>OrgSize</th>
      <th>Currency</th>
      <th>CompTotal</th>
      <th>CompFreq</th>
      <th>LanguageHaveWorkedWith</th>
      <th>LanguageWantToWorkWith</th>
      <th>DatabaseHaveWorkedWith</th>
      <th>DatabaseWantToWorkWith</th>
      <th>PlatformHaveWorkedWith</th>
      <th>PlatformWantToWorkWith</th>
      <th>WebframeHaveWorkedWith</th>
      <th>WebframeWantToWorkWith</th>
      <th>MiscTechHaveWorkedWith</th>
      <th>MiscTechWantToWorkWith</th>
      <th>ToolsTechHaveWorkedWith</th>
      <th>ToolsTechWantToWorkWith</th>
      <th>NEWCollabToolsHaveWorkedWith</th>
      <th>NEWCollabToolsWantToWorkWith</th>
      <th>OpSys</th>
      <th>NEWStuck</th>
      <th>NEWSOSites</th>
      <th>SOVisitFreq</th>
      <th>SOAccount</th>
      <th>SOPartFreq</th>
      <th>SOComm</th>
      <th>NEWOtherComms</th>
      <th>Age</th>
      <th>Gender</th>
      <th>Trans</th>
      <th>Sexuality</th>
      <th>Ethnicity</th>
      <th>Accessibility</th>
      <th>MentalHealth</th>
      <th>SurveyLength</th>
      <th>SurveyEase</th>
      <th>ConvertedCompYearly</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>83429</th>
      <td>83430</td>
      <td>I code primarily as a hobby</td>
      <td>Not employed, but looking for work</td>
      <td>United States of America</td>
      <td>Washington</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>18 - 24 years</td>
      <td>Other online resources (ex: videos, blogs, etc)</td>
      <td>6</td>
      <td>NaN</td>
      <td>Other (please specify):;Student</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>HTML/CSS;PHP;PowerShell;Python;SQL;VBA</td>
      <td>C#;Go;HTML/CSS;Java;JavaScript;PHP;Python;SQL;VBA</td>
      <td>MongoDB;MySQL;PostgreSQL</td>
      <td>MariaDB;Microsoft SQL Server;MongoDB;MySQL;Pos...</td>
      <td>Heroku</td>
      <td>AWS;Heroku;IBM Cloud or Watson;Microsoft Azure...</td>
      <td>Django;Flask;jQuery</td>
      <td>Angular.js;ASP.NET;ASP.NET Core ;Django;FastAP...</td>
      <td>NumPy;Pandas</td>
      <td>.NET Framework;.NET Core / .NET 5;NumPy;Pandas</td>
      <td>Git</td>
      <td>Docker;Git;Xamarin</td>
      <td>Atom;Notepad++;Sublime Text;Visual Studio Code</td>
      <td>Atom;Notepad++;Sublime Text;Visual Studio Code</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Google it;Watch help / tu...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per month or weekly</td>
      <td>Not sure/can't remember</td>
      <td>NaN</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man;Or, in your own words:</td>
      <td>Yes</td>
      <td>Queer</td>
      <td>White or of European descent</td>
      <td>I am unable to / find it difficult to walk or ...</td>
      <td>I have an anxiety disorder</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>83430</th>
      <td>83431</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>United States of America</td>
      <td>Illinois</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>23</td>
      <td>21</td>
      <td>Developer, front-end;Developer, full-stack;Dev...</td>
      <td>10 to 19 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>125000.0</td>
      <td>Yearly</td>
      <td>APL;Clojure;LISP;Python;Ruby;SQL;TypeScript</td>
      <td>APL;Clojure;Haskell;LISP;R</td>
      <td>MongoDB;MySQL;PostgreSQL;Redis</td>
      <td>PostgreSQL</td>
      <td>AWS;DigitalOcean;Google Cloud Platform;Heroku</td>
      <td>AWS;DigitalOcean;Google Cloud Platform</td>
      <td>Django;React.js;Ruby on Rails</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>Docker;Git;Kubernetes;Unity 3D</td>
      <td>Emacs;Vim</td>
      <td>Emacs</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>No</td>
      <td>NaN</td>
      <td>No, not really</td>
      <td>No</td>
      <td>45-54 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>125000.0</td>
    </tr>
    <tr>
      <th>83431</th>
      <td>83432</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>Pakistan</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>9</td>
      <td>4</td>
      <td>Developer, mobile;Developer, desktop or enterp...</td>
      <td>2 to 9 employees</td>
      <td>PKR\tPakistani rupee</td>
      <td>150000.0</td>
      <td>Monthly</td>
      <td>C#;Dart;HTML/CSS;Java;JavaScript;Kotlin;Node.j...</td>
      <td>C#;Dart;HTML/CSS;JavaScript;Kotlin;Node.js;Pyt...</td>
      <td>Firebase;MySQL;SQLite</td>
      <td>DynamoDB;Firebase;MongoDB;MySQL;SQLite</td>
      <td>Google Cloud Platform</td>
      <td>AWS;Google Cloud Platform</td>
      <td>Flask;jQuery</td>
      <td>Angular;Django;Flask;jQuery;Laravel</td>
      <td>Flutter</td>
      <td>Flutter;Hadoop;NumPy;TensorFlow;Torch/PyTorch</td>
      <td>Git</td>
      <td>Docker;Git</td>
      <td>Android Studio;IntelliJ;IPython/Jupyter;Notepa...</td>
      <td>Android Studio;IntelliJ;IPython/Jupyter;PyChar...</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Multiple times per day</td>
      <td>Yes</td>
      <td>A few times per month or weekly</td>
      <td>Yes, definitely</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Southeast Asian</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>11676.0</td>
    </tr>
    <tr>
      <th>83432</th>
      <td>83433</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>Canada</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>18 - 24 years</td>
      <td>School</td>
      <td>5</td>
      <td>Less than 1 year</td>
      <td>Developer, back-end</td>
      <td>10,000 or more employees</td>
      <td>CAD\tCanadian dollar</td>
      <td>106000.0</td>
      <td>Yearly</td>
      <td>Ruby</td>
      <td>Java;Ruby;TypeScript</td>
      <td>MySQL;PostgreSQL</td>
      <td>NaN</td>
      <td>Google Cloud Platform;Heroku</td>
      <td>NaN</td>
      <td>Flask;React.js;Ruby on Rails;Vue.js</td>
      <td>NaN</td>
      <td>NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>NaN</td>
      <td>Docker;Git;Kubernetes;Yarn</td>
      <td>NaN</td>
      <td>Atom;IPython/Jupyter;Vim;Visual Studio Code</td>
      <td>NaN</td>
      <td>MacOS</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>No</td>
      <td>NaN</td>
      <td>No, not really</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Woman</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>East Asian</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>80169.0</td>
    </tr>
    <tr>
      <th>83433</th>
      <td>83434</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>Brazil</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>18 - 24 years</td>
      <td>Online Forum;Online Courses or Certification;O...</td>
      <td>15</td>
      <td>11</td>
      <td>Developer, mobile;Developer, front-end;Develop...</td>
      <td>1,000 to 4,999 employees</td>
      <td>BRL\tBrazilian real</td>
      <td>80000.0</td>
      <td>Yearly</td>
      <td>Java;JavaScript;Kotlin;Objective-C;TypeScript</td>
      <td>Kotlin</td>
      <td>Firebase;MongoDB;MySQL;SQLite</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>React.js</td>
      <td>NaN</td>
      <td>React Native</td>
      <td>Flutter</td>
      <td>Docker;Git;Yarn</td>
      <td>Docker;Git</td>
      <td>Android Studio;Visual Studio Code;Xcode</td>
      <td>Android Studio;Xcode</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>A few times per month or weekly</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Hispanic or Latino/a/x</td>
      <td>None of the above</td>
      <td>I have an anxiety disorder</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>18326.0</td>
    </tr>
    <tr>
      <th>83434</th>
      <td>83435</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>United States of America</td>
      <td>Texas</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>6</td>
      <td>5</td>
      <td>Developer, back-end</td>
      <td>20 to 99 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>160500.0</td>
      <td>Yearly</td>
      <td>Clojure;Kotlin;SQL</td>
      <td>Clojure</td>
      <td>Oracle;SQLite</td>
      <td>SQLite</td>
      <td>AWS</td>
      <td>AWS</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>Git;Kubernetes</td>
      <td>IntelliJ;Sublime Text;Vim;Visual Studio Code</td>
      <td>Sublime Text;Vim</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Google it</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>No</td>
      <td>NaN</td>
      <td>No, not at all</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>I have a concentration and/or memory disorder ...</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>160500.0</td>
    </tr>
    <tr>
      <th>83435</th>
      <td>83436</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>Benin</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>4</td>
      <td>2</td>
      <td>Developer, full-stack</td>
      <td>Just me - I am a freelancer, sole proprietor, ...</td>
      <td>XOF\tWest African CFA franc</td>
      <td>200000.0</td>
      <td>Monthly</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Firebase;MariaDB;MySQL;PostgreSQL;Redis;SQLite</td>
      <td>Firebase;MariaDB;MongoDB;MySQL;PostgreSQL;Redi...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Django;jQuery;Laravel;React.js;Ruby on Rails</td>
      <td>Django;Express;jQuery;Laravel;React.js;Ruby on...</td>
      <td>Flutter;Qt</td>
      <td>NaN</td>
      <td>Git;Unity 3D;Unreal Engine</td>
      <td>Docker;Git;Kubernetes</td>
      <td>Android Studio;Eclipse;Emacs;IntelliJ;NetBeans...</td>
      <td>Emacs;IntelliJ;PHPStorm;PyCharm;RStudio;Sublim...</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Multiple times per day</td>
      <td>Yes</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Black or of African descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>3960.0</td>
    </tr>
    <tr>
      <th>83436</th>
      <td>83437</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>United States of America</td>
      <td>New Jersey</td>
      <td>NaN</td>
      <td>Secondary school (e.g. American high school, G...</td>
      <td>11 - 17 years</td>
      <td>School</td>
      <td>10</td>
      <td>4</td>
      <td>Data scientist or machine learning specialist;...</td>
      <td>10,000 or more employees</td>
      <td>USD\tUnited States dollar</td>
      <td>1800.0</td>
      <td>Weekly</td>
      <td>Groovy;Java;Python</td>
      <td>Java;Python</td>
      <td>DynamoDB;Elasticsearch;MongoDB;PostgreSQL;Redis</td>
      <td>DynamoDB;Redis</td>
      <td>AWS;Google Cloud Platform</td>
      <td>AWS</td>
      <td>FastAPI;Flask</td>
      <td>FastAPI;Flask</td>
      <td>Hadoop;Keras;NumPy;Pandas</td>
      <td>Apache Spark;Hadoop;Keras;NumPy;Pandas;TensorFlow</td>
      <td>Ansible;Docker;Git;Terraform</td>
      <td>Docker;Git;Kubernetes;Terraform</td>
      <td>Android Studio;Eclipse;IntelliJ;IPython/Jupyte...</td>
      <td>IntelliJ;IPython/Jupyter;Notepad++;Vim</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>Yes</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>No, not really</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>NaN</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>90000.0</td>
    </tr>
    <tr>
      <th>83437</th>
      <td>83438</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>Canada</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Online Courses or Certification;Books / Physic...</td>
      <td>5</td>
      <td>3</td>
      <td>Developer, back-end</td>
      <td>20 to 99 employees</td>
      <td>CAD\tCanadian dollar</td>
      <td>90000.0</td>
      <td>Monthly</td>
      <td>Bash/Shell;JavaScript;Node.js;Python</td>
      <td>Go;Rust</td>
      <td>Cassandra;Elasticsearch;MongoDB;PostgreSQL;Redis</td>
      <td>NaN</td>
      <td>Heroku</td>
      <td>AWS;DigitalOcean</td>
      <td>Django;Express;Flask;React.js</td>
      <td>NaN</td>
      <td>NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>Ansible;Docker;Git;Terraform</td>
      <td>Kubernetes;Terraform</td>
      <td>PyCharm;Sublime Text</td>
      <td>NaN</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>A few times per month or weekly</td>
      <td>Yes</td>
      <td>Less than once per month or monthly</td>
      <td>No, not really</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>I have a mood or emotional disorder (e.g. depr...</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>816816.0</td>
    </tr>
    <tr>
      <th>83438</th>
      <td>83439</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>Brazil</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Professional degree (JD, MD, etc.)</td>
      <td>11 - 17 years</td>
      <td>School</td>
      <td>14</td>
      <td>4</td>
      <td>Developer, front-end;Developer, full-stack;Dev...</td>
      <td>I don’t know</td>
      <td>BRL\tBrazilian real</td>
      <td>7700.0</td>
      <td>Monthly</td>
      <td>Delphi;Elixir;HTML/CSS;Java;JavaScript</td>
      <td>Elixir;HTML/CSS;Java;JavaScript;Node.js;PHP;SQ...</td>
      <td>Oracle;PostgreSQL</td>
      <td>Elasticsearch;MongoDB;MySQL;Oracle;PostgreSQL;...</td>
      <td>Microsoft Azure</td>
      <td>AWS</td>
      <td>Angular;Spring</td>
      <td>Express;Laravel;Spring;Symfony</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>Docker;Git;Kubernetes</td>
      <td>IntelliJ;Visual Studio Code</td>
      <td>IntelliJ;PHPStorm;Visual Studio Code</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange;Stack Overflow f...</td>
      <td>A few times per week</td>
      <td>Yes</td>
      <td>A few times per week</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Hispanic or Latino/a/x</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>21168.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Accede a los datos de la columna 'Employment'
datos.Employment
```




    0        Independent contractor, freelancer, or self-em...
    1                                       Student, full-time
    2                                       Student, full-time
    3                                       Employed full-time
    4        Independent contractor, freelancer, or self-em...
                                   ...                        
    83434                                   Employed full-time
    83435    Independent contractor, freelancer, or self-em...
    83436                                   Employed full-time
    83437                                   Employed full-time
    83438                                   Employed full-time
    Name: Employment, Length: 83439, dtype: object




```python
# Accede a los datos de las columnas 'Employment', 'Country', 'YearsCode'
datos[['Employment', 'Country', 'YearsCode']]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Employment</th>
      <th>Country</th>
      <th>YearsCode</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>Slovakia</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Student, full-time</td>
      <td>Netherlands</td>
      <td>7</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Student, full-time</td>
      <td>Russian Federation</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Employed full-time</td>
      <td>Austria</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>United Kingdom of Great Britain and Northern I...</td>
      <td>17</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>83434</th>
      <td>Employed full-time</td>
      <td>United States of America</td>
      <td>6</td>
    </tr>
    <tr>
      <th>83435</th>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>Benin</td>
      <td>4</td>
    </tr>
    <tr>
      <th>83436</th>
      <td>Employed full-time</td>
      <td>United States of America</td>
      <td>10</td>
    </tr>
    <tr>
      <th>83437</th>
      <td>Employed full-time</td>
      <td>Canada</td>
      <td>5</td>
    </tr>
    <tr>
      <th>83438</th>
      <td>Employed full-time</td>
      <td>Brazil</td>
      <td>14</td>
    </tr>
  </tbody>
</table>
<p>83439 rows × 3 columns</p>
</div>




```python
# Muestra las columnas del dataframe
datos.columns
```




    Index(['ResponseId', 'MainBranch', 'Employment', 'Country', 'US_State',
           'UK_Country', 'EdLevel', 'Age1stCode', 'LearnCode', 'YearsCode',
           'YearsCodePro', 'DevType', 'OrgSize', 'Currency', 'CompTotal',
           'CompFreq', 'LanguageHaveWorkedWith', 'LanguageWantToWorkWith',
           'DatabaseHaveWorkedWith', 'DatabaseWantToWorkWith',
           'PlatformHaveWorkedWith', 'PlatformWantToWorkWith',
           'WebframeHaveWorkedWith', 'WebframeWantToWorkWith',
           'MiscTechHaveWorkedWith', 'MiscTechWantToWorkWith',
           'ToolsTechHaveWorkedWith', 'ToolsTechWantToWorkWith',
           'NEWCollabToolsHaveWorkedWith', 'NEWCollabToolsWantToWorkWith', 'OpSys',
           'NEWStuck', 'NEWSOSites', 'SOVisitFreq', 'SOAccount', 'SOPartFreq',
           'SOComm', 'NEWOtherComms', 'Age', 'Gender', 'Trans', 'Sexuality',
           'Ethnicity', 'Accessibility', 'MentalHealth', 'SurveyLength',
           'SurveyEase', 'ConvertedCompYearly'],
          dtype='object')




```python
# Accede a filas con iloc (integer location)
datos.iloc[0]
```




    ResponseId                                                                      1
    MainBranch                                         I am a developer by profession
    Employment                      Independent contractor, freelancer, or self-em...
    Country                                                                  Slovakia
    US_State                                                                      NaN
    UK_Country                                                                    NaN
    EdLevel                         Secondary school (e.g. American high school, G...
    Age1stCode                                                          18 - 24 years
    LearnCode                       Coding Bootcamp;Other online resources (ex: vi...
    YearsCode                                                                     NaN
    YearsCodePro                                                                  NaN
    DevType                                                         Developer, mobile
    OrgSize                                                        20 to 99 employees
    Currency                                                        EUR European Euro
    CompTotal                                                                  4800.0
    CompFreq                                                                  Monthly
    LanguageHaveWorkedWith              C++;HTML/CSS;JavaScript;Objective-C;PHP;Swift
    LanguageWantToWorkWith                                                      Swift
    DatabaseHaveWorkedWith                                          PostgreSQL;SQLite
    DatabaseWantToWorkWith                                                     SQLite
    PlatformHaveWorkedWith                                                        NaN
    PlatformWantToWorkWith                                                        NaN
    WebframeHaveWorkedWith                                            Laravel;Symfony
    WebframeWantToWorkWith                                                        NaN
    MiscTechHaveWorkedWith                                                        NaN
    MiscTechWantToWorkWith                                                        NaN
    ToolsTechHaveWorkedWith                                                       NaN
    ToolsTechWantToWorkWith                                                       NaN
    NEWCollabToolsHaveWorkedWith                                       PHPStorm;Xcode
    NEWCollabToolsWantToWorkWith                                           Atom;Xcode
    OpSys                                                                       MacOS
    NEWStuck                        Call a coworker or friend;Visit Stack Overflow...
    NEWSOSites                                                         Stack Overflow
    SOVisitFreq                                                Multiple times per day
    SOAccount                                                                     Yes
    SOPartFreq                                        A few times per month or weekly
    SOComm                                                            Yes, definitely
    NEWOtherComms                                                                  No
    Age                                                               25-34 years old
    Gender                                                                        Man
    Trans                                                                          No
    Sexuality                                                 Straight / Heterosexual
    Ethnicity                                            White or of European descent
    Accessibility                                                   None of the above
    MentalHealth                                                    None of the above
    SurveyLength                                                Appropriate in length
    SurveyEase                                                                   Easy
    ConvertedCompYearly                                                       62268.0
    Name: 0, dtype: object




```python
datos.iloc[[0, 3, 5]]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ResponseId</th>
      <th>MainBranch</th>
      <th>Employment</th>
      <th>Country</th>
      <th>US_State</th>
      <th>UK_Country</th>
      <th>EdLevel</th>
      <th>Age1stCode</th>
      <th>LearnCode</th>
      <th>YearsCode</th>
      <th>YearsCodePro</th>
      <th>DevType</th>
      <th>OrgSize</th>
      <th>Currency</th>
      <th>CompTotal</th>
      <th>CompFreq</th>
      <th>LanguageHaveWorkedWith</th>
      <th>LanguageWantToWorkWith</th>
      <th>DatabaseHaveWorkedWith</th>
      <th>DatabaseWantToWorkWith</th>
      <th>PlatformHaveWorkedWith</th>
      <th>PlatformWantToWorkWith</th>
      <th>WebframeHaveWorkedWith</th>
      <th>WebframeWantToWorkWith</th>
      <th>MiscTechHaveWorkedWith</th>
      <th>MiscTechWantToWorkWith</th>
      <th>ToolsTechHaveWorkedWith</th>
      <th>ToolsTechWantToWorkWith</th>
      <th>NEWCollabToolsHaveWorkedWith</th>
      <th>NEWCollabToolsWantToWorkWith</th>
      <th>OpSys</th>
      <th>NEWStuck</th>
      <th>NEWSOSites</th>
      <th>SOVisitFreq</th>
      <th>SOAccount</th>
      <th>SOPartFreq</th>
      <th>SOComm</th>
      <th>NEWOtherComms</th>
      <th>Age</th>
      <th>Gender</th>
      <th>Trans</th>
      <th>Sexuality</th>
      <th>Ethnicity</th>
      <th>Accessibility</th>
      <th>MentalHealth</th>
      <th>SurveyLength</th>
      <th>SurveyEase</th>
      <th>ConvertedCompYearly</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>Slovakia</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Secondary school (e.g. American high school, G...</td>
      <td>18 - 24 years</td>
      <td>Coding Bootcamp;Other online resources (ex: vi...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Developer, mobile</td>
      <td>20 to 99 employees</td>
      <td>EUR European Euro</td>
      <td>4800.0</td>
      <td>Monthly</td>
      <td>C++;HTML/CSS;JavaScript;Objective-C;PHP;Swift</td>
      <td>Swift</td>
      <td>PostgreSQL;SQLite</td>
      <td>SQLite</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Laravel;Symfony</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>PHPStorm;Xcode</td>
      <td>Atom;Xcode</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>Multiple times per day</td>
      <td>Yes</td>
      <td>A few times per month or weekly</td>
      <td>Yes, definitely</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>62268.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>Austria</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>11 - 17 years</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Developer, front-end</td>
      <td>100 to 499 employees</td>
      <td>EUR European Euro</td>
      <td>NaN</td>
      <td>Monthly</td>
      <td>JavaScript;TypeScript</td>
      <td>JavaScript;TypeScript</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Angular;jQuery</td>
      <td>Angular;jQuery</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>Daily or almost daily</td>
      <td>Neutral</td>
      <td>No</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>I am deaf / hard of hearing</td>
      <td>NaN</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>5</th>
      <td>6</td>
      <td>I am a student who is learning to code</td>
      <td>Student, part-time</td>
      <td>United States of America</td>
      <td>Georgia</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>C;C#;C++;HTML/CSS;Java;JavaScript;Node.js;Powe...</td>
      <td>C#;C++;Go;HTML/CSS;Java;JavaScript;Node.js;Obj...</td>
      <td>MySQL;PostgreSQL;SQLite</td>
      <td>Elasticsearch;Firebase;IBM DB2;MariaDB;Microso...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Express;Flask;jQuery;React.js</td>
      <td>Express;Flask;jQuery;React.js</td>
      <td>Keras;NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>Keras;NumPy;Pandas;Qt;React Native;TensorFlow;...</td>
      <td>Git</td>
      <td>Docker;Git;Unity 3D;Unreal Engine</td>
      <td>IPython/Jupyter;Notepad++;PyCharm;Sublime Text...</td>
      <td>Android Studio;IPython/Jupyter;Vim;Visual Stud...</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Multiple times per day</td>
      <td>Yes</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Prefer not to say</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Prefer not to say</td>
      <td>None of the above</td>
      <td>I have a concentration and/or memory disorder ...</td>
      <td>Too long</td>
      <td>Neither easy nor difficult</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Muestra la columna 3 de las filas 0, 3, y 5
datos.iloc[[0, 3, 5], 3]
```




    0                    Slovakia
    3                     Austria
    5    United States of America
    Name: Country, dtype: object




```python
# loc muestra resultados buscando por etiquetas (labels)
datos.loc[[0, 3, 5], 'Country']
```




    0                    Slovakia
    3                     Austria
    5    United States of America
    Name: Country, dtype: object




```python
# Cuenta los países de donde provienen los programadores
datos.Country.value_counts()
```




    United States of America                                15288
    India                                                   10511
    Germany                                                  5625
    United Kingdom of Great Britain and Northern Ireland     4475
    Canada                                                   3012
                                                            ...  
    Saint Kitts and Nevis                                       1
    Dominica                                                    1
    Saint Vincent and the Grenadines                            1
    Tuvalu                                                      1
    Papua New Guinea                                            1
    Name: Country, Length: 181, dtype: int64




```python
# Determinar una columna como identificador primario
datos.set_index('ResponseId')
# Para establecerla
# datos.set_index('ResponseId', inplace=True)
# Para volver al ID original
# datos.reset_index(inplace=True)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>MainBranch</th>
      <th>Employment</th>
      <th>Country</th>
      <th>US_State</th>
      <th>UK_Country</th>
      <th>EdLevel</th>
      <th>Age1stCode</th>
      <th>LearnCode</th>
      <th>YearsCode</th>
      <th>YearsCodePro</th>
      <th>DevType</th>
      <th>OrgSize</th>
      <th>Currency</th>
      <th>CompTotal</th>
      <th>CompFreq</th>
      <th>LanguageHaveWorkedWith</th>
      <th>LanguageWantToWorkWith</th>
      <th>DatabaseHaveWorkedWith</th>
      <th>DatabaseWantToWorkWith</th>
      <th>PlatformHaveWorkedWith</th>
      <th>PlatformWantToWorkWith</th>
      <th>WebframeHaveWorkedWith</th>
      <th>WebframeWantToWorkWith</th>
      <th>MiscTechHaveWorkedWith</th>
      <th>MiscTechWantToWorkWith</th>
      <th>ToolsTechHaveWorkedWith</th>
      <th>ToolsTechWantToWorkWith</th>
      <th>NEWCollabToolsHaveWorkedWith</th>
      <th>NEWCollabToolsWantToWorkWith</th>
      <th>OpSys</th>
      <th>NEWStuck</th>
      <th>NEWSOSites</th>
      <th>SOVisitFreq</th>
      <th>SOAccount</th>
      <th>SOPartFreq</th>
      <th>SOComm</th>
      <th>NEWOtherComms</th>
      <th>Age</th>
      <th>Gender</th>
      <th>Trans</th>
      <th>Sexuality</th>
      <th>Ethnicity</th>
      <th>Accessibility</th>
      <th>MentalHealth</th>
      <th>SurveyLength</th>
      <th>SurveyEase</th>
      <th>ConvertedCompYearly</th>
    </tr>
    <tr>
      <th>ResponseId</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>Slovakia</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Secondary school (e.g. American high school, G...</td>
      <td>18 - 24 years</td>
      <td>Coding Bootcamp;Other online resources (ex: vi...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Developer, mobile</td>
      <td>20 to 99 employees</td>
      <td>EUR European Euro</td>
      <td>4800.0</td>
      <td>Monthly</td>
      <td>C++;HTML/CSS;JavaScript;Objective-C;PHP;Swift</td>
      <td>Swift</td>
      <td>PostgreSQL;SQLite</td>
      <td>SQLite</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Laravel;Symfony</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>PHPStorm;Xcode</td>
      <td>Atom;Xcode</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>Multiple times per day</td>
      <td>Yes</td>
      <td>A few times per month or weekly</td>
      <td>Yes, definitely</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>62268.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>I am a student who is learning to code</td>
      <td>Student, full-time</td>
      <td>Netherlands</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>7</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>JavaScript;Python</td>
      <td>NaN</td>
      <td>PostgreSQL</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Angular;Flask;Vue.js</td>
      <td>NaN</td>
      <td>Cordova</td>
      <td>NaN</td>
      <td>Docker;Git;Yarn</td>
      <td>Git</td>
      <td>Android Studio;IntelliJ;Notepad++;PyCharm</td>
      <td>NaN</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Google it</td>
      <td>Stack Overflow</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>Daily or almost daily</td>
      <td>Yes, definitely</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>I am not primarily a developer, but I write co...</td>
      <td>Student, full-time</td>
      <td>Russian Federation</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Assembly;C;Python;R;Rust</td>
      <td>Julia;Python;Rust</td>
      <td>SQLite</td>
      <td>SQLite</td>
      <td>Heroku</td>
      <td>NaN</td>
      <td>Flask</td>
      <td>Flask</td>
      <td>NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>Keras;NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>IPython/Jupyter;PyCharm;RStudio;Sublime Text;V...</td>
      <td>IPython/Jupyter;RStudio;Sublime Text;Visual St...</td>
      <td>MacOS</td>
      <td>Visit Stack Overflow;Google it;Watch help / tu...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Multiple times per day</td>
      <td>Yes</td>
      <td>Multiple times per day</td>
      <td>Yes, definitely</td>
      <td>Yes</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>Austria</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>11 - 17 years</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Developer, front-end</td>
      <td>100 to 499 employees</td>
      <td>EUR European Euro</td>
      <td>NaN</td>
      <td>Monthly</td>
      <td>JavaScript;TypeScript</td>
      <td>JavaScript;TypeScript</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Angular;jQuery</td>
      <td>Angular;jQuery</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>Daily or almost daily</td>
      <td>Neutral</td>
      <td>No</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>I am deaf / hard of hearing</td>
      <td>NaN</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>5</th>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>United Kingdom of Great Britain and Northern I...</td>
      <td>NaN</td>
      <td>England</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>5 - 10 years</td>
      <td>Friend or family member</td>
      <td>17</td>
      <td>10</td>
      <td>Developer, desktop or enterprise applications;...</td>
      <td>Just me - I am a freelancer, sole proprietor, ...</td>
      <td>GBP\tPound sterling</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bash/Shell;HTML/CSS;Python;SQL</td>
      <td>Bash/Shell;HTML/CSS;Python;SQL</td>
      <td>Elasticsearch;PostgreSQL;Redis</td>
      <td>Cassandra;Elasticsearch;PostgreSQL;Redis</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Flask</td>
      <td>Flask</td>
      <td>Apache Spark;Hadoop;NumPy;Pandas</td>
      <td>Hadoop;NumPy;Pandas</td>
      <td>Docker;Git;Kubernetes;Yarn</td>
      <td>Docker;Git;Kubernetes;Yarn</td>
      <td>Atom;IPython/Jupyter;Notepad++;PyCharm;Vim</td>
      <td>Atom;IPython/Jupyter;Notepad++;PyCharm;Vim;Vis...</td>
      <td>Linux-based</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>A few times per week</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>NaN</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>NaN</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>83435</th>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>United States of America</td>
      <td>Texas</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>6</td>
      <td>5</td>
      <td>Developer, back-end</td>
      <td>20 to 99 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>160500.0</td>
      <td>Yearly</td>
      <td>Clojure;Kotlin;SQL</td>
      <td>Clojure</td>
      <td>Oracle;SQLite</td>
      <td>SQLite</td>
      <td>AWS</td>
      <td>AWS</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>Git;Kubernetes</td>
      <td>IntelliJ;Sublime Text;Vim;Visual Studio Code</td>
      <td>Sublime Text;Vim</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Google it</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>No</td>
      <td>NaN</td>
      <td>No, not at all</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>I have a concentration and/or memory disorder ...</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>160500.0</td>
    </tr>
    <tr>
      <th>83436</th>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>Benin</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>4</td>
      <td>2</td>
      <td>Developer, full-stack</td>
      <td>Just me - I am a freelancer, sole proprietor, ...</td>
      <td>XOF\tWest African CFA franc</td>
      <td>200000.0</td>
      <td>Monthly</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Firebase;MariaDB;MySQL;PostgreSQL;Redis;SQLite</td>
      <td>Firebase;MariaDB;MongoDB;MySQL;PostgreSQL;Redi...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Django;jQuery;Laravel;React.js;Ruby on Rails</td>
      <td>Django;Express;jQuery;Laravel;React.js;Ruby on...</td>
      <td>Flutter;Qt</td>
      <td>NaN</td>
      <td>Git;Unity 3D;Unreal Engine</td>
      <td>Docker;Git;Kubernetes</td>
      <td>Android Studio;Eclipse;Emacs;IntelliJ;NetBeans...</td>
      <td>Emacs;IntelliJ;PHPStorm;PyCharm;RStudio;Sublim...</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Multiple times per day</td>
      <td>Yes</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Black or of African descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>3960.0</td>
    </tr>
    <tr>
      <th>83437</th>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>United States of America</td>
      <td>New Jersey</td>
      <td>NaN</td>
      <td>Secondary school (e.g. American high school, G...</td>
      <td>11 - 17 years</td>
      <td>School</td>
      <td>10</td>
      <td>4</td>
      <td>Data scientist or machine learning specialist;...</td>
      <td>10,000 or more employees</td>
      <td>USD\tUnited States dollar</td>
      <td>1800.0</td>
      <td>Weekly</td>
      <td>Groovy;Java;Python</td>
      <td>Java;Python</td>
      <td>DynamoDB;Elasticsearch;MongoDB;PostgreSQL;Redis</td>
      <td>DynamoDB;Redis</td>
      <td>AWS;Google Cloud Platform</td>
      <td>AWS</td>
      <td>FastAPI;Flask</td>
      <td>FastAPI;Flask</td>
      <td>Hadoop;Keras;NumPy;Pandas</td>
      <td>Apache Spark;Hadoop;Keras;NumPy;Pandas;TensorFlow</td>
      <td>Ansible;Docker;Git;Terraform</td>
      <td>Docker;Git;Kubernetes;Terraform</td>
      <td>Android Studio;Eclipse;IntelliJ;IPython/Jupyte...</td>
      <td>IntelliJ;IPython/Jupyter;Notepad++;Vim</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>Yes</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>No, not really</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>NaN</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>90000.0</td>
    </tr>
    <tr>
      <th>83438</th>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>Canada</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Online Courses or Certification;Books / Physic...</td>
      <td>5</td>
      <td>3</td>
      <td>Developer, back-end</td>
      <td>20 to 99 employees</td>
      <td>CAD\tCanadian dollar</td>
      <td>90000.0</td>
      <td>Monthly</td>
      <td>Bash/Shell;JavaScript;Node.js;Python</td>
      <td>Go;Rust</td>
      <td>Cassandra;Elasticsearch;MongoDB;PostgreSQL;Redis</td>
      <td>NaN</td>
      <td>Heroku</td>
      <td>AWS;DigitalOcean</td>
      <td>Django;Express;Flask;React.js</td>
      <td>NaN</td>
      <td>NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>Ansible;Docker;Git;Terraform</td>
      <td>Kubernetes;Terraform</td>
      <td>PyCharm;Sublime Text</td>
      <td>NaN</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>A few times per month or weekly</td>
      <td>Yes</td>
      <td>Less than once per month or monthly</td>
      <td>No, not really</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>I have a mood or emotional disorder (e.g. depr...</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>816816.0</td>
    </tr>
    <tr>
      <th>83439</th>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>Brazil</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Professional degree (JD, MD, etc.)</td>
      <td>11 - 17 years</td>
      <td>School</td>
      <td>14</td>
      <td>4</td>
      <td>Developer, front-end;Developer, full-stack;Dev...</td>
      <td>I don’t know</td>
      <td>BRL\tBrazilian real</td>
      <td>7700.0</td>
      <td>Monthly</td>
      <td>Delphi;Elixir;HTML/CSS;Java;JavaScript</td>
      <td>Elixir;HTML/CSS;Java;JavaScript;Node.js;PHP;SQ...</td>
      <td>Oracle;PostgreSQL</td>
      <td>Elasticsearch;MongoDB;MySQL;Oracle;PostgreSQL;...</td>
      <td>Microsoft Azure</td>
      <td>AWS</td>
      <td>Angular;Spring</td>
      <td>Express;Laravel;Spring;Symfony</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>Docker;Git;Kubernetes</td>
      <td>IntelliJ;Visual Studio Code</td>
      <td>IntelliJ;PHPStorm;Visual Studio Code</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange;Stack Overflow f...</td>
      <td>A few times per week</td>
      <td>Yes</td>
      <td>A few times per week</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Hispanic or Latino/a/x</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>21168.0</td>
    </tr>
  </tbody>
</table>
<p>83439 rows × 47 columns</p>
</div>




```python
datos
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ResponseId</th>
      <th>MainBranch</th>
      <th>Employment</th>
      <th>Country</th>
      <th>US_State</th>
      <th>UK_Country</th>
      <th>EdLevel</th>
      <th>Age1stCode</th>
      <th>LearnCode</th>
      <th>YearsCode</th>
      <th>YearsCodePro</th>
      <th>DevType</th>
      <th>OrgSize</th>
      <th>Currency</th>
      <th>CompTotal</th>
      <th>CompFreq</th>
      <th>LanguageHaveWorkedWith</th>
      <th>LanguageWantToWorkWith</th>
      <th>DatabaseHaveWorkedWith</th>
      <th>DatabaseWantToWorkWith</th>
      <th>PlatformHaveWorkedWith</th>
      <th>PlatformWantToWorkWith</th>
      <th>WebframeHaveWorkedWith</th>
      <th>WebframeWantToWorkWith</th>
      <th>MiscTechHaveWorkedWith</th>
      <th>MiscTechWantToWorkWith</th>
      <th>ToolsTechHaveWorkedWith</th>
      <th>ToolsTechWantToWorkWith</th>
      <th>NEWCollabToolsHaveWorkedWith</th>
      <th>NEWCollabToolsWantToWorkWith</th>
      <th>OpSys</th>
      <th>NEWStuck</th>
      <th>NEWSOSites</th>
      <th>SOVisitFreq</th>
      <th>SOAccount</th>
      <th>SOPartFreq</th>
      <th>SOComm</th>
      <th>NEWOtherComms</th>
      <th>Age</th>
      <th>Gender</th>
      <th>Trans</th>
      <th>Sexuality</th>
      <th>Ethnicity</th>
      <th>Accessibility</th>
      <th>MentalHealth</th>
      <th>SurveyLength</th>
      <th>SurveyEase</th>
      <th>ConvertedCompYearly</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>Slovakia</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Secondary school (e.g. American high school, G...</td>
      <td>18 - 24 years</td>
      <td>Coding Bootcamp;Other online resources (ex: vi...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Developer, mobile</td>
      <td>20 to 99 employees</td>
      <td>EUR European Euro</td>
      <td>4800.0</td>
      <td>Monthly</td>
      <td>C++;HTML/CSS;JavaScript;Objective-C;PHP;Swift</td>
      <td>Swift</td>
      <td>PostgreSQL;SQLite</td>
      <td>SQLite</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Laravel;Symfony</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>PHPStorm;Xcode</td>
      <td>Atom;Xcode</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>Multiple times per day</td>
      <td>Yes</td>
      <td>A few times per month or weekly</td>
      <td>Yes, definitely</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>62268.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>I am a student who is learning to code</td>
      <td>Student, full-time</td>
      <td>Netherlands</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>7</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>JavaScript;Python</td>
      <td>NaN</td>
      <td>PostgreSQL</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Angular;Flask;Vue.js</td>
      <td>NaN</td>
      <td>Cordova</td>
      <td>NaN</td>
      <td>Docker;Git;Yarn</td>
      <td>Git</td>
      <td>Android Studio;IntelliJ;Notepad++;PyCharm</td>
      <td>NaN</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Google it</td>
      <td>Stack Overflow</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>Daily or almost daily</td>
      <td>Yes, definitely</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>I am not primarily a developer, but I write co...</td>
      <td>Student, full-time</td>
      <td>Russian Federation</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Assembly;C;Python;R;Rust</td>
      <td>Julia;Python;Rust</td>
      <td>SQLite</td>
      <td>SQLite</td>
      <td>Heroku</td>
      <td>NaN</td>
      <td>Flask</td>
      <td>Flask</td>
      <td>NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>Keras;NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>IPython/Jupyter;PyCharm;RStudio;Sublime Text;V...</td>
      <td>IPython/Jupyter;RStudio;Sublime Text;Visual St...</td>
      <td>MacOS</td>
      <td>Visit Stack Overflow;Google it;Watch help / tu...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Multiple times per day</td>
      <td>Yes</td>
      <td>Multiple times per day</td>
      <td>Yes, definitely</td>
      <td>Yes</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>Austria</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>11 - 17 years</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Developer, front-end</td>
      <td>100 to 499 employees</td>
      <td>EUR European Euro</td>
      <td>NaN</td>
      <td>Monthly</td>
      <td>JavaScript;TypeScript</td>
      <td>JavaScript;TypeScript</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Angular;jQuery</td>
      <td>Angular;jQuery</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>Daily or almost daily</td>
      <td>Neutral</td>
      <td>No</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>I am deaf / hard of hearing</td>
      <td>NaN</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>United Kingdom of Great Britain and Northern I...</td>
      <td>NaN</td>
      <td>England</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>5 - 10 years</td>
      <td>Friend or family member</td>
      <td>17</td>
      <td>10</td>
      <td>Developer, desktop or enterprise applications;...</td>
      <td>Just me - I am a freelancer, sole proprietor, ...</td>
      <td>GBP\tPound sterling</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bash/Shell;HTML/CSS;Python;SQL</td>
      <td>Bash/Shell;HTML/CSS;Python;SQL</td>
      <td>Elasticsearch;PostgreSQL;Redis</td>
      <td>Cassandra;Elasticsearch;PostgreSQL;Redis</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Flask</td>
      <td>Flask</td>
      <td>Apache Spark;Hadoop;NumPy;Pandas</td>
      <td>Hadoop;NumPy;Pandas</td>
      <td>Docker;Git;Kubernetes;Yarn</td>
      <td>Docker;Git;Kubernetes;Yarn</td>
      <td>Atom;IPython/Jupyter;Notepad++;PyCharm;Vim</td>
      <td>Atom;IPython/Jupyter;Notepad++;PyCharm;Vim;Vis...</td>
      <td>Linux-based</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>A few times per week</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>NaN</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>NaN</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>83434</th>
      <td>83435</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>United States of America</td>
      <td>Texas</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>6</td>
      <td>5</td>
      <td>Developer, back-end</td>
      <td>20 to 99 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>160500.0</td>
      <td>Yearly</td>
      <td>Clojure;Kotlin;SQL</td>
      <td>Clojure</td>
      <td>Oracle;SQLite</td>
      <td>SQLite</td>
      <td>AWS</td>
      <td>AWS</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>Git;Kubernetes</td>
      <td>IntelliJ;Sublime Text;Vim;Visual Studio Code</td>
      <td>Sublime Text;Vim</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Google it</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>No</td>
      <td>NaN</td>
      <td>No, not at all</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>I have a concentration and/or memory disorder ...</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>160500.0</td>
    </tr>
    <tr>
      <th>83435</th>
      <td>83436</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>Benin</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>4</td>
      <td>2</td>
      <td>Developer, full-stack</td>
      <td>Just me - I am a freelancer, sole proprietor, ...</td>
      <td>XOF\tWest African CFA franc</td>
      <td>200000.0</td>
      <td>Monthly</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Firebase;MariaDB;MySQL;PostgreSQL;Redis;SQLite</td>
      <td>Firebase;MariaDB;MongoDB;MySQL;PostgreSQL;Redi...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Django;jQuery;Laravel;React.js;Ruby on Rails</td>
      <td>Django;Express;jQuery;Laravel;React.js;Ruby on...</td>
      <td>Flutter;Qt</td>
      <td>NaN</td>
      <td>Git;Unity 3D;Unreal Engine</td>
      <td>Docker;Git;Kubernetes</td>
      <td>Android Studio;Eclipse;Emacs;IntelliJ;NetBeans...</td>
      <td>Emacs;IntelliJ;PHPStorm;PyCharm;RStudio;Sublim...</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Multiple times per day</td>
      <td>Yes</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Black or of African descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>3960.0</td>
    </tr>
    <tr>
      <th>83436</th>
      <td>83437</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>United States of America</td>
      <td>New Jersey</td>
      <td>NaN</td>
      <td>Secondary school (e.g. American high school, G...</td>
      <td>11 - 17 years</td>
      <td>School</td>
      <td>10</td>
      <td>4</td>
      <td>Data scientist or machine learning specialist;...</td>
      <td>10,000 or more employees</td>
      <td>USD\tUnited States dollar</td>
      <td>1800.0</td>
      <td>Weekly</td>
      <td>Groovy;Java;Python</td>
      <td>Java;Python</td>
      <td>DynamoDB;Elasticsearch;MongoDB;PostgreSQL;Redis</td>
      <td>DynamoDB;Redis</td>
      <td>AWS;Google Cloud Platform</td>
      <td>AWS</td>
      <td>FastAPI;Flask</td>
      <td>FastAPI;Flask</td>
      <td>Hadoop;Keras;NumPy;Pandas</td>
      <td>Apache Spark;Hadoop;Keras;NumPy;Pandas;TensorFlow</td>
      <td>Ansible;Docker;Git;Terraform</td>
      <td>Docker;Git;Kubernetes;Terraform</td>
      <td>Android Studio;Eclipse;IntelliJ;IPython/Jupyte...</td>
      <td>IntelliJ;IPython/Jupyter;Notepad++;Vim</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>Yes</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>No, not really</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>NaN</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>90000.0</td>
    </tr>
    <tr>
      <th>83437</th>
      <td>83438</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>Canada</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Online Courses or Certification;Books / Physic...</td>
      <td>5</td>
      <td>3</td>
      <td>Developer, back-end</td>
      <td>20 to 99 employees</td>
      <td>CAD\tCanadian dollar</td>
      <td>90000.0</td>
      <td>Monthly</td>
      <td>Bash/Shell;JavaScript;Node.js;Python</td>
      <td>Go;Rust</td>
      <td>Cassandra;Elasticsearch;MongoDB;PostgreSQL;Redis</td>
      <td>NaN</td>
      <td>Heroku</td>
      <td>AWS;DigitalOcean</td>
      <td>Django;Express;Flask;React.js</td>
      <td>NaN</td>
      <td>NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>Ansible;Docker;Git;Terraform</td>
      <td>Kubernetes;Terraform</td>
      <td>PyCharm;Sublime Text</td>
      <td>NaN</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>A few times per month or weekly</td>
      <td>Yes</td>
      <td>Less than once per month or monthly</td>
      <td>No, not really</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>I have a mood or emotional disorder (e.g. depr...</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>816816.0</td>
    </tr>
    <tr>
      <th>83438</th>
      <td>83439</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>Brazil</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Professional degree (JD, MD, etc.)</td>
      <td>11 - 17 years</td>
      <td>School</td>
      <td>14</td>
      <td>4</td>
      <td>Developer, front-end;Developer, full-stack;Dev...</td>
      <td>I don’t know</td>
      <td>BRL\tBrazilian real</td>
      <td>7700.0</td>
      <td>Monthly</td>
      <td>Delphi;Elixir;HTML/CSS;Java;JavaScript</td>
      <td>Elixir;HTML/CSS;Java;JavaScript;Node.js;PHP;SQ...</td>
      <td>Oracle;PostgreSQL</td>
      <td>Elasticsearch;MongoDB;MySQL;Oracle;PostgreSQL;...</td>
      <td>Microsoft Azure</td>
      <td>AWS</td>
      <td>Angular;Spring</td>
      <td>Express;Laravel;Spring;Symfony</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>Docker;Git;Kubernetes</td>
      <td>IntelliJ;Visual Studio Code</td>
      <td>IntelliJ;PHPStorm;Visual Studio Code</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange;Stack Overflow f...</td>
      <td>A few times per week</td>
      <td>Yes</td>
      <td>A few times per week</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Hispanic or Latino/a/x</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>21168.0</td>
    </tr>
  </tbody>
</table>
<p>83439 rows × 48 columns</p>
</div>




```python
# Determinar una columna como identificador primario al crear el dataframe
schema_datos = pd.read_csv('survey_results_schema.csv', index_col='qname')
```


```python
schema_datos
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>qid</th>
      <th>question</th>
      <th>force_resp</th>
      <th>type</th>
      <th>selector</th>
    </tr>
    <tr>
      <th>qname</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>S0</th>
      <td>QID16</td>
      <td>&lt;div&gt;&lt;span style="font-size:19px;"&gt;&lt;strong&gt;Hel...</td>
      <td>False</td>
      <td>DB</td>
      <td>TB</td>
    </tr>
    <tr>
      <th>MetaInfo</th>
      <td>QID12</td>
      <td>Browser Meta Info</td>
      <td>False</td>
      <td>Meta</td>
      <td>Browser</td>
    </tr>
    <tr>
      <th>S1</th>
      <td>QID1</td>
      <td>&lt;span style="font-size:22px; font-family: aria...</td>
      <td>False</td>
      <td>DB</td>
      <td>TB</td>
    </tr>
    <tr>
      <th>MainBranch</th>
      <td>QID2</td>
      <td>Which of the following options best describes ...</td>
      <td>True</td>
      <td>MC</td>
      <td>SAVR</td>
    </tr>
    <tr>
      <th>Employment</th>
      <td>QID24</td>
      <td>Which of the following best describes your cur...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>Country</th>
      <td>QID6</td>
      <td>Where do you live? &lt;span style="font-weight: b...</td>
      <td>True</td>
      <td>MC</td>
      <td>DL</td>
    </tr>
    <tr>
      <th>US_State</th>
      <td>QID7</td>
      <td>&lt;p&gt;In which state or territory of the USA do y...</td>
      <td>False</td>
      <td>MC</td>
      <td>DL</td>
    </tr>
    <tr>
      <th>UK_Country</th>
      <td>QID9</td>
      <td>In which part of the United Kingdom do you liv...</td>
      <td>False</td>
      <td>MC</td>
      <td>DL</td>
    </tr>
    <tr>
      <th>S2</th>
      <td>QID190</td>
      <td>&lt;span style="font-size:22px; font-family: aria...</td>
      <td>False</td>
      <td>DB</td>
      <td>TB</td>
    </tr>
    <tr>
      <th>EdLevel</th>
      <td>QID25</td>
      <td>Which of the following best describes the high...</td>
      <td>False</td>
      <td>MC</td>
      <td>SAVR</td>
    </tr>
    <tr>
      <th>Age1stCode</th>
      <td>QID149</td>
      <td>At what age did you write your first line of c...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>LearnCode</th>
      <td>QID276</td>
      <td>How did you learn to code? Select all that apply.</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>YearsCode</th>
      <td>QID32</td>
      <td>Including any education, how many years have y...</td>
      <td>False</td>
      <td>MC</td>
      <td>DL</td>
    </tr>
    <tr>
      <th>YearsCodePro</th>
      <td>QID34</td>
      <td>NOT including education, how many years have y...</td>
      <td>False</td>
      <td>MC</td>
      <td>DL</td>
    </tr>
    <tr>
      <th>DevType</th>
      <td>QID31</td>
      <td>Which of the following describes your current ...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>OrgSize</th>
      <td>QID29</td>
      <td>Approximately how many people are employed by ...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>Currency</th>
      <td>QID50</td>
      <td>Which currency do you use day-to-day? If your ...</td>
      <td>True</td>
      <td>MC</td>
      <td>SB</td>
    </tr>
    <tr>
      <th>CompTotal</th>
      <td>QID51</td>
      <td>What is your current total compensation (salar...</td>
      <td>False</td>
      <td>TE</td>
      <td>SL</td>
    </tr>
    <tr>
      <th>CompFreq</th>
      <td>QID52</td>
      <td>Is that compensation weekly, monthly, or yearly?</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>S3</th>
      <td>QID61</td>
      <td>&lt;span style="font-size:22px; font-family: aria...</td>
      <td>False</td>
      <td>DB</td>
      <td>TB</td>
    </tr>
    <tr>
      <th>Language</th>
      <td>QID233</td>
      <td>Which &lt;b&gt;programming, scripting, and markup la...</td>
      <td>False</td>
      <td>Matrix</td>
      <td>Likert</td>
    </tr>
    <tr>
      <th>Database</th>
      <td>QID262</td>
      <td>Which &lt;b&gt;database environments &lt;/b&gt;have you do...</td>
      <td>False</td>
      <td>Matrix</td>
      <td>Likert</td>
    </tr>
    <tr>
      <th>Platform</th>
      <td>QID263</td>
      <td>Which &lt;b&gt;cloud platforms&lt;/b&gt; have you done ext...</td>
      <td>False</td>
      <td>Matrix</td>
      <td>Likert</td>
    </tr>
    <tr>
      <th>Webframe</th>
      <td>QID264</td>
      <td>Which &lt;strong&gt;web frameworks &lt;/strong&gt;&lt;span st...</td>
      <td>False</td>
      <td>Matrix</td>
      <td>Likert</td>
    </tr>
    <tr>
      <th>MiscTech</th>
      <td>QID265</td>
      <td>Which &lt;b&gt;other frameworks and libraries&lt;/b&gt; ha...</td>
      <td>False</td>
      <td>Matrix</td>
      <td>Likert</td>
    </tr>
    <tr>
      <th>ToolsTech</th>
      <td>QID275</td>
      <td>Which &lt;strong&gt;tools&lt;/strong&gt; have you done ext...</td>
      <td>False</td>
      <td>Matrix</td>
      <td>Likert</td>
    </tr>
    <tr>
      <th>NEWCollabTools</th>
      <td>QID274</td>
      <td>Which &lt;strong&gt;development environments&lt;/strong...</td>
      <td>False</td>
      <td>Matrix</td>
      <td>Likert</td>
    </tr>
    <tr>
      <th>OpSys</th>
      <td>QID71</td>
      <td>What is the primary operating system in which ...</td>
      <td>False</td>
      <td>MC</td>
      <td>SAVR</td>
    </tr>
    <tr>
      <th>NEWStuck</th>
      <td>QID243</td>
      <td>What do you do when you get stuck on a problem...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>S4</th>
      <td>QID91</td>
      <td>&lt;span style="font-size:22px; font-family: aria...</td>
      <td>False</td>
      <td>DB</td>
      <td>TB</td>
    </tr>
    <tr>
      <th>NEWSOSites</th>
      <td>QID266</td>
      <td>Which of the following Stack Overflow sites ha...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>SOVisitFreq</th>
      <td>QID100</td>
      <td>How frequently would you say you visit Stack O...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>SOAccount</th>
      <td>QID101</td>
      <td>Do you have a Stack Overflow account?</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>SOPartFreq</th>
      <td>QID102</td>
      <td>How frequently would you say you participate i...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>SOComm</th>
      <td>QID106</td>
      <td>Do you consider yourself a member of the Stack...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>NEWOtherComms</th>
      <td>QID267</td>
      <td>Are you a member of any other online developer...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>NEWOtherCommsNames</th>
      <td>QID268</td>
      <td>Please name up to 5 other online developer com...</td>
      <td>False</td>
      <td>Matrix</td>
      <td>Likert</td>
    </tr>
    <tr>
      <th>S5</th>
      <td>QID121</td>
      <td>&lt;span style="font-size:22px; font-family: aria...</td>
      <td>False</td>
      <td>DB</td>
      <td>TB</td>
    </tr>
    <tr>
      <th>Age</th>
      <td>QID127</td>
      <td>What is your age?</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>Gender</th>
      <td>QID122</td>
      <td>Which of the following describe you, if any? P...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>Trans</th>
      <td>QID153</td>
      <td>Do you identify as transgender?</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>Sexuality</th>
      <td>QID136</td>
      <td>Which of the following describe you, if any? P...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>Ethnicity</th>
      <td>QID126</td>
      <td>Which of the following describe you, if any? P...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>Accessibility</th>
      <td>QID124</td>
      <td>Which of the following describe you, if any? P...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>MentalHealth</th>
      <td>QID125</td>
      <td>Which of the following describe you, if any? P...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>S6</th>
      <td>QID131</td>
      <td>&lt;span style="font-size:22px;"&gt;&lt;strong&gt;Final Qu...</td>
      <td>False</td>
      <td>DB</td>
      <td>TB</td>
    </tr>
    <tr>
      <th>SurveyLength</th>
      <td>QID132</td>
      <td>How do you feel about the length of the survey...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>SurveyEase</th>
      <td>QID133</td>
      <td>How easy or difficult was this survey to compl...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Se accede al dato a través del campo 'Country'
schema_datos.loc['Country', 'question']
```




    'Where do you live? <span style="font-weight: bolder;">*</span>'




```python
# Ordenar los datos: ascendente
schema_datos.sort_index()
# Ordenar los datos: descendente
# schema_datos.sort_index(ascending=False)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>qid</th>
      <th>question</th>
      <th>force_resp</th>
      <th>type</th>
      <th>selector</th>
    </tr>
    <tr>
      <th>qname</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Accessibility</th>
      <td>QID124</td>
      <td>Which of the following describe you, if any? P...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>Age</th>
      <td>QID127</td>
      <td>What is your age?</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>Age1stCode</th>
      <td>QID149</td>
      <td>At what age did you write your first line of c...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>CompFreq</th>
      <td>QID52</td>
      <td>Is that compensation weekly, monthly, or yearly?</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>CompTotal</th>
      <td>QID51</td>
      <td>What is your current total compensation (salar...</td>
      <td>False</td>
      <td>TE</td>
      <td>SL</td>
    </tr>
    <tr>
      <th>Country</th>
      <td>QID6</td>
      <td>Where do you live? &lt;span style="font-weight: b...</td>
      <td>True</td>
      <td>MC</td>
      <td>DL</td>
    </tr>
    <tr>
      <th>Currency</th>
      <td>QID50</td>
      <td>Which currency do you use day-to-day? If your ...</td>
      <td>True</td>
      <td>MC</td>
      <td>SB</td>
    </tr>
    <tr>
      <th>Database</th>
      <td>QID262</td>
      <td>Which &lt;b&gt;database environments &lt;/b&gt;have you do...</td>
      <td>False</td>
      <td>Matrix</td>
      <td>Likert</td>
    </tr>
    <tr>
      <th>DevType</th>
      <td>QID31</td>
      <td>Which of the following describes your current ...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>EdLevel</th>
      <td>QID25</td>
      <td>Which of the following best describes the high...</td>
      <td>False</td>
      <td>MC</td>
      <td>SAVR</td>
    </tr>
    <tr>
      <th>Employment</th>
      <td>QID24</td>
      <td>Which of the following best describes your cur...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>Ethnicity</th>
      <td>QID126</td>
      <td>Which of the following describe you, if any? P...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>Gender</th>
      <td>QID122</td>
      <td>Which of the following describe you, if any? P...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>Language</th>
      <td>QID233</td>
      <td>Which &lt;b&gt;programming, scripting, and markup la...</td>
      <td>False</td>
      <td>Matrix</td>
      <td>Likert</td>
    </tr>
    <tr>
      <th>LearnCode</th>
      <td>QID276</td>
      <td>How did you learn to code? Select all that apply.</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>MainBranch</th>
      <td>QID2</td>
      <td>Which of the following options best describes ...</td>
      <td>True</td>
      <td>MC</td>
      <td>SAVR</td>
    </tr>
    <tr>
      <th>MentalHealth</th>
      <td>QID125</td>
      <td>Which of the following describe you, if any? P...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>MetaInfo</th>
      <td>QID12</td>
      <td>Browser Meta Info</td>
      <td>False</td>
      <td>Meta</td>
      <td>Browser</td>
    </tr>
    <tr>
      <th>MiscTech</th>
      <td>QID265</td>
      <td>Which &lt;b&gt;other frameworks and libraries&lt;/b&gt; ha...</td>
      <td>False</td>
      <td>Matrix</td>
      <td>Likert</td>
    </tr>
    <tr>
      <th>NEWCollabTools</th>
      <td>QID274</td>
      <td>Which &lt;strong&gt;development environments&lt;/strong...</td>
      <td>False</td>
      <td>Matrix</td>
      <td>Likert</td>
    </tr>
    <tr>
      <th>NEWOtherComms</th>
      <td>QID267</td>
      <td>Are you a member of any other online developer...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>NEWOtherCommsNames</th>
      <td>QID268</td>
      <td>Please name up to 5 other online developer com...</td>
      <td>False</td>
      <td>Matrix</td>
      <td>Likert</td>
    </tr>
    <tr>
      <th>NEWSOSites</th>
      <td>QID266</td>
      <td>Which of the following Stack Overflow sites ha...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>NEWStuck</th>
      <td>QID243</td>
      <td>What do you do when you get stuck on a problem...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>OpSys</th>
      <td>QID71</td>
      <td>What is the primary operating system in which ...</td>
      <td>False</td>
      <td>MC</td>
      <td>SAVR</td>
    </tr>
    <tr>
      <th>OrgSize</th>
      <td>QID29</td>
      <td>Approximately how many people are employed by ...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>Platform</th>
      <td>QID263</td>
      <td>Which &lt;b&gt;cloud platforms&lt;/b&gt; have you done ext...</td>
      <td>False</td>
      <td>Matrix</td>
      <td>Likert</td>
    </tr>
    <tr>
      <th>S0</th>
      <td>QID16</td>
      <td>&lt;div&gt;&lt;span style="font-size:19px;"&gt;&lt;strong&gt;Hel...</td>
      <td>False</td>
      <td>DB</td>
      <td>TB</td>
    </tr>
    <tr>
      <th>S1</th>
      <td>QID1</td>
      <td>&lt;span style="font-size:22px; font-family: aria...</td>
      <td>False</td>
      <td>DB</td>
      <td>TB</td>
    </tr>
    <tr>
      <th>S2</th>
      <td>QID190</td>
      <td>&lt;span style="font-size:22px; font-family: aria...</td>
      <td>False</td>
      <td>DB</td>
      <td>TB</td>
    </tr>
    <tr>
      <th>S3</th>
      <td>QID61</td>
      <td>&lt;span style="font-size:22px; font-family: aria...</td>
      <td>False</td>
      <td>DB</td>
      <td>TB</td>
    </tr>
    <tr>
      <th>S4</th>
      <td>QID91</td>
      <td>&lt;span style="font-size:22px; font-family: aria...</td>
      <td>False</td>
      <td>DB</td>
      <td>TB</td>
    </tr>
    <tr>
      <th>S5</th>
      <td>QID121</td>
      <td>&lt;span style="font-size:22px; font-family: aria...</td>
      <td>False</td>
      <td>DB</td>
      <td>TB</td>
    </tr>
    <tr>
      <th>S6</th>
      <td>QID131</td>
      <td>&lt;span style="font-size:22px;"&gt;&lt;strong&gt;Final Qu...</td>
      <td>False</td>
      <td>DB</td>
      <td>TB</td>
    </tr>
    <tr>
      <th>SOAccount</th>
      <td>QID101</td>
      <td>Do you have a Stack Overflow account?</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>SOComm</th>
      <td>QID106</td>
      <td>Do you consider yourself a member of the Stack...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>SOPartFreq</th>
      <td>QID102</td>
      <td>How frequently would you say you participate i...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>SOVisitFreq</th>
      <td>QID100</td>
      <td>How frequently would you say you visit Stack O...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>Sexuality</th>
      <td>QID136</td>
      <td>Which of the following describe you, if any? P...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>SurveyEase</th>
      <td>QID133</td>
      <td>How easy or difficult was this survey to compl...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>SurveyLength</th>
      <td>QID132</td>
      <td>How do you feel about the length of the survey...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>ToolsTech</th>
      <td>QID275</td>
      <td>Which &lt;strong&gt;tools&lt;/strong&gt; have you done ext...</td>
      <td>False</td>
      <td>Matrix</td>
      <td>Likert</td>
    </tr>
    <tr>
      <th>Trans</th>
      <td>QID153</td>
      <td>Do you identify as transgender?</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>UK_Country</th>
      <td>QID9</td>
      <td>In which part of the United Kingdom do you liv...</td>
      <td>False</td>
      <td>MC</td>
      <td>DL</td>
    </tr>
    <tr>
      <th>US_State</th>
      <td>QID7</td>
      <td>&lt;p&gt;In which state or territory of the USA do y...</td>
      <td>False</td>
      <td>MC</td>
      <td>DL</td>
    </tr>
    <tr>
      <th>Webframe</th>
      <td>QID264</td>
      <td>Which &lt;strong&gt;web frameworks &lt;/strong&gt;&lt;span st...</td>
      <td>False</td>
      <td>Matrix</td>
      <td>Likert</td>
    </tr>
    <tr>
      <th>YearsCode</th>
      <td>QID32</td>
      <td>Including any education, how many years have y...</td>
      <td>False</td>
      <td>MC</td>
      <td>DL</td>
    </tr>
    <tr>
      <th>YearsCodePro</th>
      <td>QID34</td>
      <td>NOT including education, how many years have y...</td>
      <td>False</td>
      <td>MC</td>
      <td>DL</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Muestra todos los registros que cumplen con el criterio
filtro = datos['Country'] == 'Spain'
```


```python
schema_datos
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>qid</th>
      <th>question</th>
      <th>force_resp</th>
      <th>type</th>
      <th>selector</th>
    </tr>
    <tr>
      <th>qname</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>S0</th>
      <td>QID16</td>
      <td>&lt;div&gt;&lt;span style="font-size:19px;"&gt;&lt;strong&gt;Hel...</td>
      <td>False</td>
      <td>DB</td>
      <td>TB</td>
    </tr>
    <tr>
      <th>MetaInfo</th>
      <td>QID12</td>
      <td>Browser Meta Info</td>
      <td>False</td>
      <td>Meta</td>
      <td>Browser</td>
    </tr>
    <tr>
      <th>S1</th>
      <td>QID1</td>
      <td>&lt;span style="font-size:22px; font-family: aria...</td>
      <td>False</td>
      <td>DB</td>
      <td>TB</td>
    </tr>
    <tr>
      <th>MainBranch</th>
      <td>QID2</td>
      <td>Which of the following options best describes ...</td>
      <td>True</td>
      <td>MC</td>
      <td>SAVR</td>
    </tr>
    <tr>
      <th>Employment</th>
      <td>QID24</td>
      <td>Which of the following best describes your cur...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>Country</th>
      <td>QID6</td>
      <td>Where do you live? &lt;span style="font-weight: b...</td>
      <td>True</td>
      <td>MC</td>
      <td>DL</td>
    </tr>
    <tr>
      <th>US_State</th>
      <td>QID7</td>
      <td>&lt;p&gt;In which state or territory of the USA do y...</td>
      <td>False</td>
      <td>MC</td>
      <td>DL</td>
    </tr>
    <tr>
      <th>UK_Country</th>
      <td>QID9</td>
      <td>In which part of the United Kingdom do you liv...</td>
      <td>False</td>
      <td>MC</td>
      <td>DL</td>
    </tr>
    <tr>
      <th>S2</th>
      <td>QID190</td>
      <td>&lt;span style="font-size:22px; font-family: aria...</td>
      <td>False</td>
      <td>DB</td>
      <td>TB</td>
    </tr>
    <tr>
      <th>EdLevel</th>
      <td>QID25</td>
      <td>Which of the following best describes the high...</td>
      <td>False</td>
      <td>MC</td>
      <td>SAVR</td>
    </tr>
    <tr>
      <th>Age1stCode</th>
      <td>QID149</td>
      <td>At what age did you write your first line of c...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>LearnCode</th>
      <td>QID276</td>
      <td>How did you learn to code? Select all that apply.</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>YearsCode</th>
      <td>QID32</td>
      <td>Including any education, how many years have y...</td>
      <td>False</td>
      <td>MC</td>
      <td>DL</td>
    </tr>
    <tr>
      <th>YearsCodePro</th>
      <td>QID34</td>
      <td>NOT including education, how many years have y...</td>
      <td>False</td>
      <td>MC</td>
      <td>DL</td>
    </tr>
    <tr>
      <th>DevType</th>
      <td>QID31</td>
      <td>Which of the following describes your current ...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>OrgSize</th>
      <td>QID29</td>
      <td>Approximately how many people are employed by ...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>Currency</th>
      <td>QID50</td>
      <td>Which currency do you use day-to-day? If your ...</td>
      <td>True</td>
      <td>MC</td>
      <td>SB</td>
    </tr>
    <tr>
      <th>CompTotal</th>
      <td>QID51</td>
      <td>What is your current total compensation (salar...</td>
      <td>False</td>
      <td>TE</td>
      <td>SL</td>
    </tr>
    <tr>
      <th>CompFreq</th>
      <td>QID52</td>
      <td>Is that compensation weekly, monthly, or yearly?</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>S3</th>
      <td>QID61</td>
      <td>&lt;span style="font-size:22px; font-family: aria...</td>
      <td>False</td>
      <td>DB</td>
      <td>TB</td>
    </tr>
    <tr>
      <th>Language</th>
      <td>QID233</td>
      <td>Which &lt;b&gt;programming, scripting, and markup la...</td>
      <td>False</td>
      <td>Matrix</td>
      <td>Likert</td>
    </tr>
    <tr>
      <th>Database</th>
      <td>QID262</td>
      <td>Which &lt;b&gt;database environments &lt;/b&gt;have you do...</td>
      <td>False</td>
      <td>Matrix</td>
      <td>Likert</td>
    </tr>
    <tr>
      <th>Platform</th>
      <td>QID263</td>
      <td>Which &lt;b&gt;cloud platforms&lt;/b&gt; have you done ext...</td>
      <td>False</td>
      <td>Matrix</td>
      <td>Likert</td>
    </tr>
    <tr>
      <th>Webframe</th>
      <td>QID264</td>
      <td>Which &lt;strong&gt;web frameworks &lt;/strong&gt;&lt;span st...</td>
      <td>False</td>
      <td>Matrix</td>
      <td>Likert</td>
    </tr>
    <tr>
      <th>MiscTech</th>
      <td>QID265</td>
      <td>Which &lt;b&gt;other frameworks and libraries&lt;/b&gt; ha...</td>
      <td>False</td>
      <td>Matrix</td>
      <td>Likert</td>
    </tr>
    <tr>
      <th>ToolsTech</th>
      <td>QID275</td>
      <td>Which &lt;strong&gt;tools&lt;/strong&gt; have you done ext...</td>
      <td>False</td>
      <td>Matrix</td>
      <td>Likert</td>
    </tr>
    <tr>
      <th>NEWCollabTools</th>
      <td>QID274</td>
      <td>Which &lt;strong&gt;development environments&lt;/strong...</td>
      <td>False</td>
      <td>Matrix</td>
      <td>Likert</td>
    </tr>
    <tr>
      <th>OpSys</th>
      <td>QID71</td>
      <td>What is the primary operating system in which ...</td>
      <td>False</td>
      <td>MC</td>
      <td>SAVR</td>
    </tr>
    <tr>
      <th>NEWStuck</th>
      <td>QID243</td>
      <td>What do you do when you get stuck on a problem...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>S4</th>
      <td>QID91</td>
      <td>&lt;span style="font-size:22px; font-family: aria...</td>
      <td>False</td>
      <td>DB</td>
      <td>TB</td>
    </tr>
    <tr>
      <th>NEWSOSites</th>
      <td>QID266</td>
      <td>Which of the following Stack Overflow sites ha...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>SOVisitFreq</th>
      <td>QID100</td>
      <td>How frequently would you say you visit Stack O...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>SOAccount</th>
      <td>QID101</td>
      <td>Do you have a Stack Overflow account?</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>SOPartFreq</th>
      <td>QID102</td>
      <td>How frequently would you say you participate i...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>SOComm</th>
      <td>QID106</td>
      <td>Do you consider yourself a member of the Stack...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>NEWOtherComms</th>
      <td>QID267</td>
      <td>Are you a member of any other online developer...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>NEWOtherCommsNames</th>
      <td>QID268</td>
      <td>Please name up to 5 other online developer com...</td>
      <td>False</td>
      <td>Matrix</td>
      <td>Likert</td>
    </tr>
    <tr>
      <th>S5</th>
      <td>QID121</td>
      <td>&lt;span style="font-size:22px; font-family: aria...</td>
      <td>False</td>
      <td>DB</td>
      <td>TB</td>
    </tr>
    <tr>
      <th>Age</th>
      <td>QID127</td>
      <td>What is your age?</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>Gender</th>
      <td>QID122</td>
      <td>Which of the following describe you, if any? P...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>Trans</th>
      <td>QID153</td>
      <td>Do you identify as transgender?</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>Sexuality</th>
      <td>QID136</td>
      <td>Which of the following describe you, if any? P...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>Ethnicity</th>
      <td>QID126</td>
      <td>Which of the following describe you, if any? P...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>Accessibility</th>
      <td>QID124</td>
      <td>Which of the following describe you, if any? P...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>MentalHealth</th>
      <td>QID125</td>
      <td>Which of the following describe you, if any? P...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>S6</th>
      <td>QID131</td>
      <td>&lt;span style="font-size:22px;"&gt;&lt;strong&gt;Final Qu...</td>
      <td>False</td>
      <td>DB</td>
      <td>TB</td>
    </tr>
    <tr>
      <th>SurveyLength</th>
      <td>QID132</td>
      <td>How do you feel about the length of the survey...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
    <tr>
      <th>SurveyEase</th>
      <td>QID133</td>
      <td>How easy or difficult was this survey to compl...</td>
      <td>False</td>
      <td>MC</td>
      <td>MAVR</td>
    </tr>
  </tbody>
</table>
</div>




```python
datos[filtro]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ResponseId</th>
      <th>MainBranch</th>
      <th>Employment</th>
      <th>Country</th>
      <th>US_State</th>
      <th>UK_Country</th>
      <th>EdLevel</th>
      <th>Age1stCode</th>
      <th>LearnCode</th>
      <th>YearsCode</th>
      <th>YearsCodePro</th>
      <th>DevType</th>
      <th>OrgSize</th>
      <th>Currency</th>
      <th>CompTotal</th>
      <th>CompFreq</th>
      <th>LanguageHaveWorkedWith</th>
      <th>LanguageWantToWorkWith</th>
      <th>DatabaseHaveWorkedWith</th>
      <th>DatabaseWantToWorkWith</th>
      <th>PlatformHaveWorkedWith</th>
      <th>PlatformWantToWorkWith</th>
      <th>WebframeHaveWorkedWith</th>
      <th>WebframeWantToWorkWith</th>
      <th>MiscTechHaveWorkedWith</th>
      <th>MiscTechWantToWorkWith</th>
      <th>ToolsTechHaveWorkedWith</th>
      <th>ToolsTechWantToWorkWith</th>
      <th>NEWCollabToolsHaveWorkedWith</th>
      <th>NEWCollabToolsWantToWorkWith</th>
      <th>OpSys</th>
      <th>NEWStuck</th>
      <th>NEWSOSites</th>
      <th>SOVisitFreq</th>
      <th>SOAccount</th>
      <th>SOPartFreq</th>
      <th>SOComm</th>
      <th>NEWOtherComms</th>
      <th>Age</th>
      <th>Gender</th>
      <th>Trans</th>
      <th>Sexuality</th>
      <th>Ethnicity</th>
      <th>Accessibility</th>
      <th>MentalHealth</th>
      <th>SurveyLength</th>
      <th>SurveyEase</th>
      <th>ConvertedCompYearly</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>11</th>
      <td>12</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>Spain</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>12</td>
      <td>5</td>
      <td>Developer, back-end</td>
      <td>10 to 19 employees</td>
      <td>EUR European Euro</td>
      <td>43000.0</td>
      <td>Yearly</td>
      <td>Bash/Shell;HTML/CSS;JavaScript;Node.js;SQL;Typ...</td>
      <td>C++;Clojure;JavaScript;Node.js;Rust;SQL;TypeSc...</td>
      <td>PostgreSQL</td>
      <td>MongoDB;PostgreSQL;Redis</td>
      <td>AWS</td>
      <td>NaN</td>
      <td>Express;React.js;Vue.js</td>
      <td>Express;Vue.js</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Git</td>
      <td>Git</td>
      <td>Atom</td>
      <td>Atom</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>Less than once per month or monthly</td>
      <td>Yes, somewhat</td>
      <td>Yes</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent;Hispanic or Latin...</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Too long</td>
      <td>Easy</td>
      <td>46482.0</td>
    </tr>
    <tr>
      <th>68</th>
      <td>69</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>Spain</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>11 - 17 years</td>
      <td>School</td>
      <td>20</td>
      <td>10</td>
      <td>Developer, back-end</td>
      <td>10,000 or more employees</td>
      <td>EUR European Euro</td>
      <td>54000.0</td>
      <td>Yearly</td>
      <td>Bash/Shell;JavaScript;Node.js;TypeScript</td>
      <td>JavaScript;Node.js;Python;TypeScript</td>
      <td>DynamoDB</td>
      <td>DynamoDB;Firebase</td>
      <td>AWS</td>
      <td>AWS;Microsoft Azure</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Terraform</td>
      <td>Terraform</td>
      <td>Notepad++;Vim;Visual Studio Code</td>
      <td>Vim;Visual Studio Code</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>A few times per week</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>NaN</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>58373.0</td>
    </tr>
    <tr>
      <th>79</th>
      <td>80</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>Spain</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Associate degree (A.A., A.S., etc.)</td>
      <td>11 - 17 years</td>
      <td>Online Courses or Certification</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Developer, back-end</td>
      <td>100 to 499 employees</td>
      <td>EUR European Euro</td>
      <td>20000.0</td>
      <td>Yearly</td>
      <td>C#;Go;Java;Python</td>
      <td>C++;Clojure;Go;Rust</td>
      <td>Elasticsearch;Firebase;MariaDB;MySQL;PostgreSQ...</td>
      <td>PostgreSQL</td>
      <td>AWS;Google Cloud Platform;Heroku</td>
      <td>AWS;Heroku</td>
      <td>Angular;Django;FastAPI;Flask</td>
      <td>React.js</td>
      <td>Flutter</td>
      <td>NumPy;Pandas</td>
      <td>Docker;Git;Terraform;Unity 3D</td>
      <td>Deno;Kubernetes;Yarn</td>
      <td>Android Studio;IntelliJ;NetBeans;Visual Studio...</td>
      <td>Emacs;Neovim</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>No, not at all</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Hispanic or Latino/a/x</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>21620.0</td>
    </tr>
    <tr>
      <th>108</th>
      <td>109</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>Spain</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Associate degree (A.A., A.S., etc.)</td>
      <td>25 - 34 years</td>
      <td>Coding Bootcamp;School</td>
      <td>10</td>
      <td>8</td>
      <td>Developer, full-stack;Developer, back-end;Prod...</td>
      <td>100 to 499 employees</td>
      <td>EUR European Euro</td>
      <td>36000.0</td>
      <td>Yearly</td>
      <td>HTML/CSS;Java;JavaScript;Node.js;Python;SQL</td>
      <td>HTML/CSS;Java;JavaScript;Node.js;Python;SQL;Ty...</td>
      <td>Microsoft SQL Server;MongoDB;PostgreSQL</td>
      <td>MongoDB;PostgreSQL</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>jQuery;Spring</td>
      <td>Angular;Angular.js;Express;Spring</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>Ansible;Docker;Git</td>
      <td>Eclipse;Notepad++</td>
      <td>Eclipse;Notepad++</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
      <td>Stack Overflow</td>
      <td>Multiple times per day</td>
      <td>Yes</td>
      <td>A few times per week</td>
      <td>Yes, definitely</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>38915.0</td>
    </tr>
    <tr>
      <th>267</th>
      <td>268</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>Spain</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other (please specify):</td>
      <td>27</td>
      <td>13</td>
      <td>Developer, full-stack</td>
      <td>1,000 to 4,999 employees</td>
      <td>EUR European Euro</td>
      <td>NaN</td>
      <td>Monthly</td>
      <td>HTML/CSS;Java;JavaScript;Node.js;SQL</td>
      <td>HTML/CSS;Java;JavaScript;Node.js;Python;SQL</td>
      <td>MongoDB;Oracle</td>
      <td>MongoDB;Oracle</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Express;jQuery;Spring</td>
      <td>Express;jQuery;Spring</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Eclipse;Notepad++</td>
      <td>Eclipse;Notepad++</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Google it;Do other work a...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>A few times per month or weekly</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>83097</th>
      <td>83098</td>
      <td>I am a student who is learning to code</td>
      <td>Student, part-time</td>
      <td>Spain</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Secondary school (e.g. American high school, G...</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>3</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>HTML/CSS;Java;SQL</td>
      <td>C#;HTML/CSS;Java;JavaScript;Kotlin;PHP;Python;SQL</td>
      <td>MariaDB;MySQL</td>
      <td>MySQL;SQLite</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Git</td>
      <td>Git;Unity 3D</td>
      <td>Eclipse;Notepad++</td>
      <td>Android Studio;Eclipse;Notepad++;Visual Studio...</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>Yes, somewhat</td>
      <td>Yes</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>83133</th>
      <td>83134</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>Spain</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>8</td>
      <td>3</td>
      <td>Engineer, data;Data scientist or machine learn...</td>
      <td>20 to 99 employees</td>
      <td>EUR European Euro</td>
      <td>50000.0</td>
      <td>Yearly</td>
      <td>C;C++;Go;HTML/CSS;JavaScript;Node.js;Python</td>
      <td>C;C++;Go;Haskell;HTML/CSS;Python;Rust;Scala</td>
      <td>Cassandra;PostgreSQL;Redis;SQLite</td>
      <td>Cassandra;PostgreSQL;Redis;SQLite</td>
      <td>AWS;Google Cloud Platform</td>
      <td>AWS;Google Cloud Platform</td>
      <td>Flask;React.js</td>
      <td>FastAPI;Flask;React.js</td>
      <td>NumPy;Torch/PyTorch</td>
      <td>Apache Spark;NumPy;Torch/PyTorch</td>
      <td>Docker;Git;Kubernetes;Terraform</td>
      <td>Docker;Git;Kubernetes;Puppet;Terraform</td>
      <td>Emacs;Vim;Visual Studio Code</td>
      <td>Emacs;Vim;Visual Studio Code</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>Yes</td>
      <td>Less than once per month or monthly</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>I have a concentration and/or memory disorder ...</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>54049.0</td>
    </tr>
    <tr>
      <th>83137</th>
      <td>83138</td>
      <td>I am a developer by profession</td>
      <td>Not employed, but looking for work</td>
      <td>Spain</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Some college/university study without earning ...</td>
      <td>5 - 10 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>30</td>
      <td>NaN</td>
      <td>Developer, mobile;Developer, front-end;Develop...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bash/Shell;F#;HTML/CSS;Java;JavaScript;Kotlin;...</td>
      <td>F#;HTML/CSS;Kotlin;TypeScript</td>
      <td>Firebase;MySQL;Redis;SQLite</td>
      <td>Firebase;MySQL;Redis;SQLite</td>
      <td>AWS</td>
      <td>NaN</td>
      <td>jQuery;Svelte;Symfony;Vue.js</td>
      <td>Svelte;Vue.js</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>Deno;Docker;Git</td>
      <td>Android Studio;Atom;NetBeans;Notepad++;Sublime...</td>
      <td>Android Studio;Visual Studio Code</td>
      <td>Linux-based</td>
      <td>Visit Stack Overflow;Google it;Do other work a...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>Yes</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>No, not really</td>
      <td>No</td>
      <td>35-44 years old</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>83159</th>
      <td>83160</td>
      <td>I am a developer by profession</td>
      <td>Student, full-time</td>
      <td>Spain</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc)</td>
      <td>10</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Assembly;Bash/Shell;C;C#;C++;HTML/CSS;Java;Jav...</td>
      <td>Assembly;Bash/Shell;C;C#;C++;Clojure;Crystal;E...</td>
      <td>Cassandra;MariaDB;MongoDB;MySQL;SQLite</td>
      <td>Couchbase;Elasticsearch;MongoDB;MySQL;PostgreS...</td>
      <td>AWS</td>
      <td>AWS</td>
      <td>Express;Flask;React.js</td>
      <td>Angular;Express;Flask;Gatsby;jQuery;Laravel;Re...</td>
      <td>.NET Framework;Apache Spark;Keras;NumPy;Pandas...</td>
      <td>.NET Framework;Apache Spark;Cordova;Flutter;Ke...</td>
      <td>Docker;Git;Kubernetes;Unity 3D;Unreal Engine</td>
      <td>Ansible;Docker;Git;Unity 3D;Xamarin</td>
      <td>Android Studio;Atom;Eclipse;IPython/Jupyter;Ne...</td>
      <td>Atom;IPython/Jupyter;Notepad++;Visual Studio Code</td>
      <td>Linux-based</td>
      <td>Go for a walk or other physical activity;Play ...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>A few times per month or weekly</td>
      <td>Yes, definitely</td>
      <td>Yes</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>83313</th>
      <td>83314</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>Spain</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Professional degree (JD, MD, etc.)</td>
      <td>11 - 17 years</td>
      <td>Coding Bootcamp;Other online resources (ex: vi...</td>
      <td>10</td>
      <td>5</td>
      <td>Developer, front-end;Developer, full-stack;Dev...</td>
      <td>2 to 9 employees</td>
      <td>EUR European Euro</td>
      <td>2300.0</td>
      <td>Monthly</td>
      <td>Elixir;JavaScript;Ruby</td>
      <td>Elixir;Ruby</td>
      <td>Firebase;PostgreSQL;Redis</td>
      <td>Firebase;PostgreSQL;Redis</td>
      <td>AWS;DigitalOcean;Google Cloud Platform</td>
      <td>AWS;DigitalOcean;Google Cloud Platform</td>
      <td>jQuery;Ruby on Rails</td>
      <td>Django;Ruby on Rails;Vue.js</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Ansible;Docker;Git;Yarn</td>
      <td>Ansible;Docker;Git;Kubernetes;Yarn</td>
      <td>RubyMine;Visual Studio Code</td>
      <td>Visual Studio Code</td>
      <td>MacOS</td>
      <td>Visit Stack Overflow;Google it</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Multiple times per day</td>
      <td>Yes</td>
      <td>Less than once per month or monthly</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Hispanic or Latino/a/x</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>29832.0</td>
    </tr>
  </tbody>
</table>
<p>1485 rows × 48 columns</p>
</div>




```python
# Datos filtrados usando loc
datos.loc[filtro, 'Employment']
```




    11                                      Employed full-time
    68                                      Employed full-time
    79                                      Employed full-time
    108                                     Employed full-time
    267                                     Employed full-time
                                   ...                        
    83097                                   Student, part-time
    83133                                   Employed full-time
    83137                   Not employed, but looking for work
    83159                                   Student, full-time
    83313    Independent contractor, freelancer, or self-em...
    Name: Employment, Length: 1485, dtype: object




```python
prog_python = (datos['Country'] == 'Spain') & (datos['LanguageHaveWorkedWith'] == 'Python')
```


```python
datos.loc[prog_python]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ResponseId</th>
      <th>MainBranch</th>
      <th>Employment</th>
      <th>Country</th>
      <th>US_State</th>
      <th>UK_Country</th>
      <th>EdLevel</th>
      <th>Age1stCode</th>
      <th>LearnCode</th>
      <th>YearsCode</th>
      <th>YearsCodePro</th>
      <th>DevType</th>
      <th>OrgSize</th>
      <th>Currency</th>
      <th>CompTotal</th>
      <th>CompFreq</th>
      <th>LanguageHaveWorkedWith</th>
      <th>LanguageWantToWorkWith</th>
      <th>DatabaseHaveWorkedWith</th>
      <th>DatabaseWantToWorkWith</th>
      <th>PlatformHaveWorkedWith</th>
      <th>PlatformWantToWorkWith</th>
      <th>WebframeHaveWorkedWith</th>
      <th>WebframeWantToWorkWith</th>
      <th>MiscTechHaveWorkedWith</th>
      <th>MiscTechWantToWorkWith</th>
      <th>ToolsTechHaveWorkedWith</th>
      <th>ToolsTechWantToWorkWith</th>
      <th>NEWCollabToolsHaveWorkedWith</th>
      <th>NEWCollabToolsWantToWorkWith</th>
      <th>OpSys</th>
      <th>NEWStuck</th>
      <th>NEWSOSites</th>
      <th>SOVisitFreq</th>
      <th>SOAccount</th>
      <th>SOPartFreq</th>
      <th>SOComm</th>
      <th>NEWOtherComms</th>
      <th>Age</th>
      <th>Gender</th>
      <th>Trans</th>
      <th>Sexuality</th>
      <th>Ethnicity</th>
      <th>Accessibility</th>
      <th>MentalHealth</th>
      <th>SurveyLength</th>
      <th>SurveyEase</th>
      <th>ConvertedCompYearly</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>503</th>
      <td>504</td>
      <td>I am not primarily a developer, but I write co...</td>
      <td>Employed full-time</td>
      <td>Spain</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Other doctoral degree (Ph.D., Ed.D., etc.)</td>
      <td>11 - 17 years</td>
      <td>Friend or family member;Other (please specify):</td>
      <td>25</td>
      <td>20</td>
      <td>Data scientist or machine learning specialist</td>
      <td>1,000 to 4,999 employees</td>
      <td>EUR European Euro</td>
      <td>60000.0</td>
      <td>Yearly</td>
      <td>Python</td>
      <td>Julia;Kotlin;Python;R</td>
      <td>MariaDB;PostgreSQL</td>
      <td>MariaDB;PostgreSQL;Redis</td>
      <td>AWS</td>
      <td>AWS</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NumPy;Pandas</td>
      <td>Keras;NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>Docker;Git</td>
      <td>Docker;Git</td>
      <td>PyCharm;Vim</td>
      <td>PyCharm;Vim</td>
      <td>Linux-based</td>
      <td>Visit Stack Overflow;Google it</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>Yes</td>
      <td>Less than once per month or monthly</td>
      <td>Neutral</td>
      <td>No</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>NaN</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>64859.0</td>
    </tr>
    <tr>
      <th>2746</th>
      <td>2747</td>
      <td>I am not primarily a developer, but I write co...</td>
      <td>Employed full-time</td>
      <td>Spain</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>13</td>
      <td>5</td>
      <td>Academic researcher;Student</td>
      <td>10 to 19 employees</td>
      <td>EUR European Euro</td>
      <td>1200.0</td>
      <td>Monthly</td>
      <td>Python</td>
      <td>Python;Rust</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Git</td>
      <td>Docker;Git</td>
      <td>IPython/Jupyter;PyCharm</td>
      <td>IPython/Jupyter;PyCharm</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Multiple times per day</td>
      <td>Yes</td>
      <td>Multiple times per day</td>
      <td>Yes, definitely</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>15564.0</td>
    </tr>
    <tr>
      <th>4033</th>
      <td>4034</td>
      <td>I am a student who is learning to code</td>
      <td>Student, full-time</td>
      <td>Spain</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Python</td>
      <td>Bash/Shell;Python</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Google Cloud Platform</td>
      <td>Google Cloud Platform</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Git</td>
      <td>Git;Unity 3D</td>
      <td>Visual Studio;Visual Studio Code</td>
      <td>Visual Studio;Visual Studio Code</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
      <td>Stack Overflow</td>
      <td>A few times per month or weekly</td>
      <td>Yes</td>
      <td>Less than once per month or monthly</td>
      <td>Neutral</td>
      <td>No</td>
      <td>Under 18 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent;Hispanic or Latin...</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>8433</th>
      <td>8434</td>
      <td>I am a student who is learning to code</td>
      <td>Student, part-time</td>
      <td>Spain</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Secondary school (e.g. American high school, G...</td>
      <td>11 - 17 years</td>
      <td>Coding Bootcamp;Other online resources (ex: vi...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Python</td>
      <td>C;Go;Python</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Atom;Visual Studio Code</td>
      <td>NaN</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Google it;Watch help / tu...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per month or weekly</td>
      <td>Yes</td>
      <td>A few times per month or weekly</td>
      <td>Yes, somewhat</td>
      <td>Yes</td>
      <td>Under 18 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>18022</th>
      <td>18023</td>
      <td>I am not primarily a developer, but I write co...</td>
      <td>Employed full-time</td>
      <td>Spain</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>18 - 24 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>7</td>
      <td>Less than 1 year</td>
      <td>Academic researcher;Scientist</td>
      <td>20 to 99 employees</td>
      <td>EUR European Euro</td>
      <td>35000.0</td>
      <td>Yearly</td>
      <td>Python</td>
      <td>Python</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Google Cloud Platform</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NumPy</td>
      <td>NumPy;Pandas</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Atom;Notepad++;Vim</td>
      <td>Atom;Vim</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>Less than once per month or monthly</td>
      <td>No, not really</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Hispanic or Latino/a/x</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>37834.0</td>
    </tr>
    <tr>
      <th>19666</th>
      <td>19667</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>Spain</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc)</td>
      <td>7</td>
      <td>3</td>
      <td>Developer, back-end</td>
      <td>100 to 499 employees</td>
      <td>EUR European Euro</td>
      <td>31000.0</td>
      <td>Yearly</td>
      <td>Python</td>
      <td>Python</td>
      <td>MySQL</td>
      <td>MySQL</td>
      <td>AWS</td>
      <td>Google Cloud Platform</td>
      <td>Flask</td>
      <td>Django;Flask;React.js</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>Docker;Git;Kubernetes</td>
      <td>IPython/Jupyter;PyCharm</td>
      <td>IPython/Jupyter;PyCharm</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>A few times per week</td>
      <td>Yes</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>33510.0</td>
    </tr>
    <tr>
      <th>23070</th>
      <td>23071</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>Spain</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>11 - 17 years</td>
      <td>School</td>
      <td>9</td>
      <td>2</td>
      <td>Engineer, data</td>
      <td>100 to 499 employees</td>
      <td>EUR European Euro</td>
      <td>1700.0</td>
      <td>Monthly</td>
      <td>Python</td>
      <td>C++;Python;R</td>
      <td>MongoDB</td>
      <td>NaN</td>
      <td>Google Cloud Platform</td>
      <td>AWS;IBM Cloud or Watson</td>
      <td>Flask</td>
      <td>NaN</td>
      <td>Keras;NumPy;TensorFlow;Torch/PyTorch</td>
      <td>Torch/PyTorch</td>
      <td>Docker;Git</td>
      <td>Docker</td>
      <td>IPython/Jupyter;PyCharm</td>
      <td>IPython/Jupyter</td>
      <td>MacOS</td>
      <td>Go for a walk or other physical activity;Googl...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>No</td>
      <td>NaN</td>
      <td>No, not at all</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Woman</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>22056.0</td>
    </tr>
    <tr>
      <th>24391</th>
      <td>24392</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>Spain</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Other doctoral degree (Ph.D., Ed.D., etc.)</td>
      <td>11 - 17 years</td>
      <td>Books / Physical media</td>
      <td>20</td>
      <td>5</td>
      <td>Developer, back-end</td>
      <td>500 to 999 employees</td>
      <td>EUR European Euro</td>
      <td>86000.0</td>
      <td>Yearly</td>
      <td>Python</td>
      <td>Python</td>
      <td>MariaDB</td>
      <td>MariaDB;PostgreSQL</td>
      <td>AWS</td>
      <td>AWS</td>
      <td>Django;React.js;Svelte</td>
      <td>Django;React.js</td>
      <td>NumPy</td>
      <td>NumPy;Torch/PyTorch</td>
      <td>Git</td>
      <td>Git</td>
      <td>Vim</td>
      <td>Vim</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>Yes</td>
      <td>A few times per month or weekly</td>
      <td>No, not really</td>
      <td>No</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Hispanic or Latino/a/x</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>92964.0</td>
    </tr>
    <tr>
      <th>41991</th>
      <td>41992</td>
      <td>I am not primarily a developer, but I write co...</td>
      <td>Employed full-time</td>
      <td>Spain</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Other doctoral degree (Ph.D., Ed.D., etc.)</td>
      <td>18 - 24 years</td>
      <td>Other (please specify):</td>
      <td>14</td>
      <td>11</td>
      <td>Data scientist or machine learning specialist</td>
      <td>10 to 19 employees</td>
      <td>EUR European Euro</td>
      <td>35000.0</td>
      <td>Yearly</td>
      <td>Python</td>
      <td>Python</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>AWS</td>
      <td>AWS</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NumPy;Pandas;Torch/PyTorch</td>
      <td>NumPy;Pandas;Torch/PyTorch</td>
      <td>Docker;Git</td>
      <td>Docker;Git;Terraform</td>
      <td>PyCharm</td>
      <td>PyCharm</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>Yes</td>
      <td>A few times per month or weekly</td>
      <td>Yes, somewhat</td>
      <td>Yes</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>37834.0</td>
    </tr>
    <tr>
      <th>51907</th>
      <td>51908</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>Spain</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>5 - 10 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>20</td>
      <td>11</td>
      <td>Developer, back-end</td>
      <td>20 to 99 employees</td>
      <td>EUR European Euro</td>
      <td>45000.0</td>
      <td>Yearly</td>
      <td>Python</td>
      <td>C;Go;Rust</td>
      <td>MariaDB;MongoDB;Redis</td>
      <td>Elasticsearch;PostgreSQL;Redis</td>
      <td>Google Cloud Platform</td>
      <td>AWS;Google Cloud Platform</td>
      <td>Django</td>
      <td>Flask</td>
      <td>NumPy;Pandas</td>
      <td>NumPy;Torch/PyTorch</td>
      <td>Docker;Git</td>
      <td>Ansible;Docker;Git;Terraform</td>
      <td>Neovim;Vim</td>
      <td>Neovim</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>A few times per month or weekly</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Prefer not to say</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>Prefer not to say</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>48644.0</td>
    </tr>
    <tr>
      <th>54100</th>
      <td>54101</td>
      <td>I am not primarily a developer, but I write co...</td>
      <td>Employed full-time</td>
      <td>Spain</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Other doctoral degree (Ph.D., Ed.D., etc.)</td>
      <td>11 - 17 years</td>
      <td>Books / Physical media</td>
      <td>35</td>
      <td>15</td>
      <td>Data scientist or machine learning specialist;...</td>
      <td>2 to 9 employees</td>
      <td>EUR European Euro</td>
      <td>3000.0</td>
      <td>Monthly</td>
      <td>Python</td>
      <td>Python</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NumPy;Pandas</td>
      <td>NumPy;Pandas</td>
      <td>Git</td>
      <td>Docker;Git</td>
      <td>Visual Studio Code</td>
      <td>Visual Studio Code</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Google it;Meditate</td>
      <td>Stack Overflow</td>
      <td>A few times per month or weekly</td>
      <td>Yes</td>
      <td>Less than once per month or monthly</td>
      <td>No, not really</td>
      <td>No</td>
      <td>45-54 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>38916.0</td>
    </tr>
    <tr>
      <th>54537</th>
      <td>54538</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>Spain</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Some college/university study without earning ...</td>
      <td>11 - 17 years</td>
      <td>School;Online Courses or Certification;Books /...</td>
      <td>17</td>
      <td>14</td>
      <td>Data scientist or machine learning specialist;...</td>
      <td>10 to 19 employees</td>
      <td>EUR European Euro</td>
      <td>3250.0</td>
      <td>Monthly</td>
      <td>Python</td>
      <td>Python</td>
      <td>PostgreSQL;SQLite</td>
      <td>PostgreSQL</td>
      <td>AWS</td>
      <td>AWS</td>
      <td>Django;React.js</td>
      <td>Django;React.js</td>
      <td>NumPy;Pandas</td>
      <td>NumPy;Pandas</td>
      <td>Docker;Git</td>
      <td>Docker;Git</td>
      <td>PyCharm;Vim</td>
      <td>PyCharm;Vim</td>
      <td>Linux-based</td>
      <td>Visit Stack Overflow;Google it</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>A few times per week</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Hispanic or Latino/a/x</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>42156.0</td>
    </tr>
    <tr>
      <th>55187</th>
      <td>55188</td>
      <td>I am a student who is learning to code</td>
      <td>Student, full-time</td>
      <td>Spain</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Primary/elementary school</td>
      <td>5 - 10 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>2</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Python</td>
      <td>Python</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NumPy</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Visual Studio Code</td>
      <td>Visual Studio Code</td>
      <td>Linux-based</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
      <td>Stack Overflow</td>
      <td>A few times per week</td>
      <td>Yes</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>Under 18 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent;I don't know;Hisp...</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>56851</th>
      <td>56852</td>
      <td>I am not primarily a developer, but I write co...</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>Spain</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>18 - 24 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>11</td>
      <td>6</td>
      <td>Other (please specify):;Data scientist or mach...</td>
      <td>2 to 9 employees</td>
      <td>EUR European Euro</td>
      <td>900.0</td>
      <td>Monthly</td>
      <td>Python</td>
      <td>Dart;JavaScript;Node.js;Python</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Django</td>
      <td>Django</td>
      <td>NumPy</td>
      <td>Flutter;NumPy;Torch/PyTorch</td>
      <td>Git</td>
      <td>Git</td>
      <td>Visual Studio Code</td>
      <td>Visual Studio Code</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
      <td>Stack Overflow</td>
      <td>A few times per week</td>
      <td>Yes</td>
      <td>Less than once per month or monthly</td>
      <td>Yes, definitely</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent;Hispanic or Latin...</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>11676.0</td>
    </tr>
    <tr>
      <th>58643</th>
      <td>58644</td>
      <td>I am not primarily a developer, but I write co...</td>
      <td>Employed full-time</td>
      <td>Spain</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>17</td>
      <td>9</td>
      <td>Academic researcher;Student</td>
      <td>1,000 to 4,999 employees</td>
      <td>EUR European Euro</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Python</td>
      <td>Go;Python</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Git</td>
      <td>Docker;Git;Kubernetes</td>
      <td>Atom;IntelliJ;IPython/Jupyter;PyCharm;Vim</td>
      <td>Atom;Vim</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Multiple times per day</td>
      <td>Yes</td>
      <td>Less than once per month or monthly</td>
      <td>No, not really</td>
      <td>Yes</td>
      <td>35-44 years old</td>
      <td>Woman</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Too long</td>
      <td>Easy</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>63396</th>
      <td>63397</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>Spain</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc)</td>
      <td>10</td>
      <td>3</td>
      <td>Engineer, data;Data scientist or machine learn...</td>
      <td>I don’t know</td>
      <td>EUR European Euro</td>
      <td>25000.0</td>
      <td>Yearly</td>
      <td>Python</td>
      <td>NaN</td>
      <td>MySQL</td>
      <td>NaN</td>
      <td>Google Cloud Platform</td>
      <td>NaN</td>
      <td>Flask</td>
      <td>NaN</td>
      <td>NumPy;Pandas</td>
      <td>NaN</td>
      <td>Git</td>
      <td>NaN</td>
      <td>IPython/Jupyter;Vim;Visual Studio Code</td>
      <td>NaN</td>
      <td>MacOS</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>Not sure/can't remember</td>
      <td>NaN</td>
      <td>Neutral</td>
      <td>Yes</td>
      <td>25-34 years old</td>
      <td>Woman</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent;Hispanic or Latin...</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>27025.0</td>
    </tr>
    <tr>
      <th>63685</th>
      <td>63686</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>Spain</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>18 - 24 years</td>
      <td>Colleague</td>
      <td>8</td>
      <td>3</td>
      <td>Developer, back-end;Academic researcher</td>
      <td>2 to 9 employees</td>
      <td>EUR European Euro</td>
      <td>NaN</td>
      <td>Monthly</td>
      <td>Python</td>
      <td>Python</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Keras;NumPy;Pandas;TensorFlow</td>
      <td>Keras;NumPy;Pandas;TensorFlow</td>
      <td>Git</td>
      <td>Git</td>
      <td>Emacs</td>
      <td>Emacs</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per month or weekly</td>
      <td>Not sure/can't remember</td>
      <td>NaN</td>
      <td>No, not at all</td>
      <td>Yes</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>66698</th>
      <td>66699</td>
      <td>I code primarily as a hobby</td>
      <td>Student, full-time</td>
      <td>Spain</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Secondary school (e.g. American high school, G...</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>2</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Python</td>
      <td>JavaScript;Python</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Visual Studio Code</td>
      <td>Visual Studio Code</td>
      <td>MacOS</td>
      <td>Visit Stack Overflow;Google it;Watch help / tu...</td>
      <td>Stack Overflow</td>
      <td>A few times per month or weekly</td>
      <td>No</td>
      <td>NaN</td>
      <td>Not sure</td>
      <td>No</td>
      <td>Under 18 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Gay or Lesbian</td>
      <td>White or of European descent;Hispanic or Latin...</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>66947</th>
      <td>66948</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>Spain</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Some college/university study without earning ...</td>
      <td>11 - 17 years</td>
      <td>Online Forum;Online Courses or Certification;B...</td>
      <td>20</td>
      <td>20</td>
      <td>Developer, desktop or enterprise applications;...</td>
      <td>100 to 499 employees</td>
      <td>EUR European Euro</td>
      <td>35000.0</td>
      <td>Yearly</td>
      <td>Python</td>
      <td>Go;Python;Rust</td>
      <td>PostgreSQL;SQLite</td>
      <td>PostgreSQL;SQLite</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>FastAPI;Flask</td>
      <td>FastAPI</td>
      <td>Qt</td>
      <td>Qt</td>
      <td>Git</td>
      <td>Git</td>
      <td>PyCharm;Visual Studio Code</td>
      <td>PyCharm;Visual Studio Code</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Google it;Watch help / tu...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>Less than once per month or monthly</td>
      <td>No, not really</td>
      <td>No</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>37834.0</td>
    </tr>
    <tr>
      <th>69700</th>
      <td>69701</td>
      <td>I am a student who is learning to code</td>
      <td>Student, full-time</td>
      <td>Spain</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Secondary school (e.g. American high school, G...</td>
      <td>5 - 10 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>Less than 1 year</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Python</td>
      <td>C++;Java;JavaScript;Python</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NumPy</td>
      <td>.NET Framework;.NET Core / .NET 5</td>
      <td>Unity 3D</td>
      <td>Unity 3D</td>
      <td>Android Studio;PyCharm;Visual Studio Code</td>
      <td>Visual Studio Code</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Google it;Watch help / tu...</td>
      <td>Stack Overflow</td>
      <td>A few times per month or weekly</td>
      <td>Yes</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>No, not really</td>
      <td>Yes</td>
      <td>Under 18 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Hispanic or Latino/a/x</td>
      <td>I am deaf / hard of hearing</td>
      <td>I have an anxiety disorder</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>73557</th>
      <td>73558</td>
      <td>I am not primarily a developer, but I write co...</td>
      <td>Employed full-time</td>
      <td>Spain</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>18 - 24 years</td>
      <td>Online Forum</td>
      <td>4</td>
      <td>4</td>
      <td>Engineer, data;Engineering manager</td>
      <td>100 to 499 employees</td>
      <td>EUR European Euro</td>
      <td>34500.0</td>
      <td>Yearly</td>
      <td>Python</td>
      <td>Python</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Pandas</td>
      <td>Pandas</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>PyCharm</td>
      <td>PyCharm</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>A few times per week</td>
      <td>Yes</td>
      <td>A few times per month or weekly</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>37294.0</td>
    </tr>
    <tr>
      <th>76104</th>
      <td>76105</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>Spain</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>18 - 24 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>6</td>
      <td>4</td>
      <td>Data scientist or machine learning specialist</td>
      <td>100 to 499 employees</td>
      <td>EUR European Euro</td>
      <td>24080.0</td>
      <td>Yearly</td>
      <td>Python</td>
      <td>C++;Haskell;Java;Kotlin;Python;R;Scala</td>
      <td>MariaDB;MySQL</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Keras;NumPy;Pandas;TensorFlow</td>
      <td>Apache Spark;Keras;NumPy;Pandas;TensorFlow;Tor...</td>
      <td>Git</td>
      <td>Git</td>
      <td>Visual Studio Code</td>
      <td>Vim;Visual Studio Code</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>Not sure/can't remember</td>
      <td>NaN</td>
      <td>No, not really</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Woman</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent;I don't know;Hisp...</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>26030.0</td>
    </tr>
    <tr>
      <th>79253</th>
      <td>79254</td>
      <td>I code primarily as a hobby</td>
      <td>Student, full-time</td>
      <td>Spain</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Something else</td>
      <td>5 - 10 years</td>
      <td>Coding Bootcamp;Other online resources (ex: vi...</td>
      <td>4</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Python</td>
      <td>C#</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>AWS</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Visual Studio</td>
      <td>Android Studio;Atom;Notepad++</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>Daily or almost daily</td>
      <td>No</td>
      <td>NaN</td>
      <td>No, not really</td>
      <td>No</td>
      <td>Under 18 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>82733</th>
      <td>82734</td>
      <td>I am a student who is learning to code</td>
      <td>Student, part-time</td>
      <td>Spain</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Secondary school (e.g. American high school, G...</td>
      <td>5 - 10 years</td>
      <td>Books / Physical media</td>
      <td>1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Python</td>
      <td>JavaScript</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Notepad++;Visual Studio</td>
      <td>NaN</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Google it;Watch help / tu...</td>
      <td>Stack Overflow</td>
      <td>A few times per week</td>
      <td>Yes</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>Not sure</td>
      <td>Yes</td>
      <td>NaN</td>
      <td>Man;Or, in your own words:</td>
      <td>No</td>
      <td>Bisexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>Prefer not to say</td>
      <td>Too long</td>
      <td>Easy</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
filtrar_paises = (datos['Country'] == 'Spain') | (datos['Country'] == 'France')
```


```python
datos.loc[filtrar_paises]
# Negación
# datos.loc[~filtrar_paises]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ResponseId</th>
      <th>MainBranch</th>
      <th>Employment</th>
      <th>Country</th>
      <th>US_State</th>
      <th>UK_Country</th>
      <th>EdLevel</th>
      <th>Age1stCode</th>
      <th>LearnCode</th>
      <th>YearsCode</th>
      <th>YearsCodePro</th>
      <th>DevType</th>
      <th>OrgSize</th>
      <th>Currency</th>
      <th>CompTotal</th>
      <th>CompFreq</th>
      <th>LanguageHaveWorkedWith</th>
      <th>LanguageWantToWorkWith</th>
      <th>DatabaseHaveWorkedWith</th>
      <th>DatabaseWantToWorkWith</th>
      <th>PlatformHaveWorkedWith</th>
      <th>PlatformWantToWorkWith</th>
      <th>WebframeHaveWorkedWith</th>
      <th>WebframeWantToWorkWith</th>
      <th>MiscTechHaveWorkedWith</th>
      <th>MiscTechWantToWorkWith</th>
      <th>ToolsTechHaveWorkedWith</th>
      <th>ToolsTechWantToWorkWith</th>
      <th>NEWCollabToolsHaveWorkedWith</th>
      <th>NEWCollabToolsWantToWorkWith</th>
      <th>OpSys</th>
      <th>NEWStuck</th>
      <th>NEWSOSites</th>
      <th>SOVisitFreq</th>
      <th>SOAccount</th>
      <th>SOPartFreq</th>
      <th>SOComm</th>
      <th>NEWOtherComms</th>
      <th>Age</th>
      <th>Gender</th>
      <th>Trans</th>
      <th>Sexuality</th>
      <th>Ethnicity</th>
      <th>Accessibility</th>
      <th>MentalHealth</th>
      <th>SurveyLength</th>
      <th>SurveyEase</th>
      <th>ConvertedCompYearly</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>11</th>
      <td>12</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>Spain</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>12</td>
      <td>5</td>
      <td>Developer, back-end</td>
      <td>10 to 19 employees</td>
      <td>EUR European Euro</td>
      <td>43000.0</td>
      <td>Yearly</td>
      <td>Bash/Shell;HTML/CSS;JavaScript;Node.js;SQL;Typ...</td>
      <td>C++;Clojure;JavaScript;Node.js;Rust;SQL;TypeSc...</td>
      <td>PostgreSQL</td>
      <td>MongoDB;PostgreSQL;Redis</td>
      <td>AWS</td>
      <td>NaN</td>
      <td>Express;React.js;Vue.js</td>
      <td>Express;Vue.js</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Git</td>
      <td>Git</td>
      <td>Atom</td>
      <td>Atom</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>Less than once per month or monthly</td>
      <td>Yes, somewhat</td>
      <td>Yes</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent;Hispanic or Latin...</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Too long</td>
      <td>Easy</td>
      <td>46482.0</td>
    </tr>
    <tr>
      <th>23</th>
      <td>24</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>France</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>11 - 17 years</td>
      <td>School;Online Courses or Certification</td>
      <td>9</td>
      <td>2</td>
      <td>Engineer, data;Data scientist or machine learn...</td>
      <td>10 to 19 employees</td>
      <td>EUR European Euro</td>
      <td>36000.0</td>
      <td>Yearly</td>
      <td>JavaScript;Python</td>
      <td>Python;SQL</td>
      <td>MySQL</td>
      <td>Elasticsearch;MongoDB;MySQL;PostgreSQL</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Apache Spark;Keras;NumPy;Pandas;TensorFlow;Tor...</td>
      <td>Apache Spark;Keras;NumPy;Pandas;TensorFlow;Tor...</td>
      <td>Docker;Git</td>
      <td>Docker;Git;Kubernetes</td>
      <td>Visual Studio Code</td>
      <td>Visual Studio Code</td>
      <td>Linux-based</td>
      <td>Visit Stack Overflow;Google it</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>Yes</td>
      <td>Less than once per month or monthly</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>NaN</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>38915.0</td>
    </tr>
    <tr>
      <th>41</th>
      <td>42</td>
      <td>I am not primarily a developer, but I write co...</td>
      <td>Employed full-time</td>
      <td>France</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>6</td>
      <td>3</td>
      <td>Academic researcher;Scientist;Student</td>
      <td>20 to 99 employees</td>
      <td>EUR European Euro</td>
      <td>24000.0</td>
      <td>Yearly</td>
      <td>Bash/Shell;C#;C++;Python</td>
      <td>C++;Python</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>.NET Framework;.NET Core / .NET 5;NumPy;Pandas;Qt</td>
      <td>.NET Framework;.NET Core / .NET 5;NumPy;Pandas;Qt</td>
      <td>Git</td>
      <td>Git</td>
      <td>IPython/Jupyter;Notepad++;Visual Studio;Visual...</td>
      <td>IPython/Jupyter;Visual Studio Code</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Google it;Watch help / tu...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>A few times per week</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Hispanic or Latino/a/x</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Too long</td>
      <td>Easy</td>
      <td>25944.0</td>
    </tr>
    <tr>
      <th>44</th>
      <td>45</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>France</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>18 - 24 years</td>
      <td>School</td>
      <td>6</td>
      <td>Less than 1 year</td>
      <td>Developer, full-stack</td>
      <td>10 to 19 employees</td>
      <td>EUR European Euro</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>HTML/CSS;JavaScript;Node.js;Python;R;SQL;TypeS...</td>
      <td>NaN</td>
      <td>PostgreSQL</td>
      <td>NaN</td>
      <td>Google Cloud Platform</td>
      <td>NaN</td>
      <td>Django;Flask;Vue.js</td>
      <td>NaN</td>
      <td>NumPy;TensorFlow</td>
      <td>NaN</td>
      <td>Docker;Git;Kubernetes</td>
      <td>NaN</td>
      <td>Visual Studio</td>
      <td>NaN</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Google it</td>
      <td>Stack Overflow</td>
      <td>A few times per week</td>
      <td>No</td>
      <td>NaN</td>
      <td>Neutral</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Woman</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>68</th>
      <td>69</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>Spain</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>11 - 17 years</td>
      <td>School</td>
      <td>20</td>
      <td>10</td>
      <td>Developer, back-end</td>
      <td>10,000 or more employees</td>
      <td>EUR European Euro</td>
      <td>54000.0</td>
      <td>Yearly</td>
      <td>Bash/Shell;JavaScript;Node.js;TypeScript</td>
      <td>JavaScript;Node.js;Python;TypeScript</td>
      <td>DynamoDB</td>
      <td>DynamoDB;Firebase</td>
      <td>AWS</td>
      <td>AWS;Microsoft Azure</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Terraform</td>
      <td>Terraform</td>
      <td>Notepad++;Vim;Visual Studio Code</td>
      <td>Vim;Visual Studio Code</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>A few times per week</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>NaN</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>58373.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>83313</th>
      <td>83314</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>Spain</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Professional degree (JD, MD, etc.)</td>
      <td>11 - 17 years</td>
      <td>Coding Bootcamp;Other online resources (ex: vi...</td>
      <td>10</td>
      <td>5</td>
      <td>Developer, front-end;Developer, full-stack;Dev...</td>
      <td>2 to 9 employees</td>
      <td>EUR European Euro</td>
      <td>2300.0</td>
      <td>Monthly</td>
      <td>Elixir;JavaScript;Ruby</td>
      <td>Elixir;Ruby</td>
      <td>Firebase;PostgreSQL;Redis</td>
      <td>Firebase;PostgreSQL;Redis</td>
      <td>AWS;DigitalOcean;Google Cloud Platform</td>
      <td>AWS;DigitalOcean;Google Cloud Platform</td>
      <td>jQuery;Ruby on Rails</td>
      <td>Django;Ruby on Rails;Vue.js</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Ansible;Docker;Git;Yarn</td>
      <td>Ansible;Docker;Git;Kubernetes;Yarn</td>
      <td>RubyMine;Visual Studio Code</td>
      <td>Visual Studio Code</td>
      <td>MacOS</td>
      <td>Visit Stack Overflow;Google it</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Multiple times per day</td>
      <td>Yes</td>
      <td>Less than once per month or monthly</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Hispanic or Latino/a/x</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>29832.0</td>
    </tr>
    <tr>
      <th>83326</th>
      <td>83327</td>
      <td>I am a student who is learning to code</td>
      <td>Student, full-time</td>
      <td>France</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Something else</td>
      <td>11 - 17 years</td>
      <td>Online Courses or Certification</td>
      <td>5</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Python</td>
      <td>HTML/CSS;JavaScript;Python</td>
      <td>MongoDB;PostgreSQL</td>
      <td>MongoDB</td>
      <td>Heroku;Microsoft Azure</td>
      <td>NaN</td>
      <td>Django;Flask;React.js</td>
      <td>Flask;React.js</td>
      <td>Keras;NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>Keras;NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>Git</td>
      <td>Git</td>
      <td>IPython/Jupyter;Visual Studio Code</td>
      <td>IPython/Jupyter;Visual Studio Code</td>
      <td>Windows Subsystem for Linux (WSL)</td>
      <td>Visit Stack Overflow;Google it;Do other work a...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>A few times per week</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>Appropriate in length</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>83333</th>
      <td>83334</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>France</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>18 - 24 years</td>
      <td>Coding Bootcamp;Other online resources (ex: vi...</td>
      <td>4</td>
      <td>3</td>
      <td>Developer, full-stack</td>
      <td>100 to 499 employees</td>
      <td>EUR European Euro</td>
      <td>50000.0</td>
      <td>Yearly</td>
      <td>JavaScript;Node.js;Ruby;SQL;TypeScript</td>
      <td>C#;C++;Crystal;Go;JavaScript;Node.js;Python;Ru...</td>
      <td>MySQL;Redis</td>
      <td>Elasticsearch;Firebase;MySQL;PostgreSQL;Redis</td>
      <td>Heroku</td>
      <td>AWS;DigitalOcean;Google Cloud Platform;Heroku</td>
      <td>React.js;Ruby on Rails</td>
      <td>ASP.NET;ASP.NET Core ;Django;Express;FastAPI;F...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Git</td>
      <td>Chef;Deno;Git</td>
      <td>Visual Studio Code</td>
      <td>PyCharm;Visual Studio;Visual Studio Code;Xcode</td>
      <td>MacOS</td>
      <td>Google it</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>Not sure/can't remember</td>
      <td>NaN</td>
      <td>Yes, somewhat</td>
      <td>Yes</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>54049.0</td>
    </tr>
    <tr>
      <th>83344</th>
      <td>83345</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>France</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>18 - 24 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>10</td>
      <td>5</td>
      <td>Developer, back-end</td>
      <td>20 to 99 employees</td>
      <td>EUR European Euro</td>
      <td>50000.0</td>
      <td>Yearly</td>
      <td>HTML/CSS;Python;SQL</td>
      <td>HTML/CSS;Python;Rust;SQL;TypeScript</td>
      <td>MariaDB</td>
      <td>MariaDB</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Angular.js;FastAPI</td>
      <td>Angular;FastAPI;React.js;Vue.js</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>Docker;Git</td>
      <td>PyCharm</td>
      <td>PyCharm;Visual Studio Code</td>
      <td>Linux-based</td>
      <td>Visit Stack Overflow;Google it;Do other work a...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>Less than once per month or monthly</td>
      <td>No, not at all</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent;Biracial</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>54049.0</td>
    </tr>
    <tr>
      <th>83420</th>
      <td>83421</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>France</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>5 - 10 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>16</td>
      <td>4</td>
      <td>Developer, front-end;Developer, desktop or ent...</td>
      <td>2 to 9 employees</td>
      <td>EUR European Euro</td>
      <td>33000.0</td>
      <td>Yearly</td>
      <td>Bash/Shell;C#;C++;Go;Groovy;HTML/CSS;Java;Java...</td>
      <td>HTML/CSS;Java;JavaScript;Node.js;Python;TypeSc...</td>
      <td>Elasticsearch;Firebase;IBM DB2;MariaDB;Microso...</td>
      <td>Elasticsearch;MongoDB;Redis</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Angular;ASP.NET;ASP.NET Core ;Express;React.js...</td>
      <td>Express;React.js;Spring;Vue.js</td>
      <td>.NET Framework;.NET Core / .NET 5;Apache Spark</td>
      <td>Apache Spark;TensorFlow;Torch/PyTorch</td>
      <td>Ansible;Deno;Docker;Git;Kubernetes;Puppet;Terr...</td>
      <td>Deno;Docker;Git;Kubernetes;Unity 3D;Unreal Eng...</td>
      <td>Android Studio;Eclipse;IntelliJ;IPython/Jupyte...</td>
      <td>IntelliJ;IPython/Jupyter;Visual Studio Code;We...</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Google it</td>
      <td>Stack Overflow</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>Neutral</td>
      <td>Yes</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>I have a mood or emotional disorder (e.g. depr...</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>35672.0</td>
    </tr>
  </tbody>
</table>
<p>4193 rows × 48 columns</p>
</div>




```python
salario_alto = datos['ConvertedCompYearly'] > 80000
```


```python
datos.loc[salario_alto]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ResponseId</th>
      <th>MainBranch</th>
      <th>Employment</th>
      <th>Country</th>
      <th>US_State</th>
      <th>UK_Country</th>
      <th>EdLevel</th>
      <th>Age1stCode</th>
      <th>LearnCode</th>
      <th>YearsCode</th>
      <th>YearsCodePro</th>
      <th>DevType</th>
      <th>OrgSize</th>
      <th>Currency</th>
      <th>CompTotal</th>
      <th>CompFreq</th>
      <th>LanguageHaveWorkedWith</th>
      <th>LanguageWantToWorkWith</th>
      <th>DatabaseHaveWorkedWith</th>
      <th>DatabaseWantToWorkWith</th>
      <th>PlatformHaveWorkedWith</th>
      <th>PlatformWantToWorkWith</th>
      <th>WebframeHaveWorkedWith</th>
      <th>WebframeWantToWorkWith</th>
      <th>MiscTechHaveWorkedWith</th>
      <th>MiscTechWantToWorkWith</th>
      <th>ToolsTechHaveWorkedWith</th>
      <th>ToolsTechWantToWorkWith</th>
      <th>NEWCollabToolsHaveWorkedWith</th>
      <th>NEWCollabToolsWantToWorkWith</th>
      <th>OpSys</th>
      <th>NEWStuck</th>
      <th>NEWSOSites</th>
      <th>SOVisitFreq</th>
      <th>SOAccount</th>
      <th>SOPartFreq</th>
      <th>SOComm</th>
      <th>NEWOtherComms</th>
      <th>Age</th>
      <th>Gender</th>
      <th>Trans</th>
      <th>Sexuality</th>
      <th>Ethnicity</th>
      <th>Accessibility</th>
      <th>MentalHealth</th>
      <th>SurveyLength</th>
      <th>SurveyEase</th>
      <th>ConvertedCompYearly</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>18</th>
      <td>19</td>
      <td>I am not primarily a developer, but I write co...</td>
      <td>I prefer not to say</td>
      <td>Singapore</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Other doctoral degree (Ph.D., Ed.D., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other (please specify):</td>
      <td>40</td>
      <td>30</td>
      <td>NaN</td>
      <td>5,000 to 9,999 employees</td>
      <td>SGD\tSingapore dollar</td>
      <td>18700.0</td>
      <td>Monthly</td>
      <td>C++;Python</td>
      <td>C++;Python</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NumPy;Pandas;Torch/PyTorch</td>
      <td>NumPy;Pandas;Torch/PyTorch</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>IPython/Jupyter;Vim</td>
      <td>IPython/Jupyter;Vim</td>
      <td>Linux-based</td>
      <td>Google it</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Multiple times per day</td>
      <td>Yes</td>
      <td>Multiple times per day</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>45-54 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>160932.0</td>
    </tr>
    <tr>
      <th>26</th>
      <td>27</td>
      <td>I am not primarily a developer, but I write co...</td>
      <td>Employed full-time</td>
      <td>Switzerland</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>11 - 17 years</td>
      <td>Other (please specify):</td>
      <td>14</td>
      <td>5</td>
      <td>Academic researcher;Scientist;Student</td>
      <td>5,000 to 9,999 employees</td>
      <td>CHF\tSwiss franc</td>
      <td>80000.0</td>
      <td>Yearly</td>
      <td>C++;Python</td>
      <td>C++;Go;Java;Python</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NumPy;Pandas</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>Docker;Git</td>
      <td>IntelliJ;IPython/Jupyter</td>
      <td>IntelliJ;IPython/Jupyter</td>
      <td>Linux-based</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Multiple times per day</td>
      <td>Yes</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>Neutral</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>NaN</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>81319.0</td>
    </tr>
    <tr>
      <th>31</th>
      <td>32</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>Israel</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>25 - 34 years</td>
      <td>School;Online Courses or Certification</td>
      <td>4</td>
      <td>2</td>
      <td>Engineer, data;Developer, back-end</td>
      <td>5,000 to 9,999 employees</td>
      <td>ILS\tIsraeli new shekel</td>
      <td>35000.0</td>
      <td>Monthly</td>
      <td>Bash/Shell;Go;Java;Node.js;Python;Scala;SQL</td>
      <td>Bash/Shell;Java;Python;Scala;SQL</td>
      <td>DynamoDB;MongoDB;MySQL;PostgreSQL</td>
      <td>Cassandra;MongoDB;MySQL;PostgreSQL;Redis</td>
      <td>AWS;Google Cloud Platform;Microsoft Azure</td>
      <td>AWS;Google Cloud Platform</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Apache Spark;NumPy;Pandas</td>
      <td>Apache Spark</td>
      <td>Docker;Git;Kubernetes;Terraform</td>
      <td>Docker;Git;Kubernetes</td>
      <td>Atom;IntelliJ;IPython/Jupyter;PyCharm;Sublime ...</td>
      <td>IntelliJ;Visual Studio Code</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Google it;Do other w...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>Yes</td>
      <td>A few times per month or weekly</td>
      <td>No, not really</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent;Middle Eastern</td>
      <td>None of the above</td>
      <td>I have a concentration and/or memory disorder ...</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>122580.0</td>
    </tr>
    <tr>
      <th>36</th>
      <td>37</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>United States of America</td>
      <td>District of Columbia</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>8</td>
      <td>Less than 1 year</td>
      <td>Developer, embedded applications or devices</td>
      <td>20 to 99 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>103000.0</td>
      <td>Yearly</td>
      <td>Assembly;C;Java;Kotlin;Rust</td>
      <td>Assembly;Kotlin;Rust;SQL</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>Git</td>
      <td>IntelliJ;PyCharm;Webstorm</td>
      <td>Android Studio;IntelliJ;PyCharm;Sublime Text;W...</td>
      <td>Linux-based</td>
      <td>Visit Stack Overflow;Google it;Do other work a...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>A few times per week</td>
      <td>Yes, somewhat</td>
      <td>Yes</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>Prefer not to say</td>
      <td>Too short</td>
      <td>Easy</td>
      <td>103000.0</td>
    </tr>
    <tr>
      <th>37</th>
      <td>38</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>United States of America</td>
      <td>Massachusetts</td>
      <td>NaN</td>
      <td>Some college/university study without earning ...</td>
      <td>18 - 24 years</td>
      <td>Other online resources (ex: videos, blogs, etc)</td>
      <td>20</td>
      <td>15</td>
      <td>Developer, back-end</td>
      <td>1,000 to 4,999 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>300000.0</td>
      <td>Yearly</td>
      <td>Go</td>
      <td>Go;Rust</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>AWS;Google Cloud Platform;Microsoft Azure</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Docker;Git;Terraform</td>
      <td>Git;Terraform</td>
      <td>Vim;Visual Studio Code</td>
      <td>Vim;Visual Studio Code</td>
      <td>MacOS</td>
      <td>Google it;Do other work and come back later;Me...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>Daily or almost daily</td>
      <td>Yes, definitely</td>
      <td>No</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>I have a concentration and/or memory disorder ...</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>300000.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>83430</th>
      <td>83431</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>United States of America</td>
      <td>Illinois</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>23</td>
      <td>21</td>
      <td>Developer, front-end;Developer, full-stack;Dev...</td>
      <td>10 to 19 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>125000.0</td>
      <td>Yearly</td>
      <td>APL;Clojure;LISP;Python;Ruby;SQL;TypeScript</td>
      <td>APL;Clojure;Haskell;LISP;R</td>
      <td>MongoDB;MySQL;PostgreSQL;Redis</td>
      <td>PostgreSQL</td>
      <td>AWS;DigitalOcean;Google Cloud Platform;Heroku</td>
      <td>AWS;DigitalOcean;Google Cloud Platform</td>
      <td>Django;React.js;Ruby on Rails</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>Docker;Git;Kubernetes;Unity 3D</td>
      <td>Emacs;Vim</td>
      <td>Emacs</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>No</td>
      <td>NaN</td>
      <td>No, not really</td>
      <td>No</td>
      <td>45-54 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>125000.0</td>
    </tr>
    <tr>
      <th>83432</th>
      <td>83433</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>Canada</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>18 - 24 years</td>
      <td>School</td>
      <td>5</td>
      <td>Less than 1 year</td>
      <td>Developer, back-end</td>
      <td>10,000 or more employees</td>
      <td>CAD\tCanadian dollar</td>
      <td>106000.0</td>
      <td>Yearly</td>
      <td>Ruby</td>
      <td>Java;Ruby;TypeScript</td>
      <td>MySQL;PostgreSQL</td>
      <td>NaN</td>
      <td>Google Cloud Platform;Heroku</td>
      <td>NaN</td>
      <td>Flask;React.js;Ruby on Rails;Vue.js</td>
      <td>NaN</td>
      <td>NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>NaN</td>
      <td>Docker;Git;Kubernetes;Yarn</td>
      <td>NaN</td>
      <td>Atom;IPython/Jupyter;Vim;Visual Studio Code</td>
      <td>NaN</td>
      <td>MacOS</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>No</td>
      <td>NaN</td>
      <td>No, not really</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Woman</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>East Asian</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>80169.0</td>
    </tr>
    <tr>
      <th>83434</th>
      <td>83435</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>United States of America</td>
      <td>Texas</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>6</td>
      <td>5</td>
      <td>Developer, back-end</td>
      <td>20 to 99 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>160500.0</td>
      <td>Yearly</td>
      <td>Clojure;Kotlin;SQL</td>
      <td>Clojure</td>
      <td>Oracle;SQLite</td>
      <td>SQLite</td>
      <td>AWS</td>
      <td>AWS</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>Git;Kubernetes</td>
      <td>IntelliJ;Sublime Text;Vim;Visual Studio Code</td>
      <td>Sublime Text;Vim</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Google it</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>No</td>
      <td>NaN</td>
      <td>No, not at all</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>I have a concentration and/or memory disorder ...</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>160500.0</td>
    </tr>
    <tr>
      <th>83436</th>
      <td>83437</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>United States of America</td>
      <td>New Jersey</td>
      <td>NaN</td>
      <td>Secondary school (e.g. American high school, G...</td>
      <td>11 - 17 years</td>
      <td>School</td>
      <td>10</td>
      <td>4</td>
      <td>Data scientist or machine learning specialist;...</td>
      <td>10,000 or more employees</td>
      <td>USD\tUnited States dollar</td>
      <td>1800.0</td>
      <td>Weekly</td>
      <td>Groovy;Java;Python</td>
      <td>Java;Python</td>
      <td>DynamoDB;Elasticsearch;MongoDB;PostgreSQL;Redis</td>
      <td>DynamoDB;Redis</td>
      <td>AWS;Google Cloud Platform</td>
      <td>AWS</td>
      <td>FastAPI;Flask</td>
      <td>FastAPI;Flask</td>
      <td>Hadoop;Keras;NumPy;Pandas</td>
      <td>Apache Spark;Hadoop;Keras;NumPy;Pandas;TensorFlow</td>
      <td>Ansible;Docker;Git;Terraform</td>
      <td>Docker;Git;Kubernetes;Terraform</td>
      <td>Android Studio;Eclipse;IntelliJ;IPython/Jupyte...</td>
      <td>IntelliJ;IPython/Jupyter;Notepad++;Vim</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>Yes</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>No, not really</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>NaN</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>90000.0</td>
    </tr>
    <tr>
      <th>83437</th>
      <td>83438</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>Canada</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Online Courses or Certification;Books / Physic...</td>
      <td>5</td>
      <td>3</td>
      <td>Developer, back-end</td>
      <td>20 to 99 employees</td>
      <td>CAD\tCanadian dollar</td>
      <td>90000.0</td>
      <td>Monthly</td>
      <td>Bash/Shell;JavaScript;Node.js;Python</td>
      <td>Go;Rust</td>
      <td>Cassandra;Elasticsearch;MongoDB;PostgreSQL;Redis</td>
      <td>NaN</td>
      <td>Heroku</td>
      <td>AWS;DigitalOcean</td>
      <td>Django;Express;Flask;React.js</td>
      <td>NaN</td>
      <td>NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>Ansible;Docker;Git;Terraform</td>
      <td>Kubernetes;Terraform</td>
      <td>PyCharm;Sublime Text</td>
      <td>NaN</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>A few times per month or weekly</td>
      <td>Yes</td>
      <td>Less than once per month or monthly</td>
      <td>No, not really</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>I have a mood or emotional disorder (e.g. depr...</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>816816.0</td>
    </tr>
  </tbody>
</table>
<p>15696 rows × 48 columns</p>
</div>




```python
datos.loc[salario_alto, ['Country', 'LanguageHaveWorkedWith']]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Country</th>
      <th>LanguageHaveWorkedWith</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>18</th>
      <td>Singapore</td>
      <td>C++;Python</td>
    </tr>
    <tr>
      <th>26</th>
      <td>Switzerland</td>
      <td>C++;Python</td>
    </tr>
    <tr>
      <th>31</th>
      <td>Israel</td>
      <td>Bash/Shell;Go;Java;Node.js;Python;Scala;SQL</td>
    </tr>
    <tr>
      <th>36</th>
      <td>United States of America</td>
      <td>Assembly;C;Java;Kotlin;Rust</td>
    </tr>
    <tr>
      <th>37</th>
      <td>United States of America</td>
      <td>Go</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>83430</th>
      <td>United States of America</td>
      <td>APL;Clojure;LISP;Python;Ruby;SQL;TypeScript</td>
    </tr>
    <tr>
      <th>83432</th>
      <td>Canada</td>
      <td>Ruby</td>
    </tr>
    <tr>
      <th>83434</th>
      <td>United States of America</td>
      <td>Clojure;Kotlin;SQL</td>
    </tr>
    <tr>
      <th>83436</th>
      <td>United States of America</td>
      <td>Groovy;Java;Python</td>
    </tr>
    <tr>
      <th>83437</th>
      <td>Canada</td>
      <td>Bash/Shell;JavaScript;Node.js;Python</td>
    </tr>
  </tbody>
</table>
<p>15696 rows × 2 columns</p>
</div>




```python
salario_eur = (datos['ConvertedCompYearly'] > 80000) & (datos['Currency'] == 'EUR European Euro')
```


```python
datos.loc[salario_eur]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ResponseId</th>
      <th>MainBranch</th>
      <th>Employment</th>
      <th>Country</th>
      <th>US_State</th>
      <th>UK_Country</th>
      <th>EdLevel</th>
      <th>Age1stCode</th>
      <th>LearnCode</th>
      <th>YearsCode</th>
      <th>YearsCodePro</th>
      <th>DevType</th>
      <th>OrgSize</th>
      <th>Currency</th>
      <th>CompTotal</th>
      <th>CompFreq</th>
      <th>LanguageHaveWorkedWith</th>
      <th>LanguageWantToWorkWith</th>
      <th>DatabaseHaveWorkedWith</th>
      <th>DatabaseWantToWorkWith</th>
      <th>PlatformHaveWorkedWith</th>
      <th>PlatformWantToWorkWith</th>
      <th>WebframeHaveWorkedWith</th>
      <th>WebframeWantToWorkWith</th>
      <th>MiscTechHaveWorkedWith</th>
      <th>MiscTechWantToWorkWith</th>
      <th>ToolsTechHaveWorkedWith</th>
      <th>ToolsTechWantToWorkWith</th>
      <th>NEWCollabToolsHaveWorkedWith</th>
      <th>NEWCollabToolsWantToWorkWith</th>
      <th>OpSys</th>
      <th>NEWStuck</th>
      <th>NEWSOSites</th>
      <th>SOVisitFreq</th>
      <th>SOAccount</th>
      <th>SOPartFreq</th>
      <th>SOComm</th>
      <th>NEWOtherComms</th>
      <th>Age</th>
      <th>Gender</th>
      <th>Trans</th>
      <th>Sexuality</th>
      <th>Ethnicity</th>
      <th>Accessibility</th>
      <th>MentalHealth</th>
      <th>SurveyLength</th>
      <th>SurveyEase</th>
      <th>ConvertedCompYearly</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>91</th>
      <td>92</td>
      <td>I am not primarily a developer, but I write co...</td>
      <td>Employed full-time</td>
      <td>Netherlands</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Primary/elementary school</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>20</td>
      <td>10</td>
      <td>Other (please specify):;DevOps specialist;Syst...</td>
      <td>10,000 or more employees</td>
      <td>EUR European Euro</td>
      <td>100000.0</td>
      <td>Yearly</td>
      <td>Bash/Shell;C#;JavaScript;Node.js;PowerShell;Py...</td>
      <td>C#;C++;F#;PowerShell;Python;Rust;TypeScript</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>ASP.NET;ASP.NET Core ;jQuery;React.js</td>
      <td>Angular.js;ASP.NET Core ;Vue.js</td>
      <td>.NET Framework;.NET Core / .NET 5</td>
      <td>.NET Framework;.NET Core / .NET 5</td>
      <td>Docker;Git;Kubernetes;Puppet;Terraform;Unity 3D</td>
      <td>Docker;Git</td>
      <td>Visual Studio;Visual Studio Code</td>
      <td>Visual Studio;Visual Studio Code</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Multiple times per day</td>
      <td>Yes</td>
      <td>Multiple times per day</td>
      <td>Yes, somewhat</td>
      <td>Yes</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Bisexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>I have a concentration and/or memory disorder ...</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>108098.0</td>
    </tr>
    <tr>
      <th>96</th>
      <td>97</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>Germany</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other (please specify):</td>
      <td>10</td>
      <td>Less than 1 year</td>
      <td>Developer, full-stack</td>
      <td>100 to 499 employees</td>
      <td>EUR European Euro</td>
      <td>40000.0</td>
      <td>Monthly</td>
      <td>Bash/Shell;Clojure;Haskell;Java;JavaScript;Kot...</td>
      <td>Haskell</td>
      <td>Cassandra</td>
      <td>NaN</td>
      <td>AWS;Google Cloud Platform</td>
      <td>NaN</td>
      <td>React.js</td>
      <td>NaN</td>
      <td>Flutter</td>
      <td>NaN</td>
      <td>Docker;Git;Kubernetes</td>
      <td>Git</td>
      <td>Emacs;Neovim;Vim</td>
      <td>Emacs;Neovim;Vim</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Panic</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>Yes</td>
      <td>Less than once per month or monthly</td>
      <td>No, not really</td>
      <td>Yes</td>
      <td>18-24 years old</td>
      <td>Non-binary, genderqueer, or gender non-conforming</td>
      <td>Yes</td>
      <td>Bisexual;Queer</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>I have a mood or emotional disorder (e.g. depr...</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>518868.0</td>
    </tr>
    <tr>
      <th>100</th>
      <td>101</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>France</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>8</td>
      <td>3</td>
      <td>Developer, mobile;Developer, front-end;Develop...</td>
      <td>Just me - I am a freelancer, sole proprietor, ...</td>
      <td>EUR European Euro</td>
      <td>140000.0</td>
      <td>Yearly</td>
      <td>Dart;JavaScript;Node.js</td>
      <td>C++;Dart;Swift</td>
      <td>Firebase;PostgreSQL;SQLite</td>
      <td>Firebase;SQLite</td>
      <td>Google Cloud Platform</td>
      <td>AWS;Google Cloud Platform</td>
      <td>Django;Vue.js</td>
      <td>Vue.js</td>
      <td>Flutter</td>
      <td>Flutter;TensorFlow;Torch/PyTorch</td>
      <td>Docker;Git</td>
      <td>Docker;Git;Terraform</td>
      <td>Android Studio;Visual Studio Code;Xcode</td>
      <td>Visual Studio Code</td>
      <td>MacOS</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
      <td>Stack Overflow</td>
      <td>Multiple times per day</td>
      <td>Yes</td>
      <td>Daily or almost daily</td>
      <td>Yes, definitely</td>
      <td>Yes</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Too long</td>
      <td>Easy</td>
      <td>151337.0</td>
    </tr>
    <tr>
      <th>131</th>
      <td>132</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>Germany</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Something else</td>
      <td>25 - 34 years</td>
      <td>Other (please specify):</td>
      <td>6</td>
      <td>3</td>
      <td>Developer, front-end;Developer, desktop or ent...</td>
      <td>20 to 99 employees</td>
      <td>EUR European Euro</td>
      <td>46000.0</td>
      <td>Monthly</td>
      <td>C#;PowerShell;SQL</td>
      <td>C#;Objective-C;PowerShell;SQL;Swift</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>.NET Framework;.NET Core / .NET 5</td>
      <td>.NET Framework;.NET Core / .NET 5</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Notepad++;Visual Studio</td>
      <td>Notepad++;Rider;Visual Studio;Visual Studio Co...</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Multiple times per day</td>
      <td>Yes</td>
      <td>A few times per month or weekly</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>596700.0</td>
    </tr>
    <tr>
      <th>145</th>
      <td>146</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>Germany</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>5 - 10 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>27</td>
      <td>11</td>
      <td>Developer, back-end;DevOps specialist;Engineer...</td>
      <td>100 to 499 employees</td>
      <td>EUR European Euro</td>
      <td>90000.0</td>
      <td>Yearly</td>
      <td>Bash/Shell;C;Dart;Go;HTML/CSS;JavaScript;Node....</td>
      <td>Go;Kotlin;Node.js;Rust;TypeScript</td>
      <td>DynamoDB;Elasticsearch;MongoDB;MySQL;Redis;SQLite</td>
      <td>MongoDB;Redis</td>
      <td>AWS</td>
      <td>NaN</td>
      <td>React.js</td>
      <td>React.js</td>
      <td>Flutter;React Native;TensorFlow</td>
      <td>Apache Spark;Flutter;TensorFlow;Torch/PyTorch</td>
      <td>Docker;Git;Kubernetes;Yarn</td>
      <td>Git;Kubernetes</td>
      <td>PHPStorm;PyCharm;Visual Studio Code</td>
      <td>PHPStorm;Visual Studio Code</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Go for a walk or oth...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>Yes</td>
      <td>A few times per month or weekly</td>
      <td>Yes, somewhat</td>
      <td>Yes</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Prefer not to say</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>97288.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>83266</th>
      <td>83267</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>Netherlands</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Other doctoral degree (Ph.D., Ed.D., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>26</td>
      <td>9</td>
      <td>Developer, full-stack;Engineer, data;Scientist...</td>
      <td>10,000 or more employees</td>
      <td>EUR European Euro</td>
      <td>90000.0</td>
      <td>Yearly</td>
      <td>Java;Julia;Python</td>
      <td>Julia;Rust</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Microsoft Azure</td>
      <td>Google Cloud Platform;Microsoft Azure</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>Docker;Git;Kubernetes</td>
      <td>Vim;Visual Studio Code</td>
      <td>Vim;Visual Studio Code</td>
      <td>Windows</td>
      <td>Go for a walk or other physical activity;Googl...</td>
      <td>Stack Overflow;Stack Overflow for Teams (priva...</td>
      <td>Less than once per month or monthly</td>
      <td>No</td>
      <td>NaN</td>
      <td>No, not at all</td>
      <td>Yes</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent;Hispanic or Latin...</td>
      <td>None of the above</td>
      <td>Or, in your own words:</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>97288.0</td>
    </tr>
    <tr>
      <th>83296</th>
      <td>83297</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>France</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>11 - 17 years</td>
      <td>Books / Physical media</td>
      <td>25</td>
      <td>20</td>
      <td>Other (please specify):</td>
      <td>5,000 to 9,999 employees</td>
      <td>EUR European Euro</td>
      <td>75000.0</td>
      <td>Yearly</td>
      <td>F#</td>
      <td>F#;Rust</td>
      <td>PostgreSQL</td>
      <td>PostgreSQL</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>ASP.NET Core ;Vue.js</td>
      <td>ASP.NET Core</td>
      <td>.NET Core / .NET 5</td>
      <td>.NET Core / .NET 5</td>
      <td>Docker;Git</td>
      <td>Docker;Git;Pulumi</td>
      <td>Rider;Visual Studio;Visual Studio Code</td>
      <td>Rider;Visual Studio;Visual Studio Code</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>NaN</td>
      <td>Neutral</td>
      <td>Yes</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Multiracial</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Too short</td>
      <td>Easy</td>
      <td>81074.0</td>
    </tr>
    <tr>
      <th>83409</th>
      <td>83410</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>Netherlands</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Other doctoral degree (Ph.D., Ed.D., etc.)</td>
      <td>18 - 24 years</td>
      <td>School</td>
      <td>12</td>
      <td>6</td>
      <td>Developer, desktop or enterprise applications;...</td>
      <td>10,000 or more employees</td>
      <td>EUR European Euro</td>
      <td>80000.0</td>
      <td>Yearly</td>
      <td>Julia;Matlab;Python</td>
      <td>Julia</td>
      <td>MySQL</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>Docker;Git</td>
      <td>IPython/Jupyter;Notepad++;Visual Studio Code</td>
      <td>IPython/Jupyter;Notepad++;Visual Studio Code</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Go for a walk or oth...</td>
      <td>Stack Overflow</td>
      <td>A few times per week</td>
      <td>No</td>
      <td>NaN</td>
      <td>No, not really</td>
      <td>Yes</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>86478.0</td>
    </tr>
    <tr>
      <th>83419</th>
      <td>83420</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>Austria</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>5 - 10 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>30</td>
      <td>13</td>
      <td>Developer, front-end;Developer, desktop or ent...</td>
      <td>100 to 499 employees</td>
      <td>EUR European Euro</td>
      <td>77000.0</td>
      <td>Yearly</td>
      <td>Groovy;HTML/CSS;Java;JavaScript;Node.js;PHP;Po...</td>
      <td>HTML/CSS;Java;JavaScript;Kotlin;Node.js;TypeSc...</td>
      <td>Elasticsearch;MariaDB;MySQL;Oracle;PostgreSQL;...</td>
      <td>Cassandra;Elasticsearch;MariaDB;MySQL;Oracle;P...</td>
      <td>AWS</td>
      <td>AWS;Microsoft Azure</td>
      <td>Angular;Spring</td>
      <td>Angular;Express;React.js;Spring;Svelte;Vue.js</td>
      <td>.NET Framework</td>
      <td>NaN</td>
      <td>Docker;Git;Kubernetes;Terraform</td>
      <td>Ansible;Docker;Git;Kubernetes;Terraform</td>
      <td>Android Studio;IntelliJ;Notepad++;Visual Studi...</td>
      <td>IntelliJ;Notepad++</td>
      <td>Windows Subsystem for Linux (WSL)</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>A few times per month or weekly</td>
      <td>Yes, somewhat</td>
      <td>Yes</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>83236.0</td>
    </tr>
    <tr>
      <th>83424</th>
      <td>83425</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>Germany</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>17</td>
      <td>12</td>
      <td>Developer, full-stack;Other (please specify):;...</td>
      <td>10,000 or more employees</td>
      <td>EUR European Euro</td>
      <td>120000.0</td>
      <td>Yearly</td>
      <td>Bash/Shell;C;Go;Java;JavaScript;Perl;SQL</td>
      <td>Bash/Shell;Java;Rust;SQL</td>
      <td>MySQL</td>
      <td>PostgreSQL</td>
      <td>AWS;DigitalOcean;Google Cloud Platform</td>
      <td>NaN</td>
      <td>Angular.js;Spring;Vue.js</td>
      <td>Spring</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Docker;Git;Kubernetes;Terraform</td>
      <td>Docker;Git;Kubernetes</td>
      <td>IntelliJ;Neovim;Vim</td>
      <td>IntelliJ;Neovim</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>Yes</td>
      <td>Less than once per month or monthly</td>
      <td>No, not really</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>Or, in your own words:</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>129718.0</td>
    </tr>
  </tbody>
</table>
<p>2393 rows × 48 columns</p>
</div>




```python
datos['LanguageHaveWorkedWith']
```




    0        C++;HTML/CSS;JavaScript;Objective-C;PHP;Swift
    1                                    JavaScript;Python
    2                             Assembly;C;Python;R;Rust
    3                                JavaScript;TypeScript
    4                       Bash/Shell;HTML/CSS;Python;SQL
                                 ...                      
    83434                               Clojure;Kotlin;SQL
    83435                                              NaN
    83436                               Groovy;Java;Python
    83437             Bash/Shell;JavaScript;Node.js;Python
    83438           Delphi;Elixir;HTML/CSS;Java;JavaScript
    Name: LanguageHaveWorkedWith, Length: 83439, dtype: object




```python
filtrar_lenguajes = datos['LanguageHaveWorkedWith'].str.contains('Python', na=False)
```


```python
datos.loc[filtrar_lenguajes, 'LanguageHaveWorkedWith']
```




    1                                        JavaScript;Python
    2                                 Assembly;C;Python;R;Rust
    4                           Bash/Shell;HTML/CSS;Python;SQL
    5        C;C#;C++;HTML/CSS;Java;JavaScript;Node.js;Powe...
    9                                               C++;Python
                                   ...                        
    83429               HTML/CSS;PHP;PowerShell;Python;SQL;VBA
    83430          APL;Clojure;LISP;Python;Ruby;SQL;TypeScript
    83431    C#;Dart;HTML/CSS;Java;JavaScript;Kotlin;Node.j...
    83436                                   Groovy;Java;Python
    83437                 Bash/Shell;JavaScript;Node.js;Python
    Name: LanguageHaveWorkedWith, Length: 39792, dtype: object




```python
datos.columns
```




    Index(['ResponseId', 'MainBranch', 'Employment', 'Country', 'US_State',
           'UK_Country', 'EdLevel', 'Age1stCode', 'LearnCode', 'YearsCode',
           'YearsCodePro', 'DevType', 'OrgSize', 'Currency', 'CompTotal',
           'CompFreq', 'LanguageHaveWorkedWith', 'LanguageWantToWorkWith',
           'DatabaseHaveWorkedWith', 'DatabaseWantToWorkWith',
           'PlatformHaveWorkedWith', 'PlatformWantToWorkWith',
           'WebframeHaveWorkedWith', 'WebframeWantToWorkWith',
           'MiscTechHaveWorkedWith', 'MiscTechWantToWorkWith',
           'ToolsTechHaveWorkedWith', 'ToolsTechWantToWorkWith',
           'NEWCollabToolsHaveWorkedWith', 'NEWCollabToolsWantToWorkWith', 'OpSys',
           'NEWStuck', 'NEWSOSites', 'SOVisitFreq', 'SOAccount', 'SOPartFreq',
           'SOComm', 'NEWOtherComms', 'Age', 'Gender', 'Trans', 'Sexuality',
           'Ethnicity', 'Accessibility', 'MentalHealth', 'SurveyLength',
           'SurveyEase', 'ConvertedCompYearly'],
          dtype='object')




```python
# Cambia a mayúsculas las etiquetas de los campos
datos.columns = (x.upper() for x in datos.columns)
```


```python
datos
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>RESPONSEID</th>
      <th>MAINBRANCH</th>
      <th>EMPLOYMENT</th>
      <th>COUNTRY</th>
      <th>US_STATE</th>
      <th>UK_COUNTRY</th>
      <th>EDLEVEL</th>
      <th>AGE1STCODE</th>
      <th>LEARNCODE</th>
      <th>YEARSCODE</th>
      <th>YEARSCODEPRO</th>
      <th>DEVTYPE</th>
      <th>ORGSIZE</th>
      <th>CURRENCY</th>
      <th>COMPTOTAL</th>
      <th>COMPFREQ</th>
      <th>LANGUAGEHAVEWORKEDWITH</th>
      <th>LANGUAGEWANTTOWORKWITH</th>
      <th>DATABASEHAVEWORKEDWITH</th>
      <th>DATABASEWANTTOWORKWITH</th>
      <th>PLATFORMHAVEWORKEDWITH</th>
      <th>PLATFORMWANTTOWORKWITH</th>
      <th>WEBFRAMEHAVEWORKEDWITH</th>
      <th>WEBFRAMEWANTTOWORKWITH</th>
      <th>MISCTECHHAVEWORKEDWITH</th>
      <th>MISCTECHWANTTOWORKWITH</th>
      <th>TOOLSTECHHAVEWORKEDWITH</th>
      <th>TOOLSTECHWANTTOWORKWITH</th>
      <th>NEWCOLLABTOOLSHAVEWORKEDWITH</th>
      <th>NEWCOLLABTOOLSWANTTOWORKWITH</th>
      <th>OPSYS</th>
      <th>NEWSTUCK</th>
      <th>NEWSOSITES</th>
      <th>SOVISITFREQ</th>
      <th>SOACCOUNT</th>
      <th>SOPARTFREQ</th>
      <th>SOCOMM</th>
      <th>NEWOTHERCOMMS</th>
      <th>AGE</th>
      <th>GENDER</th>
      <th>TRANS</th>
      <th>SEXUALITY</th>
      <th>ETHNICITY</th>
      <th>ACCESSIBILITY</th>
      <th>MENTALHEALTH</th>
      <th>SURVEYLENGTH</th>
      <th>SURVEYEASE</th>
      <th>CONVERTEDCOMPYEARLY</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>Slovakia</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Secondary school (e.g. American high school, G...</td>
      <td>18 - 24 years</td>
      <td>Coding Bootcamp;Other online resources (ex: vi...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Developer, mobile</td>
      <td>20 to 99 employees</td>
      <td>EUR European Euro</td>
      <td>4800.0</td>
      <td>Monthly</td>
      <td>C++;HTML/CSS;JavaScript;Objective-C;PHP;Swift</td>
      <td>Swift</td>
      <td>PostgreSQL;SQLite</td>
      <td>SQLite</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Laravel;Symfony</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>PHPStorm;Xcode</td>
      <td>Atom;Xcode</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>Multiple times per day</td>
      <td>Yes</td>
      <td>A few times per month or weekly</td>
      <td>Yes, definitely</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>62268.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>I am a student who is learning to code</td>
      <td>Student, full-time</td>
      <td>Netherlands</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>7</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>JavaScript;Python</td>
      <td>NaN</td>
      <td>PostgreSQL</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Angular;Flask;Vue.js</td>
      <td>NaN</td>
      <td>Cordova</td>
      <td>NaN</td>
      <td>Docker;Git;Yarn</td>
      <td>Git</td>
      <td>Android Studio;IntelliJ;Notepad++;PyCharm</td>
      <td>NaN</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Google it</td>
      <td>Stack Overflow</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>Daily or almost daily</td>
      <td>Yes, definitely</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>I am not primarily a developer, but I write co...</td>
      <td>Student, full-time</td>
      <td>Russian Federation</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Assembly;C;Python;R;Rust</td>
      <td>Julia;Python;Rust</td>
      <td>SQLite</td>
      <td>SQLite</td>
      <td>Heroku</td>
      <td>NaN</td>
      <td>Flask</td>
      <td>Flask</td>
      <td>NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>Keras;NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>IPython/Jupyter;PyCharm;RStudio;Sublime Text;V...</td>
      <td>IPython/Jupyter;RStudio;Sublime Text;Visual St...</td>
      <td>MacOS</td>
      <td>Visit Stack Overflow;Google it;Watch help / tu...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Multiple times per day</td>
      <td>Yes</td>
      <td>Multiple times per day</td>
      <td>Yes, definitely</td>
      <td>Yes</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>Austria</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>11 - 17 years</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Developer, front-end</td>
      <td>100 to 499 employees</td>
      <td>EUR European Euro</td>
      <td>NaN</td>
      <td>Monthly</td>
      <td>JavaScript;TypeScript</td>
      <td>JavaScript;TypeScript</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Angular;jQuery</td>
      <td>Angular;jQuery</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>Daily or almost daily</td>
      <td>Neutral</td>
      <td>No</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>I am deaf / hard of hearing</td>
      <td>NaN</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>United Kingdom of Great Britain and Northern I...</td>
      <td>NaN</td>
      <td>England</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>5 - 10 years</td>
      <td>Friend or family member</td>
      <td>17</td>
      <td>10</td>
      <td>Developer, desktop or enterprise applications;...</td>
      <td>Just me - I am a freelancer, sole proprietor, ...</td>
      <td>GBP\tPound sterling</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bash/Shell;HTML/CSS;Python;SQL</td>
      <td>Bash/Shell;HTML/CSS;Python;SQL</td>
      <td>Elasticsearch;PostgreSQL;Redis</td>
      <td>Cassandra;Elasticsearch;PostgreSQL;Redis</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Flask</td>
      <td>Flask</td>
      <td>Apache Spark;Hadoop;NumPy;Pandas</td>
      <td>Hadoop;NumPy;Pandas</td>
      <td>Docker;Git;Kubernetes;Yarn</td>
      <td>Docker;Git;Kubernetes;Yarn</td>
      <td>Atom;IPython/Jupyter;Notepad++;PyCharm;Vim</td>
      <td>Atom;IPython/Jupyter;Notepad++;PyCharm;Vim;Vis...</td>
      <td>Linux-based</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>A few times per week</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>NaN</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>NaN</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>83434</th>
      <td>83435</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>United States of America</td>
      <td>Texas</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>6</td>
      <td>5</td>
      <td>Developer, back-end</td>
      <td>20 to 99 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>160500.0</td>
      <td>Yearly</td>
      <td>Clojure;Kotlin;SQL</td>
      <td>Clojure</td>
      <td>Oracle;SQLite</td>
      <td>SQLite</td>
      <td>AWS</td>
      <td>AWS</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>Git;Kubernetes</td>
      <td>IntelliJ;Sublime Text;Vim;Visual Studio Code</td>
      <td>Sublime Text;Vim</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Google it</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>No</td>
      <td>NaN</td>
      <td>No, not at all</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>I have a concentration and/or memory disorder ...</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>160500.0</td>
    </tr>
    <tr>
      <th>83435</th>
      <td>83436</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>Benin</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>4</td>
      <td>2</td>
      <td>Developer, full-stack</td>
      <td>Just me - I am a freelancer, sole proprietor, ...</td>
      <td>XOF\tWest African CFA franc</td>
      <td>200000.0</td>
      <td>Monthly</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Firebase;MariaDB;MySQL;PostgreSQL;Redis;SQLite</td>
      <td>Firebase;MariaDB;MongoDB;MySQL;PostgreSQL;Redi...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Django;jQuery;Laravel;React.js;Ruby on Rails</td>
      <td>Django;Express;jQuery;Laravel;React.js;Ruby on...</td>
      <td>Flutter;Qt</td>
      <td>NaN</td>
      <td>Git;Unity 3D;Unreal Engine</td>
      <td>Docker;Git;Kubernetes</td>
      <td>Android Studio;Eclipse;Emacs;IntelliJ;NetBeans...</td>
      <td>Emacs;IntelliJ;PHPStorm;PyCharm;RStudio;Sublim...</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Multiple times per day</td>
      <td>Yes</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Black or of African descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>3960.0</td>
    </tr>
    <tr>
      <th>83436</th>
      <td>83437</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>United States of America</td>
      <td>New Jersey</td>
      <td>NaN</td>
      <td>Secondary school (e.g. American high school, G...</td>
      <td>11 - 17 years</td>
      <td>School</td>
      <td>10</td>
      <td>4</td>
      <td>Data scientist or machine learning specialist;...</td>
      <td>10,000 or more employees</td>
      <td>USD\tUnited States dollar</td>
      <td>1800.0</td>
      <td>Weekly</td>
      <td>Groovy;Java;Python</td>
      <td>Java;Python</td>
      <td>DynamoDB;Elasticsearch;MongoDB;PostgreSQL;Redis</td>
      <td>DynamoDB;Redis</td>
      <td>AWS;Google Cloud Platform</td>
      <td>AWS</td>
      <td>FastAPI;Flask</td>
      <td>FastAPI;Flask</td>
      <td>Hadoop;Keras;NumPy;Pandas</td>
      <td>Apache Spark;Hadoop;Keras;NumPy;Pandas;TensorFlow</td>
      <td>Ansible;Docker;Git;Terraform</td>
      <td>Docker;Git;Kubernetes;Terraform</td>
      <td>Android Studio;Eclipse;IntelliJ;IPython/Jupyte...</td>
      <td>IntelliJ;IPython/Jupyter;Notepad++;Vim</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>Yes</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>No, not really</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>NaN</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>90000.0</td>
    </tr>
    <tr>
      <th>83437</th>
      <td>83438</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>Canada</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Online Courses or Certification;Books / Physic...</td>
      <td>5</td>
      <td>3</td>
      <td>Developer, back-end</td>
      <td>20 to 99 employees</td>
      <td>CAD\tCanadian dollar</td>
      <td>90000.0</td>
      <td>Monthly</td>
      <td>Bash/Shell;JavaScript;Node.js;Python</td>
      <td>Go;Rust</td>
      <td>Cassandra;Elasticsearch;MongoDB;PostgreSQL;Redis</td>
      <td>NaN</td>
      <td>Heroku</td>
      <td>AWS;DigitalOcean</td>
      <td>Django;Express;Flask;React.js</td>
      <td>NaN</td>
      <td>NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>Ansible;Docker;Git;Terraform</td>
      <td>Kubernetes;Terraform</td>
      <td>PyCharm;Sublime Text</td>
      <td>NaN</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>A few times per month or weekly</td>
      <td>Yes</td>
      <td>Less than once per month or monthly</td>
      <td>No, not really</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>I have a mood or emotional disorder (e.g. depr...</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>816816.0</td>
    </tr>
    <tr>
      <th>83438</th>
      <td>83439</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>Brazil</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Professional degree (JD, MD, etc.)</td>
      <td>11 - 17 years</td>
      <td>School</td>
      <td>14</td>
      <td>4</td>
      <td>Developer, front-end;Developer, full-stack;Dev...</td>
      <td>I don’t know</td>
      <td>BRL\tBrazilian real</td>
      <td>7700.0</td>
      <td>Monthly</td>
      <td>Delphi;Elixir;HTML/CSS;Java;JavaScript</td>
      <td>Elixir;HTML/CSS;Java;JavaScript;Node.js;PHP;SQ...</td>
      <td>Oracle;PostgreSQL</td>
      <td>Elasticsearch;MongoDB;MySQL;Oracle;PostgreSQL;...</td>
      <td>Microsoft Azure</td>
      <td>AWS</td>
      <td>Angular;Spring</td>
      <td>Express;Laravel;Spring;Symfony</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>Docker;Git;Kubernetes</td>
      <td>IntelliJ;Visual Studio Code</td>
      <td>IntelliJ;PHPStorm;Visual Studio Code</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange;Stack Overflow f...</td>
      <td>A few times per week</td>
      <td>Yes</td>
      <td>A few times per week</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Hispanic or Latino/a/x</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>21168.0</td>
    </tr>
  </tbody>
</table>
<p>83439 rows × 48 columns</p>
</div>




```python
datos.columns = datos.columns.str.replace('_', '')
datos
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>RESPONSEID</th>
      <th>MAINBRANCH</th>
      <th>EMPLOYMENT</th>
      <th>COUNTRY</th>
      <th>USSTATE</th>
      <th>UKCOUNTRY</th>
      <th>EDLEVEL</th>
      <th>AGE1STCODE</th>
      <th>LEARNCODE</th>
      <th>YEARSCODE</th>
      <th>YEARSCODEPRO</th>
      <th>DEVTYPE</th>
      <th>ORGSIZE</th>
      <th>CURRENCY</th>
      <th>COMPTOTAL</th>
      <th>COMPFREQ</th>
      <th>LANGUAGEHAVEWORKEDWITH</th>
      <th>LANGUAGEWANTTOWORKWITH</th>
      <th>DATABASEHAVEWORKEDWITH</th>
      <th>DATABASEWANTTOWORKWITH</th>
      <th>PLATFORMHAVEWORKEDWITH</th>
      <th>PLATFORMWANTTOWORKWITH</th>
      <th>WEBFRAMEHAVEWORKEDWITH</th>
      <th>WEBFRAMEWANTTOWORKWITH</th>
      <th>MISCTECHHAVEWORKEDWITH</th>
      <th>MISCTECHWANTTOWORKWITH</th>
      <th>TOOLSTECHHAVEWORKEDWITH</th>
      <th>TOOLSTECHWANTTOWORKWITH</th>
      <th>NEWCOLLABTOOLSHAVEWORKEDWITH</th>
      <th>NEWCOLLABTOOLSWANTTOWORKWITH</th>
      <th>OPSYS</th>
      <th>NEWSTUCK</th>
      <th>NEWSOSITES</th>
      <th>SOVISITFREQ</th>
      <th>SOACCOUNT</th>
      <th>SOPARTFREQ</th>
      <th>SOCOMM</th>
      <th>NEWOTHERCOMMS</th>
      <th>AGE</th>
      <th>GENDER</th>
      <th>TRANS</th>
      <th>SEXUALITY</th>
      <th>ETHNICITY</th>
      <th>ACCESSIBILITY</th>
      <th>MENTALHEALTH</th>
      <th>SURVEYLENGTH</th>
      <th>SURVEYEASE</th>
      <th>CONVERTEDCOMPYEARLY</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>Slovakia</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Secondary school (e.g. American high school, G...</td>
      <td>18 - 24 years</td>
      <td>Coding Bootcamp;Other online resources (ex: vi...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Developer, mobile</td>
      <td>20 to 99 employees</td>
      <td>EUR European Euro</td>
      <td>4800.0</td>
      <td>Monthly</td>
      <td>C++;HTML/CSS;JavaScript;Objective-C;PHP;Swift</td>
      <td>Swift</td>
      <td>PostgreSQL;SQLite</td>
      <td>SQLite</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Laravel;Symfony</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>PHPStorm;Xcode</td>
      <td>Atom;Xcode</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>Multiple times per day</td>
      <td>Yes</td>
      <td>A few times per month or weekly</td>
      <td>Yes, definitely</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>62268.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>I am a student who is learning to code</td>
      <td>Student, full-time</td>
      <td>Netherlands</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>7</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>JavaScript;Python</td>
      <td>NaN</td>
      <td>PostgreSQL</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Angular;Flask;Vue.js</td>
      <td>NaN</td>
      <td>Cordova</td>
      <td>NaN</td>
      <td>Docker;Git;Yarn</td>
      <td>Git</td>
      <td>Android Studio;IntelliJ;Notepad++;PyCharm</td>
      <td>NaN</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Google it</td>
      <td>Stack Overflow</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>Daily or almost daily</td>
      <td>Yes, definitely</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>I am not primarily a developer, but I write co...</td>
      <td>Student, full-time</td>
      <td>Russian Federation</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Assembly;C;Python;R;Rust</td>
      <td>Julia;Python;Rust</td>
      <td>SQLite</td>
      <td>SQLite</td>
      <td>Heroku</td>
      <td>NaN</td>
      <td>Flask</td>
      <td>Flask</td>
      <td>NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>Keras;NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>IPython/Jupyter;PyCharm;RStudio;Sublime Text;V...</td>
      <td>IPython/Jupyter;RStudio;Sublime Text;Visual St...</td>
      <td>MacOS</td>
      <td>Visit Stack Overflow;Google it;Watch help / tu...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Multiple times per day</td>
      <td>Yes</td>
      <td>Multiple times per day</td>
      <td>Yes, definitely</td>
      <td>Yes</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>Austria</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>11 - 17 years</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Developer, front-end</td>
      <td>100 to 499 employees</td>
      <td>EUR European Euro</td>
      <td>NaN</td>
      <td>Monthly</td>
      <td>JavaScript;TypeScript</td>
      <td>JavaScript;TypeScript</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Angular;jQuery</td>
      <td>Angular;jQuery</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>Daily or almost daily</td>
      <td>Neutral</td>
      <td>No</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>I am deaf / hard of hearing</td>
      <td>NaN</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>United Kingdom of Great Britain and Northern I...</td>
      <td>NaN</td>
      <td>England</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>5 - 10 years</td>
      <td>Friend or family member</td>
      <td>17</td>
      <td>10</td>
      <td>Developer, desktop or enterprise applications;...</td>
      <td>Just me - I am a freelancer, sole proprietor, ...</td>
      <td>GBP\tPound sterling</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bash/Shell;HTML/CSS;Python;SQL</td>
      <td>Bash/Shell;HTML/CSS;Python;SQL</td>
      <td>Elasticsearch;PostgreSQL;Redis</td>
      <td>Cassandra;Elasticsearch;PostgreSQL;Redis</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Flask</td>
      <td>Flask</td>
      <td>Apache Spark;Hadoop;NumPy;Pandas</td>
      <td>Hadoop;NumPy;Pandas</td>
      <td>Docker;Git;Kubernetes;Yarn</td>
      <td>Docker;Git;Kubernetes;Yarn</td>
      <td>Atom;IPython/Jupyter;Notepad++;PyCharm;Vim</td>
      <td>Atom;IPython/Jupyter;Notepad++;PyCharm;Vim;Vis...</td>
      <td>Linux-based</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>A few times per week</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>NaN</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>NaN</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>83434</th>
      <td>83435</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>United States of America</td>
      <td>Texas</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>6</td>
      <td>5</td>
      <td>Developer, back-end</td>
      <td>20 to 99 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>160500.0</td>
      <td>Yearly</td>
      <td>Clojure;Kotlin;SQL</td>
      <td>Clojure</td>
      <td>Oracle;SQLite</td>
      <td>SQLite</td>
      <td>AWS</td>
      <td>AWS</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>Git;Kubernetes</td>
      <td>IntelliJ;Sublime Text;Vim;Visual Studio Code</td>
      <td>Sublime Text;Vim</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Google it</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>No</td>
      <td>NaN</td>
      <td>No, not at all</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>I have a concentration and/or memory disorder ...</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>160500.0</td>
    </tr>
    <tr>
      <th>83435</th>
      <td>83436</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>Benin</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>4</td>
      <td>2</td>
      <td>Developer, full-stack</td>
      <td>Just me - I am a freelancer, sole proprietor, ...</td>
      <td>XOF\tWest African CFA franc</td>
      <td>200000.0</td>
      <td>Monthly</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Firebase;MariaDB;MySQL;PostgreSQL;Redis;SQLite</td>
      <td>Firebase;MariaDB;MongoDB;MySQL;PostgreSQL;Redi...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Django;jQuery;Laravel;React.js;Ruby on Rails</td>
      <td>Django;Express;jQuery;Laravel;React.js;Ruby on...</td>
      <td>Flutter;Qt</td>
      <td>NaN</td>
      <td>Git;Unity 3D;Unreal Engine</td>
      <td>Docker;Git;Kubernetes</td>
      <td>Android Studio;Eclipse;Emacs;IntelliJ;NetBeans...</td>
      <td>Emacs;IntelliJ;PHPStorm;PyCharm;RStudio;Sublim...</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Multiple times per day</td>
      <td>Yes</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Black or of African descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>3960.0</td>
    </tr>
    <tr>
      <th>83436</th>
      <td>83437</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>United States of America</td>
      <td>New Jersey</td>
      <td>NaN</td>
      <td>Secondary school (e.g. American high school, G...</td>
      <td>11 - 17 years</td>
      <td>School</td>
      <td>10</td>
      <td>4</td>
      <td>Data scientist or machine learning specialist;...</td>
      <td>10,000 or more employees</td>
      <td>USD\tUnited States dollar</td>
      <td>1800.0</td>
      <td>Weekly</td>
      <td>Groovy;Java;Python</td>
      <td>Java;Python</td>
      <td>DynamoDB;Elasticsearch;MongoDB;PostgreSQL;Redis</td>
      <td>DynamoDB;Redis</td>
      <td>AWS;Google Cloud Platform</td>
      <td>AWS</td>
      <td>FastAPI;Flask</td>
      <td>FastAPI;Flask</td>
      <td>Hadoop;Keras;NumPy;Pandas</td>
      <td>Apache Spark;Hadoop;Keras;NumPy;Pandas;TensorFlow</td>
      <td>Ansible;Docker;Git;Terraform</td>
      <td>Docker;Git;Kubernetes;Terraform</td>
      <td>Android Studio;Eclipse;IntelliJ;IPython/Jupyte...</td>
      <td>IntelliJ;IPython/Jupyter;Notepad++;Vim</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>Yes</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>No, not really</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>NaN</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>90000.0</td>
    </tr>
    <tr>
      <th>83437</th>
      <td>83438</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>Canada</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Online Courses or Certification;Books / Physic...</td>
      <td>5</td>
      <td>3</td>
      <td>Developer, back-end</td>
      <td>20 to 99 employees</td>
      <td>CAD\tCanadian dollar</td>
      <td>90000.0</td>
      <td>Monthly</td>
      <td>Bash/Shell;JavaScript;Node.js;Python</td>
      <td>Go;Rust</td>
      <td>Cassandra;Elasticsearch;MongoDB;PostgreSQL;Redis</td>
      <td>NaN</td>
      <td>Heroku</td>
      <td>AWS;DigitalOcean</td>
      <td>Django;Express;Flask;React.js</td>
      <td>NaN</td>
      <td>NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>Ansible;Docker;Git;Terraform</td>
      <td>Kubernetes;Terraform</td>
      <td>PyCharm;Sublime Text</td>
      <td>NaN</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>A few times per month or weekly</td>
      <td>Yes</td>
      <td>Less than once per month or monthly</td>
      <td>No, not really</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>I have a mood or emotional disorder (e.g. depr...</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>816816.0</td>
    </tr>
    <tr>
      <th>83438</th>
      <td>83439</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>Brazil</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Professional degree (JD, MD, etc.)</td>
      <td>11 - 17 years</td>
      <td>School</td>
      <td>14</td>
      <td>4</td>
      <td>Developer, front-end;Developer, full-stack;Dev...</td>
      <td>I don’t know</td>
      <td>BRL\tBrazilian real</td>
      <td>7700.0</td>
      <td>Monthly</td>
      <td>Delphi;Elixir;HTML/CSS;Java;JavaScript</td>
      <td>Elixir;HTML/CSS;Java;JavaScript;Node.js;PHP;SQ...</td>
      <td>Oracle;PostgreSQL</td>
      <td>Elasticsearch;MongoDB;MySQL;Oracle;PostgreSQL;...</td>
      <td>Microsoft Azure</td>
      <td>AWS</td>
      <td>Angular;Spring</td>
      <td>Express;Laravel;Spring;Symfony</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>Docker;Git;Kubernetes</td>
      <td>IntelliJ;Visual Studio Code</td>
      <td>IntelliJ;PHPStorm;Visual Studio Code</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange;Stack Overflow f...</td>
      <td>A few times per week</td>
      <td>Yes</td>
      <td>A few times per week</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Hispanic or Latino/a/x</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>21168.0</td>
    </tr>
  </tbody>
</table>
<p>83439 rows × 48 columns</p>
</div>




```python
# Cambiar el nombre a un campo
datos.rename(columns={'RESPONSEID':'ID'})
# Para establecerlo
# datos.rename(columns={'RESPONSEID':'ID'}, inplace=True)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ID</th>
      <th>MAINBRANCH</th>
      <th>EMPLOYMENT</th>
      <th>COUNTRY</th>
      <th>USSTATE</th>
      <th>UKCOUNTRY</th>
      <th>EDLEVEL</th>
      <th>AGE1STCODE</th>
      <th>LEARNCODE</th>
      <th>YEARSCODE</th>
      <th>YEARSCODEPRO</th>
      <th>DEVTYPE</th>
      <th>ORGSIZE</th>
      <th>CURRENCY</th>
      <th>COMPTOTAL</th>
      <th>COMPFREQ</th>
      <th>LANGUAGEHAVEWORKEDWITH</th>
      <th>LANGUAGEWANTTOWORKWITH</th>
      <th>DATABASEHAVEWORKEDWITH</th>
      <th>DATABASEWANTTOWORKWITH</th>
      <th>PLATFORMHAVEWORKEDWITH</th>
      <th>PLATFORMWANTTOWORKWITH</th>
      <th>WEBFRAMEHAVEWORKEDWITH</th>
      <th>WEBFRAMEWANTTOWORKWITH</th>
      <th>MISCTECHHAVEWORKEDWITH</th>
      <th>MISCTECHWANTTOWORKWITH</th>
      <th>TOOLSTECHHAVEWORKEDWITH</th>
      <th>TOOLSTECHWANTTOWORKWITH</th>
      <th>NEWCOLLABTOOLSHAVEWORKEDWITH</th>
      <th>NEWCOLLABTOOLSWANTTOWORKWITH</th>
      <th>OPSYS</th>
      <th>NEWSTUCK</th>
      <th>NEWSOSITES</th>
      <th>SOVISITFREQ</th>
      <th>SOACCOUNT</th>
      <th>SOPARTFREQ</th>
      <th>SOCOMM</th>
      <th>NEWOTHERCOMMS</th>
      <th>AGE</th>
      <th>GENDER</th>
      <th>TRANS</th>
      <th>SEXUALITY</th>
      <th>ETHNICITY</th>
      <th>ACCESSIBILITY</th>
      <th>MENTALHEALTH</th>
      <th>SURVEYLENGTH</th>
      <th>SURVEYEASE</th>
      <th>CONVERTEDCOMPYEARLY</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>Slovakia</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Secondary school (e.g. American high school, G...</td>
      <td>18 - 24 years</td>
      <td>Coding Bootcamp;Other online resources (ex: vi...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Developer, mobile</td>
      <td>20 to 99 employees</td>
      <td>EUR European Euro</td>
      <td>4800.0</td>
      <td>Monthly</td>
      <td>C++;HTML/CSS;JavaScript;Objective-C;PHP;Swift</td>
      <td>Swift</td>
      <td>PostgreSQL;SQLite</td>
      <td>SQLite</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Laravel;Symfony</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>PHPStorm;Xcode</td>
      <td>Atom;Xcode</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>Multiple times per day</td>
      <td>Yes</td>
      <td>A few times per month or weekly</td>
      <td>Yes, definitely</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>62268.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>I am a student who is learning to code</td>
      <td>Student, full-time</td>
      <td>Netherlands</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>7</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>JavaScript;Python</td>
      <td>NaN</td>
      <td>PostgreSQL</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Angular;Flask;Vue.js</td>
      <td>NaN</td>
      <td>Cordova</td>
      <td>NaN</td>
      <td>Docker;Git;Yarn</td>
      <td>Git</td>
      <td>Android Studio;IntelliJ;Notepad++;PyCharm</td>
      <td>NaN</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Google it</td>
      <td>Stack Overflow</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>Daily or almost daily</td>
      <td>Yes, definitely</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>I am not primarily a developer, but I write co...</td>
      <td>Student, full-time</td>
      <td>Russian Federation</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Assembly;C;Python;R;Rust</td>
      <td>Julia;Python;Rust</td>
      <td>SQLite</td>
      <td>SQLite</td>
      <td>Heroku</td>
      <td>NaN</td>
      <td>Flask</td>
      <td>Flask</td>
      <td>NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>Keras;NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>IPython/Jupyter;PyCharm;RStudio;Sublime Text;V...</td>
      <td>IPython/Jupyter;RStudio;Sublime Text;Visual St...</td>
      <td>MacOS</td>
      <td>Visit Stack Overflow;Google it;Watch help / tu...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Multiple times per day</td>
      <td>Yes</td>
      <td>Multiple times per day</td>
      <td>Yes, definitely</td>
      <td>Yes</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>Austria</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>11 - 17 years</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Developer, front-end</td>
      <td>100 to 499 employees</td>
      <td>EUR European Euro</td>
      <td>NaN</td>
      <td>Monthly</td>
      <td>JavaScript;TypeScript</td>
      <td>JavaScript;TypeScript</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Angular;jQuery</td>
      <td>Angular;jQuery</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>Daily or almost daily</td>
      <td>Neutral</td>
      <td>No</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>I am deaf / hard of hearing</td>
      <td>NaN</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>United Kingdom of Great Britain and Northern I...</td>
      <td>NaN</td>
      <td>England</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>5 - 10 years</td>
      <td>Friend or family member</td>
      <td>17</td>
      <td>10</td>
      <td>Developer, desktop or enterprise applications;...</td>
      <td>Just me - I am a freelancer, sole proprietor, ...</td>
      <td>GBP\tPound sterling</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bash/Shell;HTML/CSS;Python;SQL</td>
      <td>Bash/Shell;HTML/CSS;Python;SQL</td>
      <td>Elasticsearch;PostgreSQL;Redis</td>
      <td>Cassandra;Elasticsearch;PostgreSQL;Redis</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Flask</td>
      <td>Flask</td>
      <td>Apache Spark;Hadoop;NumPy;Pandas</td>
      <td>Hadoop;NumPy;Pandas</td>
      <td>Docker;Git;Kubernetes;Yarn</td>
      <td>Docker;Git;Kubernetes;Yarn</td>
      <td>Atom;IPython/Jupyter;Notepad++;PyCharm;Vim</td>
      <td>Atom;IPython/Jupyter;Notepad++;PyCharm;Vim;Vis...</td>
      <td>Linux-based</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>A few times per week</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>NaN</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>NaN</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>83434</th>
      <td>83435</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>United States of America</td>
      <td>Texas</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>6</td>
      <td>5</td>
      <td>Developer, back-end</td>
      <td>20 to 99 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>160500.0</td>
      <td>Yearly</td>
      <td>Clojure;Kotlin;SQL</td>
      <td>Clojure</td>
      <td>Oracle;SQLite</td>
      <td>SQLite</td>
      <td>AWS</td>
      <td>AWS</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>Git;Kubernetes</td>
      <td>IntelliJ;Sublime Text;Vim;Visual Studio Code</td>
      <td>Sublime Text;Vim</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Google it</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>No</td>
      <td>NaN</td>
      <td>No, not at all</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>I have a concentration and/or memory disorder ...</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>160500.0</td>
    </tr>
    <tr>
      <th>83435</th>
      <td>83436</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>Benin</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>4</td>
      <td>2</td>
      <td>Developer, full-stack</td>
      <td>Just me - I am a freelancer, sole proprietor, ...</td>
      <td>XOF\tWest African CFA franc</td>
      <td>200000.0</td>
      <td>Monthly</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Firebase;MariaDB;MySQL;PostgreSQL;Redis;SQLite</td>
      <td>Firebase;MariaDB;MongoDB;MySQL;PostgreSQL;Redi...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Django;jQuery;Laravel;React.js;Ruby on Rails</td>
      <td>Django;Express;jQuery;Laravel;React.js;Ruby on...</td>
      <td>Flutter;Qt</td>
      <td>NaN</td>
      <td>Git;Unity 3D;Unreal Engine</td>
      <td>Docker;Git;Kubernetes</td>
      <td>Android Studio;Eclipse;Emacs;IntelliJ;NetBeans...</td>
      <td>Emacs;IntelliJ;PHPStorm;PyCharm;RStudio;Sublim...</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Multiple times per day</td>
      <td>Yes</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Black or of African descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>3960.0</td>
    </tr>
    <tr>
      <th>83436</th>
      <td>83437</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>United States of America</td>
      <td>New Jersey</td>
      <td>NaN</td>
      <td>Secondary school (e.g. American high school, G...</td>
      <td>11 - 17 years</td>
      <td>School</td>
      <td>10</td>
      <td>4</td>
      <td>Data scientist or machine learning specialist;...</td>
      <td>10,000 or more employees</td>
      <td>USD\tUnited States dollar</td>
      <td>1800.0</td>
      <td>Weekly</td>
      <td>Groovy;Java;Python</td>
      <td>Java;Python</td>
      <td>DynamoDB;Elasticsearch;MongoDB;PostgreSQL;Redis</td>
      <td>DynamoDB;Redis</td>
      <td>AWS;Google Cloud Platform</td>
      <td>AWS</td>
      <td>FastAPI;Flask</td>
      <td>FastAPI;Flask</td>
      <td>Hadoop;Keras;NumPy;Pandas</td>
      <td>Apache Spark;Hadoop;Keras;NumPy;Pandas;TensorFlow</td>
      <td>Ansible;Docker;Git;Terraform</td>
      <td>Docker;Git;Kubernetes;Terraform</td>
      <td>Android Studio;Eclipse;IntelliJ;IPython/Jupyte...</td>
      <td>IntelliJ;IPython/Jupyter;Notepad++;Vim</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>Yes</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>No, not really</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>NaN</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>90000.0</td>
    </tr>
    <tr>
      <th>83437</th>
      <td>83438</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>Canada</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Online Courses or Certification;Books / Physic...</td>
      <td>5</td>
      <td>3</td>
      <td>Developer, back-end</td>
      <td>20 to 99 employees</td>
      <td>CAD\tCanadian dollar</td>
      <td>90000.0</td>
      <td>Monthly</td>
      <td>Bash/Shell;JavaScript;Node.js;Python</td>
      <td>Go;Rust</td>
      <td>Cassandra;Elasticsearch;MongoDB;PostgreSQL;Redis</td>
      <td>NaN</td>
      <td>Heroku</td>
      <td>AWS;DigitalOcean</td>
      <td>Django;Express;Flask;React.js</td>
      <td>NaN</td>
      <td>NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>Ansible;Docker;Git;Terraform</td>
      <td>Kubernetes;Terraform</td>
      <td>PyCharm;Sublime Text</td>
      <td>NaN</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>A few times per month or weekly</td>
      <td>Yes</td>
      <td>Less than once per month or monthly</td>
      <td>No, not really</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>I have a mood or emotional disorder (e.g. depr...</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>816816.0</td>
    </tr>
    <tr>
      <th>83438</th>
      <td>83439</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>Brazil</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Professional degree (JD, MD, etc.)</td>
      <td>11 - 17 years</td>
      <td>School</td>
      <td>14</td>
      <td>4</td>
      <td>Developer, front-end;Developer, full-stack;Dev...</td>
      <td>I don’t know</td>
      <td>BRL\tBrazilian real</td>
      <td>7700.0</td>
      <td>Monthly</td>
      <td>Delphi;Elixir;HTML/CSS;Java;JavaScript</td>
      <td>Elixir;HTML/CSS;Java;JavaScript;Node.js;PHP;SQ...</td>
      <td>Oracle;PostgreSQL</td>
      <td>Elasticsearch;MongoDB;MySQL;Oracle;PostgreSQL;...</td>
      <td>Microsoft Azure</td>
      <td>AWS</td>
      <td>Angular;Spring</td>
      <td>Express;Laravel;Spring;Symfony</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>Docker;Git;Kubernetes</td>
      <td>IntelliJ;Visual Studio Code</td>
      <td>IntelliJ;PHPStorm;Visual Studio Code</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange;Stack Overflow f...</td>
      <td>A few times per week</td>
      <td>Yes</td>
      <td>A few times per week</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Hispanic or Latino/a/x</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>21168.0</td>
    </tr>
  </tbody>
</table>
<p>83439 rows × 48 columns</p>
</div>




```python
datos.loc[1]
```




    RESPONSEID                                                                      2
    MAINBRANCH                                 I am a student who is learning to code
    EMPLOYMENT                                                     Student, full-time
    COUNTRY                                                               Netherlands
    USSTATE                                                                       NaN
    UKCOUNTRY                                                                     NaN
    EDLEVEL                              Bachelor’s degree (B.A., B.S., B.Eng., etc.)
    AGE1STCODE                                                          11 - 17 years
    LEARNCODE                       Other online resources (ex: videos, blogs, etc...
    YEARSCODE                                                                       7
    YEARSCODEPRO                                                                  NaN
    DEVTYPE                                                                       NaN
    ORGSIZE                                                                       NaN
    CURRENCY                                                                      NaN
    COMPTOTAL                                                                     NaN
    COMPFREQ                                                                      NaN
    LANGUAGEHAVEWORKEDWITH                                          JavaScript;Python
    LANGUAGEWANTTOWORKWITH                                                        NaN
    DATABASEHAVEWORKEDWITH                                                 PostgreSQL
    DATABASEWANTTOWORKWITH                                                        NaN
    PLATFORMHAVEWORKEDWITH                                                        NaN
    PLATFORMWANTTOWORKWITH                                                        NaN
    WEBFRAMEHAVEWORKEDWITH                                       Angular;Flask;Vue.js
    WEBFRAMEWANTTOWORKWITH                                                        NaN
    MISCTECHHAVEWORKEDWITH                                                    Cordova
    MISCTECHWANTTOWORKWITH                                                        NaN
    TOOLSTECHHAVEWORKEDWITH                                           Docker;Git;Yarn
    TOOLSTECHWANTTOWORKWITH                                                       Git
    NEWCOLLABTOOLSHAVEWORKEDWITH            Android Studio;IntelliJ;Notepad++;PyCharm
    NEWCOLLABTOOLSWANTTOWORKWITH                                                  NaN
    OPSYS                                                                     Windows
    NEWSTUCK                                           Visit Stack Overflow;Google it
    NEWSOSITES                                                         Stack Overflow
    SOVISITFREQ                                                 Daily or almost daily
    SOACCOUNT                                                                     Yes
    SOPARTFREQ                                                  Daily or almost daily
    SOCOMM                                                            Yes, definitely
    NEWOTHERCOMMS                                                                  No
    AGE                                                               18-24 years old
    GENDER                                                                        Man
    TRANS                                                                          No
    SEXUALITY                                                 Straight / Heterosexual
    ETHNICITY                                            White or of European descent
    ACCESSIBILITY                                                   None of the above
    MENTALHEALTH                                                    None of the above
    SURVEYLENGTH                                                Appropriate in length
    SURVEYEASE                                                                   Easy
    CONVERTEDCOMPYEARLY                                                           NaN
    Name: 1, dtype: object




```python
# Cambiar un dato a un registro
datos.loc[1, ['COUNTRY', 'LANGUAGEWANTTOWORKWITH']] = ['Spain', 'Python']
```


```python
datos.loc[1]
```




    RESPONSEID                                                                      2
    MAINBRANCH                                 I am a student who is learning to code
    EMPLOYMENT                                                     Student, full-time
    COUNTRY                                                                     Spain
    USSTATE                                                                       NaN
    UKCOUNTRY                                                                     NaN
    EDLEVEL                              Bachelor’s degree (B.A., B.S., B.Eng., etc.)
    AGE1STCODE                                                          11 - 17 years
    LEARNCODE                       Other online resources (ex: videos, blogs, etc...
    YEARSCODE                                                                       7
    YEARSCODEPRO                                                                  NaN
    DEVTYPE                                                                       NaN
    ORGSIZE                                                                       NaN
    CURRENCY                                                                      NaN
    COMPTOTAL                                                                     NaN
    COMPFREQ                                                                      NaN
    LANGUAGEHAVEWORKEDWITH                                          JavaScript;Python
    LANGUAGEWANTTOWORKWITH                                                     Python
    DATABASEHAVEWORKEDWITH                                                 PostgreSQL
    DATABASEWANTTOWORKWITH                                                        NaN
    PLATFORMHAVEWORKEDWITH                                                        NaN
    PLATFORMWANTTOWORKWITH                                                        NaN
    WEBFRAMEHAVEWORKEDWITH                                       Angular;Flask;Vue.js
    WEBFRAMEWANTTOWORKWITH                                                        NaN
    MISCTECHHAVEWORKEDWITH                                                    Cordova
    MISCTECHWANTTOWORKWITH                                                        NaN
    TOOLSTECHHAVEWORKEDWITH                                           Docker;Git;Yarn
    TOOLSTECHWANTTOWORKWITH                                                       Git
    NEWCOLLABTOOLSHAVEWORKEDWITH            Android Studio;IntelliJ;Notepad++;PyCharm
    NEWCOLLABTOOLSWANTTOWORKWITH                                                  NaN
    OPSYS                                                                     Windows
    NEWSTUCK                                           Visit Stack Overflow;Google it
    NEWSOSITES                                                         Stack Overflow
    SOVISITFREQ                                                 Daily or almost daily
    SOACCOUNT                                                                     Yes
    SOPARTFREQ                                                  Daily or almost daily
    SOCOMM                                                            Yes, definitely
    NEWOTHERCOMMS                                                                  No
    AGE                                                               18-24 years old
    GENDER                                                                        Man
    TRANS                                                                          No
    SEXUALITY                                                 Straight / Heterosexual
    ETHNICITY                                            White or of European descent
    ACCESSIBILITY                                                   None of the above
    MENTALHEALTH                                                    None of the above
    SURVEYLENGTH                                                Appropriate in length
    SURVEYEASE                                                                   Easy
    CONVERTEDCOMPYEARLY                                                           NaN
    Name: 1, dtype: object




```python
datos.loc[1, 'COUNTRY'] = 'Netherlands'
datos.at[1, 'COUNTRY'] = 'Netherlands' # Idéntico resultado a datos.loc
```


```python
filtro_modificar_pais = (datos['COUNTRY'] == 'Spain')
datos.loc[filtro_modificar_pais, 'COUNTRY'] = 'España'
```


```python
datos[filtrar_paises]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>RESPONSEID</th>
      <th>MAINBRANCH</th>
      <th>EMPLOYMENT</th>
      <th>COUNTRY</th>
      <th>USSTATE</th>
      <th>UKCOUNTRY</th>
      <th>EDLEVEL</th>
      <th>AGE1STCODE</th>
      <th>LEARNCODE</th>
      <th>YEARSCODE</th>
      <th>YEARSCODEPRO</th>
      <th>DEVTYPE</th>
      <th>ORGSIZE</th>
      <th>CURRENCY</th>
      <th>COMPTOTAL</th>
      <th>COMPFREQ</th>
      <th>LANGUAGEHAVEWORKEDWITH</th>
      <th>LANGUAGEWANTTOWORKWITH</th>
      <th>DATABASEHAVEWORKEDWITH</th>
      <th>DATABASEWANTTOWORKWITH</th>
      <th>PLATFORMHAVEWORKEDWITH</th>
      <th>PLATFORMWANTTOWORKWITH</th>
      <th>WEBFRAMEHAVEWORKEDWITH</th>
      <th>WEBFRAMEWANTTOWORKWITH</th>
      <th>MISCTECHHAVEWORKEDWITH</th>
      <th>MISCTECHWANTTOWORKWITH</th>
      <th>TOOLSTECHHAVEWORKEDWITH</th>
      <th>TOOLSTECHWANTTOWORKWITH</th>
      <th>NEWCOLLABTOOLSHAVEWORKEDWITH</th>
      <th>NEWCOLLABTOOLSWANTTOWORKWITH</th>
      <th>OPSYS</th>
      <th>NEWSTUCK</th>
      <th>NEWSOSITES</th>
      <th>SOVISITFREQ</th>
      <th>SOACCOUNT</th>
      <th>SOPARTFREQ</th>
      <th>SOCOMM</th>
      <th>NEWOTHERCOMMS</th>
      <th>AGE</th>
      <th>GENDER</th>
      <th>TRANS</th>
      <th>SEXUALITY</th>
      <th>ETHNICITY</th>
      <th>ACCESSIBILITY</th>
      <th>MENTALHEALTH</th>
      <th>SURVEYLENGTH</th>
      <th>SURVEYEASE</th>
      <th>CONVERTEDCOMPYEARLY</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>11</th>
      <td>12</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>ESPAÑA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>12</td>
      <td>5</td>
      <td>Developer, back-end</td>
      <td>10 to 19 employees</td>
      <td>EUR European Euro</td>
      <td>43000.0</td>
      <td>Yearly</td>
      <td>Bash/Shell;HTML/CSS;JavaScript;Node.js;SQL;Typ...</td>
      <td>C++;Clojure;JavaScript;Node.js;Rust;SQL;TypeSc...</td>
      <td>PostgreSQL</td>
      <td>MongoDB;PostgreSQL;Redis</td>
      <td>AWS</td>
      <td>NaN</td>
      <td>Express;React.js;Vue.js</td>
      <td>Express;Vue.js</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Git</td>
      <td>Git</td>
      <td>Atom</td>
      <td>Atom</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>Less than once per month or monthly</td>
      <td>Yes, somewhat</td>
      <td>Yes</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent;Hispanic or Latin...</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Too long</td>
      <td>Easy</td>
      <td>46482.0</td>
    </tr>
    <tr>
      <th>23</th>
      <td>24</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>FRANCE</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>11 - 17 years</td>
      <td>School;Online Courses or Certification</td>
      <td>9</td>
      <td>2</td>
      <td>Engineer, data;Data scientist or machine learn...</td>
      <td>10 to 19 employees</td>
      <td>EUR European Euro</td>
      <td>36000.0</td>
      <td>Yearly</td>
      <td>JavaScript;Python</td>
      <td>Python;SQL</td>
      <td>MySQL</td>
      <td>Elasticsearch;MongoDB;MySQL;PostgreSQL</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Apache Spark;Keras;NumPy;Pandas;TensorFlow;Tor...</td>
      <td>Apache Spark;Keras;NumPy;Pandas;TensorFlow;Tor...</td>
      <td>Docker;Git</td>
      <td>Docker;Git;Kubernetes</td>
      <td>Visual Studio Code</td>
      <td>Visual Studio Code</td>
      <td>Linux-based</td>
      <td>Visit Stack Overflow;Google it</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>Yes</td>
      <td>Less than once per month or monthly</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>NaN</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>38915.0</td>
    </tr>
    <tr>
      <th>41</th>
      <td>42</td>
      <td>I am not primarily a developer, but I write co...</td>
      <td>Employed full-time</td>
      <td>FRANCE</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>6</td>
      <td>3</td>
      <td>Academic researcher;Scientist;Student</td>
      <td>20 to 99 employees</td>
      <td>EUR European Euro</td>
      <td>24000.0</td>
      <td>Yearly</td>
      <td>Bash/Shell;C#;C++;Python</td>
      <td>C++;Python</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>.NET Framework;.NET Core / .NET 5;NumPy;Pandas;Qt</td>
      <td>.NET Framework;.NET Core / .NET 5;NumPy;Pandas;Qt</td>
      <td>Git</td>
      <td>Git</td>
      <td>IPython/Jupyter;Notepad++;Visual Studio;Visual...</td>
      <td>IPython/Jupyter;Visual Studio Code</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Google it;Watch help / tu...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>A few times per week</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Hispanic or Latino/a/x</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Too long</td>
      <td>Easy</td>
      <td>25944.0</td>
    </tr>
    <tr>
      <th>44</th>
      <td>45</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>FRANCE</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>18 - 24 years</td>
      <td>School</td>
      <td>6</td>
      <td>Less than 1 year</td>
      <td>Developer, full-stack</td>
      <td>10 to 19 employees</td>
      <td>EUR European Euro</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>HTML/CSS;JavaScript;Node.js;Python;R;SQL;TypeS...</td>
      <td>NaN</td>
      <td>PostgreSQL</td>
      <td>NaN</td>
      <td>Google Cloud Platform</td>
      <td>NaN</td>
      <td>Django;Flask;Vue.js</td>
      <td>NaN</td>
      <td>NumPy;TensorFlow</td>
      <td>NaN</td>
      <td>Docker;Git;Kubernetes</td>
      <td>NaN</td>
      <td>Visual Studio</td>
      <td>NaN</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Google it</td>
      <td>Stack Overflow</td>
      <td>A few times per week</td>
      <td>No</td>
      <td>NaN</td>
      <td>Neutral</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Woman</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>68</th>
      <td>69</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>ESPAÑA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>11 - 17 years</td>
      <td>School</td>
      <td>20</td>
      <td>10</td>
      <td>Developer, back-end</td>
      <td>10,000 or more employees</td>
      <td>EUR European Euro</td>
      <td>54000.0</td>
      <td>Yearly</td>
      <td>Bash/Shell;JavaScript;Node.js;TypeScript</td>
      <td>JavaScript;Node.js;Python;TypeScript</td>
      <td>DynamoDB</td>
      <td>DynamoDB;Firebase</td>
      <td>AWS</td>
      <td>AWS;Microsoft Azure</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Terraform</td>
      <td>Terraform</td>
      <td>Notepad++;Vim;Visual Studio Code</td>
      <td>Vim;Visual Studio Code</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>A few times per week</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>NaN</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>58373.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>83313</th>
      <td>83314</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>ESPAÑA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Professional degree (JD, MD, etc.)</td>
      <td>11 - 17 years</td>
      <td>Coding Bootcamp;Other online resources (ex: vi...</td>
      <td>10</td>
      <td>5</td>
      <td>Developer, front-end;Developer, full-stack;Dev...</td>
      <td>2 to 9 employees</td>
      <td>EUR European Euro</td>
      <td>2300.0</td>
      <td>Monthly</td>
      <td>Elixir;JavaScript;Ruby</td>
      <td>Elixir;Ruby</td>
      <td>Firebase;PostgreSQL;Redis</td>
      <td>Firebase;PostgreSQL;Redis</td>
      <td>AWS;DigitalOcean;Google Cloud Platform</td>
      <td>AWS;DigitalOcean;Google Cloud Platform</td>
      <td>jQuery;Ruby on Rails</td>
      <td>Django;Ruby on Rails;Vue.js</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Ansible;Docker;Git;Yarn</td>
      <td>Ansible;Docker;Git;Kubernetes;Yarn</td>
      <td>RubyMine;Visual Studio Code</td>
      <td>Visual Studio Code</td>
      <td>MacOS</td>
      <td>Visit Stack Overflow;Google it</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Multiple times per day</td>
      <td>Yes</td>
      <td>Less than once per month or monthly</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Hispanic or Latino/a/x</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>29832.0</td>
    </tr>
    <tr>
      <th>83326</th>
      <td>83327</td>
      <td>I am a student who is learning to code</td>
      <td>Student, full-time</td>
      <td>FRANCE</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Something else</td>
      <td>11 - 17 years</td>
      <td>Online Courses or Certification</td>
      <td>5</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Python</td>
      <td>HTML/CSS;JavaScript;Python</td>
      <td>MongoDB;PostgreSQL</td>
      <td>MongoDB</td>
      <td>Heroku;Microsoft Azure</td>
      <td>NaN</td>
      <td>Django;Flask;React.js</td>
      <td>Flask;React.js</td>
      <td>Keras;NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>Keras;NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>Git</td>
      <td>Git</td>
      <td>IPython/Jupyter;Visual Studio Code</td>
      <td>IPython/Jupyter;Visual Studio Code</td>
      <td>Windows Subsystem for Linux (WSL)</td>
      <td>Visit Stack Overflow;Google it;Do other work a...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>A few times per week</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>Appropriate in length</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>83333</th>
      <td>83334</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>FRANCE</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>18 - 24 years</td>
      <td>Coding Bootcamp;Other online resources (ex: vi...</td>
      <td>4</td>
      <td>3</td>
      <td>Developer, full-stack</td>
      <td>100 to 499 employees</td>
      <td>EUR European Euro</td>
      <td>50000.0</td>
      <td>Yearly</td>
      <td>JavaScript;Node.js;Ruby;SQL;TypeScript</td>
      <td>C#;C++;Crystal;Go;JavaScript;Node.js;Python;Ru...</td>
      <td>MySQL;Redis</td>
      <td>Elasticsearch;Firebase;MySQL;PostgreSQL;Redis</td>
      <td>Heroku</td>
      <td>AWS;DigitalOcean;Google Cloud Platform;Heroku</td>
      <td>React.js;Ruby on Rails</td>
      <td>ASP.NET;ASP.NET Core ;Django;Express;FastAPI;F...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Git</td>
      <td>Chef;Deno;Git</td>
      <td>Visual Studio Code</td>
      <td>PyCharm;Visual Studio;Visual Studio Code;Xcode</td>
      <td>MacOS</td>
      <td>Google it</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>Not sure/can't remember</td>
      <td>NaN</td>
      <td>Yes, somewhat</td>
      <td>Yes</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>54049.0</td>
    </tr>
    <tr>
      <th>83344</th>
      <td>83345</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>FRANCE</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>18 - 24 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>10</td>
      <td>5</td>
      <td>Developer, back-end</td>
      <td>20 to 99 employees</td>
      <td>EUR European Euro</td>
      <td>50000.0</td>
      <td>Yearly</td>
      <td>HTML/CSS;Python;SQL</td>
      <td>HTML/CSS;Python;Rust;SQL;TypeScript</td>
      <td>MariaDB</td>
      <td>MariaDB</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Angular.js;FastAPI</td>
      <td>Angular;FastAPI;React.js;Vue.js</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>Docker;Git</td>
      <td>PyCharm</td>
      <td>PyCharm;Visual Studio Code</td>
      <td>Linux-based</td>
      <td>Visit Stack Overflow;Google it;Do other work a...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>Less than once per month or monthly</td>
      <td>No, not at all</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent;Biracial</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>54049.0</td>
    </tr>
    <tr>
      <th>83420</th>
      <td>83421</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>FRANCE</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>5 - 10 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>16</td>
      <td>4</td>
      <td>Developer, front-end;Developer, desktop or ent...</td>
      <td>2 to 9 employees</td>
      <td>EUR European Euro</td>
      <td>33000.0</td>
      <td>Yearly</td>
      <td>Bash/Shell;C#;C++;Go;Groovy;HTML/CSS;Java;Java...</td>
      <td>HTML/CSS;Java;JavaScript;Node.js;Python;TypeSc...</td>
      <td>Elasticsearch;Firebase;IBM DB2;MariaDB;Microso...</td>
      <td>Elasticsearch;MongoDB;Redis</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Angular;ASP.NET;ASP.NET Core ;Express;React.js...</td>
      <td>Express;React.js;Spring;Vue.js</td>
      <td>.NET Framework;.NET Core / .NET 5;Apache Spark</td>
      <td>Apache Spark;TensorFlow;Torch/PyTorch</td>
      <td>Ansible;Deno;Docker;Git;Kubernetes;Puppet;Terr...</td>
      <td>Deno;Docker;Git;Kubernetes;Unity 3D;Unreal Eng...</td>
      <td>Android Studio;Eclipse;IntelliJ;IPython/Jupyte...</td>
      <td>IntelliJ;IPython/Jupyter;Visual Studio Code;We...</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Google it</td>
      <td>Stack Overflow</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>Neutral</td>
      <td>Yes</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>I have a mood or emotional disorder (e.g. depr...</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>35672.0</td>
    </tr>
  </tbody>
</table>
<p>4193 rows × 48 columns</p>
</div>




```python
# Cambiar a mayúsculas el campo country
datos['COUNTRY'] = datos['COUNTRY'].str.upper()
```


```python
datos
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>RESPONSEID</th>
      <th>MAINBRANCH</th>
      <th>EMPLOYMENT</th>
      <th>COUNTRY</th>
      <th>USSTATE</th>
      <th>UKCOUNTRY</th>
      <th>EDLEVEL</th>
      <th>AGE1STCODE</th>
      <th>LEARNCODE</th>
      <th>YEARSCODE</th>
      <th>YEARSCODEPRO</th>
      <th>DEVTYPE</th>
      <th>ORGSIZE</th>
      <th>CURRENCY</th>
      <th>COMPTOTAL</th>
      <th>COMPFREQ</th>
      <th>LANGUAGEHAVEWORKEDWITH</th>
      <th>LANGUAGEWANTTOWORKWITH</th>
      <th>DATABASEHAVEWORKEDWITH</th>
      <th>DATABASEWANTTOWORKWITH</th>
      <th>PLATFORMHAVEWORKEDWITH</th>
      <th>PLATFORMWANTTOWORKWITH</th>
      <th>WEBFRAMEHAVEWORKEDWITH</th>
      <th>WEBFRAMEWANTTOWORKWITH</th>
      <th>MISCTECHHAVEWORKEDWITH</th>
      <th>MISCTECHWANTTOWORKWITH</th>
      <th>TOOLSTECHHAVEWORKEDWITH</th>
      <th>TOOLSTECHWANTTOWORKWITH</th>
      <th>NEWCOLLABTOOLSHAVEWORKEDWITH</th>
      <th>NEWCOLLABTOOLSWANTTOWORKWITH</th>
      <th>OPSYS</th>
      <th>NEWSTUCK</th>
      <th>NEWSOSITES</th>
      <th>SOVISITFREQ</th>
      <th>SOACCOUNT</th>
      <th>SOPARTFREQ</th>
      <th>SOCOMM</th>
      <th>NEWOTHERCOMMS</th>
      <th>AGE</th>
      <th>GENDER</th>
      <th>TRANS</th>
      <th>SEXUALITY</th>
      <th>ETHNICITY</th>
      <th>ACCESSIBILITY</th>
      <th>MENTALHEALTH</th>
      <th>SURVEYLENGTH</th>
      <th>SURVEYEASE</th>
      <th>CONVERTEDCOMPYEARLY</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>SLOVAKIA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Secondary school (e.g. American high school, G...</td>
      <td>18 - 24 years</td>
      <td>Coding Bootcamp;Other online resources (ex: vi...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Developer, mobile</td>
      <td>20 to 99 employees</td>
      <td>EUR European Euro</td>
      <td>4800.0</td>
      <td>Monthly</td>
      <td>C++;HTML/CSS;JavaScript;Objective-C;PHP;Swift</td>
      <td>Swift</td>
      <td>PostgreSQL;SQLite</td>
      <td>SQLite</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Laravel;Symfony</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>PHPStorm;Xcode</td>
      <td>Atom;Xcode</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>Multiple times per day</td>
      <td>Yes</td>
      <td>A few times per month or weekly</td>
      <td>Yes, definitely</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>62268.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>I am a student who is learning to code</td>
      <td>Student, full-time</td>
      <td>NETHERLANDS</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>7</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>JavaScript;Python</td>
      <td>Python</td>
      <td>PostgreSQL</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Angular;Flask;Vue.js</td>
      <td>NaN</td>
      <td>Cordova</td>
      <td>NaN</td>
      <td>Docker;Git;Yarn</td>
      <td>Git</td>
      <td>Android Studio;IntelliJ;Notepad++;PyCharm</td>
      <td>NaN</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Google it</td>
      <td>Stack Overflow</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>Daily or almost daily</td>
      <td>Yes, definitely</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>I am not primarily a developer, but I write co...</td>
      <td>Student, full-time</td>
      <td>RUSSIAN FEDERATION</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Assembly;C;Python;R;Rust</td>
      <td>Julia;Python;Rust</td>
      <td>SQLite</td>
      <td>SQLite</td>
      <td>Heroku</td>
      <td>NaN</td>
      <td>Flask</td>
      <td>Flask</td>
      <td>NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>Keras;NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>IPython/Jupyter;PyCharm;RStudio;Sublime Text;V...</td>
      <td>IPython/Jupyter;RStudio;Sublime Text;Visual St...</td>
      <td>MacOS</td>
      <td>Visit Stack Overflow;Google it;Watch help / tu...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Multiple times per day</td>
      <td>Yes</td>
      <td>Multiple times per day</td>
      <td>Yes, definitely</td>
      <td>Yes</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>AUSTRIA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>11 - 17 years</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Developer, front-end</td>
      <td>100 to 499 employees</td>
      <td>EUR European Euro</td>
      <td>NaN</td>
      <td>Monthly</td>
      <td>JavaScript;TypeScript</td>
      <td>JavaScript;TypeScript</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Angular;jQuery</td>
      <td>Angular;jQuery</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>Daily or almost daily</td>
      <td>Neutral</td>
      <td>No</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>I am deaf / hard of hearing</td>
      <td>NaN</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>UNITED KINGDOM OF GREAT BRITAIN AND NORTHERN I...</td>
      <td>NaN</td>
      <td>England</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>5 - 10 years</td>
      <td>Friend or family member</td>
      <td>17</td>
      <td>10</td>
      <td>Developer, desktop or enterprise applications;...</td>
      <td>Just me - I am a freelancer, sole proprietor, ...</td>
      <td>GBP\tPound sterling</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bash/Shell;HTML/CSS;Python;SQL</td>
      <td>Bash/Shell;HTML/CSS;Python;SQL</td>
      <td>Elasticsearch;PostgreSQL;Redis</td>
      <td>Cassandra;Elasticsearch;PostgreSQL;Redis</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Flask</td>
      <td>Flask</td>
      <td>Apache Spark;Hadoop;NumPy;Pandas</td>
      <td>Hadoop;NumPy;Pandas</td>
      <td>Docker;Git;Kubernetes;Yarn</td>
      <td>Docker;Git;Kubernetes;Yarn</td>
      <td>Atom;IPython/Jupyter;Notepad++;PyCharm;Vim</td>
      <td>Atom;IPython/Jupyter;Notepad++;PyCharm;Vim;Vis...</td>
      <td>Linux-based</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>A few times per week</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>NaN</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>NaN</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>83434</th>
      <td>83435</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>Texas</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>6</td>
      <td>5</td>
      <td>Developer, back-end</td>
      <td>20 to 99 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>160500.0</td>
      <td>Yearly</td>
      <td>Clojure;Kotlin;SQL</td>
      <td>Clojure</td>
      <td>Oracle;SQLite</td>
      <td>SQLite</td>
      <td>AWS</td>
      <td>AWS</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>Git;Kubernetes</td>
      <td>IntelliJ;Sublime Text;Vim;Visual Studio Code</td>
      <td>Sublime Text;Vim</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Google it</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>No</td>
      <td>NaN</td>
      <td>No, not at all</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>I have a concentration and/or memory disorder ...</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>160500.0</td>
    </tr>
    <tr>
      <th>83435</th>
      <td>83436</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>BENIN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>4</td>
      <td>2</td>
      <td>Developer, full-stack</td>
      <td>Just me - I am a freelancer, sole proprietor, ...</td>
      <td>XOF\tWest African CFA franc</td>
      <td>200000.0</td>
      <td>Monthly</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Firebase;MariaDB;MySQL;PostgreSQL;Redis;SQLite</td>
      <td>Firebase;MariaDB;MongoDB;MySQL;PostgreSQL;Redi...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Django;jQuery;Laravel;React.js;Ruby on Rails</td>
      <td>Django;Express;jQuery;Laravel;React.js;Ruby on...</td>
      <td>Flutter;Qt</td>
      <td>NaN</td>
      <td>Git;Unity 3D;Unreal Engine</td>
      <td>Docker;Git;Kubernetes</td>
      <td>Android Studio;Eclipse;Emacs;IntelliJ;NetBeans...</td>
      <td>Emacs;IntelliJ;PHPStorm;PyCharm;RStudio;Sublim...</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Multiple times per day</td>
      <td>Yes</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Black or of African descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>3960.0</td>
    </tr>
    <tr>
      <th>83436</th>
      <td>83437</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>New Jersey</td>
      <td>NaN</td>
      <td>Secondary school (e.g. American high school, G...</td>
      <td>11 - 17 years</td>
      <td>School</td>
      <td>10</td>
      <td>4</td>
      <td>Data scientist or machine learning specialist;...</td>
      <td>10,000 or more employees</td>
      <td>USD\tUnited States dollar</td>
      <td>1800.0</td>
      <td>Weekly</td>
      <td>Groovy;Java;Python</td>
      <td>Java;Python</td>
      <td>DynamoDB;Elasticsearch;MongoDB;PostgreSQL;Redis</td>
      <td>DynamoDB;Redis</td>
      <td>AWS;Google Cloud Platform</td>
      <td>AWS</td>
      <td>FastAPI;Flask</td>
      <td>FastAPI;Flask</td>
      <td>Hadoop;Keras;NumPy;Pandas</td>
      <td>Apache Spark;Hadoop;Keras;NumPy;Pandas;TensorFlow</td>
      <td>Ansible;Docker;Git;Terraform</td>
      <td>Docker;Git;Kubernetes;Terraform</td>
      <td>Android Studio;Eclipse;IntelliJ;IPython/Jupyte...</td>
      <td>IntelliJ;IPython/Jupyter;Notepad++;Vim</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>Yes</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>No, not really</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>NaN</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>90000.0</td>
    </tr>
    <tr>
      <th>83437</th>
      <td>83438</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>CANADA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Online Courses or Certification;Books / Physic...</td>
      <td>5</td>
      <td>3</td>
      <td>Developer, back-end</td>
      <td>20 to 99 employees</td>
      <td>CAD\tCanadian dollar</td>
      <td>90000.0</td>
      <td>Monthly</td>
      <td>Bash/Shell;JavaScript;Node.js;Python</td>
      <td>Go;Rust</td>
      <td>Cassandra;Elasticsearch;MongoDB;PostgreSQL;Redis</td>
      <td>NaN</td>
      <td>Heroku</td>
      <td>AWS;DigitalOcean</td>
      <td>Django;Express;Flask;React.js</td>
      <td>NaN</td>
      <td>NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>Ansible;Docker;Git;Terraform</td>
      <td>Kubernetes;Terraform</td>
      <td>PyCharm;Sublime Text</td>
      <td>NaN</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>A few times per month or weekly</td>
      <td>Yes</td>
      <td>Less than once per month or monthly</td>
      <td>No, not really</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>I have a mood or emotional disorder (e.g. depr...</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>816816.0</td>
    </tr>
    <tr>
      <th>83438</th>
      <td>83439</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>BRAZIL</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Professional degree (JD, MD, etc.)</td>
      <td>11 - 17 years</td>
      <td>School</td>
      <td>14</td>
      <td>4</td>
      <td>Developer, front-end;Developer, full-stack;Dev...</td>
      <td>I don’t know</td>
      <td>BRL\tBrazilian real</td>
      <td>7700.0</td>
      <td>Monthly</td>
      <td>Delphi;Elixir;HTML/CSS;Java;JavaScript</td>
      <td>Elixir;HTML/CSS;Java;JavaScript;Node.js;PHP;SQ...</td>
      <td>Oracle;PostgreSQL</td>
      <td>Elasticsearch;MongoDB;MySQL;Oracle;PostgreSQL;...</td>
      <td>Microsoft Azure</td>
      <td>AWS</td>
      <td>Angular;Spring</td>
      <td>Express;Laravel;Spring;Symfony</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>Docker;Git;Kubernetes</td>
      <td>IntelliJ;Visual Studio Code</td>
      <td>IntelliJ;PHPStorm;Visual Studio Code</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange;Stack Overflow f...</td>
      <td>A few times per week</td>
      <td>Yes</td>
      <td>A few times per week</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Hispanic or Latino/a/x</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>21168.0</td>
    </tr>
  </tbody>
</table>
<p>83439 rows × 48 columns</p>
</div>




```python
# Ejemplos de apply en series de objetos
# Accede a un campo y devuelve las columnas y filas
datos['COUNTRY'].apply(len)
```




    0         8
    1        11
    2        18
    3         7
    4        52
             ..
    83434    24
    83435     5
    83436    24
    83437     6
    83438     6
    Name: COUNTRY, Length: 83439, dtype: int64




```python
def actualizar_pais(COUNTRY):
    return COUNTRY.lower()
```


```python
datos['COUNTRY'].apply(actualizar_pais)
```




    0                                                 slovakia
    1                                              netherlands
    2                                       russian federation
    3                                                  austria
    4        united kingdom of great britain and northern i...
                                   ...                        
    83434                             united states of america
    83435                                                benin
    83436                             united states of america
    83437                                               canada
    83438                                               brazil
    Name: COUNTRY, Length: 83439, dtype: object




```python
datos['COUNTRY'] = datos['COUNTRY'].apply(lambda z: z.upper())
```


```python
datos
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>RESPONSEID</th>
      <th>MAINBRANCH</th>
      <th>EMPLOYMENT</th>
      <th>COUNTRY</th>
      <th>USSTATE</th>
      <th>UKCOUNTRY</th>
      <th>EDLEVEL</th>
      <th>AGE1STCODE</th>
      <th>LEARNCODE</th>
      <th>YEARSCODE</th>
      <th>YEARSCODEPRO</th>
      <th>DEVTYPE</th>
      <th>ORGSIZE</th>
      <th>CURRENCY</th>
      <th>COMPTOTAL</th>
      <th>COMPFREQ</th>
      <th>LANGUAGEHAVEWORKEDWITH</th>
      <th>LANGUAGEWANTTOWORKWITH</th>
      <th>DATABASEHAVEWORKEDWITH</th>
      <th>DATABASEWANTTOWORKWITH</th>
      <th>PLATFORMHAVEWORKEDWITH</th>
      <th>PLATFORMWANTTOWORKWITH</th>
      <th>WEBFRAMEHAVEWORKEDWITH</th>
      <th>WEBFRAMEWANTTOWORKWITH</th>
      <th>MISCTECHHAVEWORKEDWITH</th>
      <th>MISCTECHWANTTOWORKWITH</th>
      <th>TOOLSTECHHAVEWORKEDWITH</th>
      <th>TOOLSTECHWANTTOWORKWITH</th>
      <th>NEWCOLLABTOOLSHAVEWORKEDWITH</th>
      <th>NEWCOLLABTOOLSWANTTOWORKWITH</th>
      <th>OPSYS</th>
      <th>NEWSTUCK</th>
      <th>NEWSOSITES</th>
      <th>SOVISITFREQ</th>
      <th>SOACCOUNT</th>
      <th>SOPARTFREQ</th>
      <th>SOCOMM</th>
      <th>NEWOTHERCOMMS</th>
      <th>AGE</th>
      <th>GENDER</th>
      <th>TRANS</th>
      <th>SEXUALITY</th>
      <th>ETHNICITY</th>
      <th>ACCESSIBILITY</th>
      <th>MENTALHEALTH</th>
      <th>SURVEYLENGTH</th>
      <th>SURVEYEASE</th>
      <th>CONVERTEDCOMPYEARLY</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>SLOVAKIA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Secondary school (e.g. American high school, G...</td>
      <td>18 - 24 years</td>
      <td>Coding Bootcamp;Other online resources (ex: vi...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Developer, mobile</td>
      <td>20 to 99 employees</td>
      <td>EUR European Euro</td>
      <td>4800.0</td>
      <td>Monthly</td>
      <td>C++;HTML/CSS;JavaScript;Objective-C;PHP;Swift</td>
      <td>Swift</td>
      <td>PostgreSQL;SQLite</td>
      <td>SQLite</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Laravel;Symfony</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>PHPStorm;Xcode</td>
      <td>Atom;Xcode</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>Multiple times per day</td>
      <td>Yes</td>
      <td>A few times per month or weekly</td>
      <td>Yes, definitely</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>62268.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>I am a student who is learning to code</td>
      <td>Student, full-time</td>
      <td>NETHERLANDS</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>7</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>JavaScript;Python</td>
      <td>Python</td>
      <td>PostgreSQL</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Angular;Flask;Vue.js</td>
      <td>NaN</td>
      <td>Cordova</td>
      <td>NaN</td>
      <td>Docker;Git;Yarn</td>
      <td>Git</td>
      <td>Android Studio;IntelliJ;Notepad++;PyCharm</td>
      <td>NaN</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Google it</td>
      <td>Stack Overflow</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>Daily or almost daily</td>
      <td>Yes, definitely</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>I am not primarily a developer, but I write co...</td>
      <td>Student, full-time</td>
      <td>RUSSIAN FEDERATION</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Assembly;C;Python;R;Rust</td>
      <td>Julia;Python;Rust</td>
      <td>SQLite</td>
      <td>SQLite</td>
      <td>Heroku</td>
      <td>NaN</td>
      <td>Flask</td>
      <td>Flask</td>
      <td>NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>Keras;NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>IPython/Jupyter;PyCharm;RStudio;Sublime Text;V...</td>
      <td>IPython/Jupyter;RStudio;Sublime Text;Visual St...</td>
      <td>MacOS</td>
      <td>Visit Stack Overflow;Google it;Watch help / tu...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Multiple times per day</td>
      <td>Yes</td>
      <td>Multiple times per day</td>
      <td>Yes, definitely</td>
      <td>Yes</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>AUSTRIA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>11 - 17 years</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Developer, front-end</td>
      <td>100 to 499 employees</td>
      <td>EUR European Euro</td>
      <td>NaN</td>
      <td>Monthly</td>
      <td>JavaScript;TypeScript</td>
      <td>JavaScript;TypeScript</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Angular;jQuery</td>
      <td>Angular;jQuery</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>Daily or almost daily</td>
      <td>Neutral</td>
      <td>No</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>I am deaf / hard of hearing</td>
      <td>NaN</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>UNITED KINGDOM OF GREAT BRITAIN AND NORTHERN I...</td>
      <td>NaN</td>
      <td>England</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>5 - 10 years</td>
      <td>Friend or family member</td>
      <td>17</td>
      <td>10</td>
      <td>Developer, desktop or enterprise applications;...</td>
      <td>Just me - I am a freelancer, sole proprietor, ...</td>
      <td>GBP\tPound sterling</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bash/Shell;HTML/CSS;Python;SQL</td>
      <td>Bash/Shell;HTML/CSS;Python;SQL</td>
      <td>Elasticsearch;PostgreSQL;Redis</td>
      <td>Cassandra;Elasticsearch;PostgreSQL;Redis</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Flask</td>
      <td>Flask</td>
      <td>Apache Spark;Hadoop;NumPy;Pandas</td>
      <td>Hadoop;NumPy;Pandas</td>
      <td>Docker;Git;Kubernetes;Yarn</td>
      <td>Docker;Git;Kubernetes;Yarn</td>
      <td>Atom;IPython/Jupyter;Notepad++;PyCharm;Vim</td>
      <td>Atom;IPython/Jupyter;Notepad++;PyCharm;Vim;Vis...</td>
      <td>Linux-based</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>A few times per week</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>NaN</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>NaN</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>83434</th>
      <td>83435</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>Texas</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>6</td>
      <td>5</td>
      <td>Developer, back-end</td>
      <td>20 to 99 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>160500.0</td>
      <td>Yearly</td>
      <td>Clojure;Kotlin;SQL</td>
      <td>Clojure</td>
      <td>Oracle;SQLite</td>
      <td>SQLite</td>
      <td>AWS</td>
      <td>AWS</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>Git;Kubernetes</td>
      <td>IntelliJ;Sublime Text;Vim;Visual Studio Code</td>
      <td>Sublime Text;Vim</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Google it</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>No</td>
      <td>NaN</td>
      <td>No, not at all</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>I have a concentration and/or memory disorder ...</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>160500.0</td>
    </tr>
    <tr>
      <th>83435</th>
      <td>83436</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>BENIN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>4</td>
      <td>2</td>
      <td>Developer, full-stack</td>
      <td>Just me - I am a freelancer, sole proprietor, ...</td>
      <td>XOF\tWest African CFA franc</td>
      <td>200000.0</td>
      <td>Monthly</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Firebase;MariaDB;MySQL;PostgreSQL;Redis;SQLite</td>
      <td>Firebase;MariaDB;MongoDB;MySQL;PostgreSQL;Redi...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Django;jQuery;Laravel;React.js;Ruby on Rails</td>
      <td>Django;Express;jQuery;Laravel;React.js;Ruby on...</td>
      <td>Flutter;Qt</td>
      <td>NaN</td>
      <td>Git;Unity 3D;Unreal Engine</td>
      <td>Docker;Git;Kubernetes</td>
      <td>Android Studio;Eclipse;Emacs;IntelliJ;NetBeans...</td>
      <td>Emacs;IntelliJ;PHPStorm;PyCharm;RStudio;Sublim...</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Multiple times per day</td>
      <td>Yes</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Black or of African descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>3960.0</td>
    </tr>
    <tr>
      <th>83436</th>
      <td>83437</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>New Jersey</td>
      <td>NaN</td>
      <td>Secondary school (e.g. American high school, G...</td>
      <td>11 - 17 years</td>
      <td>School</td>
      <td>10</td>
      <td>4</td>
      <td>Data scientist or machine learning specialist;...</td>
      <td>10,000 or more employees</td>
      <td>USD\tUnited States dollar</td>
      <td>1800.0</td>
      <td>Weekly</td>
      <td>Groovy;Java;Python</td>
      <td>Java;Python</td>
      <td>DynamoDB;Elasticsearch;MongoDB;PostgreSQL;Redis</td>
      <td>DynamoDB;Redis</td>
      <td>AWS;Google Cloud Platform</td>
      <td>AWS</td>
      <td>FastAPI;Flask</td>
      <td>FastAPI;Flask</td>
      <td>Hadoop;Keras;NumPy;Pandas</td>
      <td>Apache Spark;Hadoop;Keras;NumPy;Pandas;TensorFlow</td>
      <td>Ansible;Docker;Git;Terraform</td>
      <td>Docker;Git;Kubernetes;Terraform</td>
      <td>Android Studio;Eclipse;IntelliJ;IPython/Jupyte...</td>
      <td>IntelliJ;IPython/Jupyter;Notepad++;Vim</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>Yes</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>No, not really</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>NaN</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>90000.0</td>
    </tr>
    <tr>
      <th>83437</th>
      <td>83438</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>CANADA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Online Courses or Certification;Books / Physic...</td>
      <td>5</td>
      <td>3</td>
      <td>Developer, back-end</td>
      <td>20 to 99 employees</td>
      <td>CAD\tCanadian dollar</td>
      <td>90000.0</td>
      <td>Monthly</td>
      <td>Bash/Shell;JavaScript;Node.js;Python</td>
      <td>Go;Rust</td>
      <td>Cassandra;Elasticsearch;MongoDB;PostgreSQL;Redis</td>
      <td>NaN</td>
      <td>Heroku</td>
      <td>AWS;DigitalOcean</td>
      <td>Django;Express;Flask;React.js</td>
      <td>NaN</td>
      <td>NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>Ansible;Docker;Git;Terraform</td>
      <td>Kubernetes;Terraform</td>
      <td>PyCharm;Sublime Text</td>
      <td>NaN</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>A few times per month or weekly</td>
      <td>Yes</td>
      <td>Less than once per month or monthly</td>
      <td>No, not really</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>I have a mood or emotional disorder (e.g. depr...</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>816816.0</td>
    </tr>
    <tr>
      <th>83438</th>
      <td>83439</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>BRAZIL</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Professional degree (JD, MD, etc.)</td>
      <td>11 - 17 years</td>
      <td>School</td>
      <td>14</td>
      <td>4</td>
      <td>Developer, front-end;Developer, full-stack;Dev...</td>
      <td>I don’t know</td>
      <td>BRL\tBrazilian real</td>
      <td>7700.0</td>
      <td>Monthly</td>
      <td>Delphi;Elixir;HTML/CSS;Java;JavaScript</td>
      <td>Elixir;HTML/CSS;Java;JavaScript;Node.js;PHP;SQ...</td>
      <td>Oracle;PostgreSQL</td>
      <td>Elasticsearch;MongoDB;MySQL;Oracle;PostgreSQL;...</td>
      <td>Microsoft Azure</td>
      <td>AWS</td>
      <td>Angular;Spring</td>
      <td>Express;Laravel;Spring;Symfony</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>Docker;Git;Kubernetes</td>
      <td>IntelliJ;Visual Studio Code</td>
      <td>IntelliJ;PHPStorm;Visual Studio Code</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange;Stack Overflow f...</td>
      <td>A few times per week</td>
      <td>Yes</td>
      <td>A few times per week</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Hispanic or Latino/a/x</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>21168.0</td>
    </tr>
  </tbody>
</table>
<p>83439 rows × 48 columns</p>
</div>




```python
# Ejemplos de apply en dataframes
# Ejecuta el código en cada serie del dataframe
datos.apply(len)
```




    RESPONSEID                      83439
    MAINBRANCH                      83439
    EMPLOYMENT                      83439
    COUNTRY                         83439
    USSTATE                         83439
    UKCOUNTRY                       83439
    EDLEVEL                         83439
    AGE1STCODE                      83439
    LEARNCODE                       83439
    YEARSCODE                       83439
    YEARSCODEPRO                    83439
    DEVTYPE                         83439
    ORGSIZE                         83439
    CURRENCY                        83439
    COMPTOTAL                       83439
    COMPFREQ                        83439
    LANGUAGEHAVEWORKEDWITH          83439
    LANGUAGEWANTTOWORKWITH          83439
    DATABASEHAVEWORKEDWITH          83439
    DATABASEWANTTOWORKWITH          83439
    PLATFORMHAVEWORKEDWITH          83439
    PLATFORMWANTTOWORKWITH          83439
    WEBFRAMEHAVEWORKEDWITH          83439
    WEBFRAMEWANTTOWORKWITH          83439
    MISCTECHHAVEWORKEDWITH          83439
    MISCTECHWANTTOWORKWITH          83439
    TOOLSTECHHAVEWORKEDWITH         83439
    TOOLSTECHWANTTOWORKWITH         83439
    NEWCOLLABTOOLSHAVEWORKEDWITH    83439
    NEWCOLLABTOOLSWANTTOWORKWITH    83439
    OPSYS                           83439
    NEWSTUCK                        83439
    NEWSOSITES                      83439
    SOVISITFREQ                     83439
    SOACCOUNT                       83439
    SOPARTFREQ                      83439
    SOCOMM                          83439
    NEWOTHERCOMMS                   83439
    AGE                             83439
    GENDER                          83439
    TRANS                           83439
    SEXUALITY                       83439
    ETHNICITY                       83439
    ACCESSIBILITY                   83439
    MENTALHEALTH                    83439
    SURVEYLENGTH                    83439
    SURVEYEASE                      83439
    CONVERTEDCOMPYEARLY             83439
    dtype: int64




```python
# Ejecuta el código en cada serie del dataframe
# modificando el eje a columna
datos.apply(len, axis='columns')
```




    0        48
    1        48
    2        48
    3        48
    4        48
             ..
    83434    48
    83435    48
    83436    48
    83437    48
    83438    48
    Length: 83439, dtype: int64




```python
# Ejemplos de apply en series
# Ejecuta el código en cada cada valor de la serie
datos.apply(pd.Series)
# Igual que datos
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>RESPONSEID</th>
      <th>MAINBRANCH</th>
      <th>EMPLOYMENT</th>
      <th>COUNTRY</th>
      <th>USSTATE</th>
      <th>UKCOUNTRY</th>
      <th>EDLEVEL</th>
      <th>AGE1STCODE</th>
      <th>LEARNCODE</th>
      <th>YEARSCODE</th>
      <th>YEARSCODEPRO</th>
      <th>DEVTYPE</th>
      <th>ORGSIZE</th>
      <th>CURRENCY</th>
      <th>COMPTOTAL</th>
      <th>COMPFREQ</th>
      <th>LANGUAGEHAVEWORKEDWITH</th>
      <th>LANGUAGEWANTTOWORKWITH</th>
      <th>DATABASEHAVEWORKEDWITH</th>
      <th>DATABASEWANTTOWORKWITH</th>
      <th>PLATFORMHAVEWORKEDWITH</th>
      <th>PLATFORMWANTTOWORKWITH</th>
      <th>WEBFRAMEHAVEWORKEDWITH</th>
      <th>WEBFRAMEWANTTOWORKWITH</th>
      <th>MISCTECHHAVEWORKEDWITH</th>
      <th>MISCTECHWANTTOWORKWITH</th>
      <th>TOOLSTECHHAVEWORKEDWITH</th>
      <th>TOOLSTECHWANTTOWORKWITH</th>
      <th>NEWCOLLABTOOLSHAVEWORKEDWITH</th>
      <th>NEWCOLLABTOOLSWANTTOWORKWITH</th>
      <th>OPSYS</th>
      <th>NEWSTUCK</th>
      <th>NEWSOSITES</th>
      <th>SOVISITFREQ</th>
      <th>SOACCOUNT</th>
      <th>SOPARTFREQ</th>
      <th>SOCOMM</th>
      <th>NEWOTHERCOMMS</th>
      <th>AGE</th>
      <th>GENDER</th>
      <th>TRANS</th>
      <th>SEXUALITY</th>
      <th>ETHNICITY</th>
      <th>ACCESSIBILITY</th>
      <th>MENTALHEALTH</th>
      <th>SURVEYLENGTH</th>
      <th>SURVEYEASE</th>
      <th>CONVERTEDCOMPYEARLY</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>SLOVAKIA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Secondary school (e.g. American high school, G...</td>
      <td>18 - 24 years</td>
      <td>Coding Bootcamp;Other online resources (ex: vi...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Developer, mobile</td>
      <td>20 to 99 employees</td>
      <td>EUR European Euro</td>
      <td>4800.0</td>
      <td>Monthly</td>
      <td>C++;HTML/CSS;JavaScript;Objective-C;PHP;Swift</td>
      <td>Swift</td>
      <td>PostgreSQL;SQLite</td>
      <td>SQLite</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Laravel;Symfony</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>PHPStorm;Xcode</td>
      <td>Atom;Xcode</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>Multiple times per day</td>
      <td>Yes</td>
      <td>A few times per month or weekly</td>
      <td>Yes, definitely</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>62268.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>I am a student who is learning to code</td>
      <td>Student, full-time</td>
      <td>NETHERLANDS</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>7</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>JavaScript;Python</td>
      <td>Python</td>
      <td>PostgreSQL</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Angular;Flask;Vue.js</td>
      <td>NaN</td>
      <td>Cordova</td>
      <td>NaN</td>
      <td>Docker;Git;Yarn</td>
      <td>Git</td>
      <td>Android Studio;IntelliJ;Notepad++;PyCharm</td>
      <td>NaN</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Google it</td>
      <td>Stack Overflow</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>Daily or almost daily</td>
      <td>Yes, definitely</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>I am not primarily a developer, but I write co...</td>
      <td>Student, full-time</td>
      <td>RUSSIAN FEDERATION</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Assembly;C;Python;R;Rust</td>
      <td>Julia;Python;Rust</td>
      <td>SQLite</td>
      <td>SQLite</td>
      <td>Heroku</td>
      <td>NaN</td>
      <td>Flask</td>
      <td>Flask</td>
      <td>NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>Keras;NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>IPython/Jupyter;PyCharm;RStudio;Sublime Text;V...</td>
      <td>IPython/Jupyter;RStudio;Sublime Text;Visual St...</td>
      <td>MacOS</td>
      <td>Visit Stack Overflow;Google it;Watch help / tu...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Multiple times per day</td>
      <td>Yes</td>
      <td>Multiple times per day</td>
      <td>Yes, definitely</td>
      <td>Yes</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>AUSTRIA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>11 - 17 years</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Developer, front-end</td>
      <td>100 to 499 employees</td>
      <td>EUR European Euro</td>
      <td>NaN</td>
      <td>Monthly</td>
      <td>JavaScript;TypeScript</td>
      <td>JavaScript;TypeScript</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Angular;jQuery</td>
      <td>Angular;jQuery</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>Daily or almost daily</td>
      <td>Neutral</td>
      <td>No</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>I am deaf / hard of hearing</td>
      <td>NaN</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>UNITED KINGDOM OF GREAT BRITAIN AND NORTHERN I...</td>
      <td>NaN</td>
      <td>England</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>5 - 10 years</td>
      <td>Friend or family member</td>
      <td>17</td>
      <td>10</td>
      <td>Developer, desktop or enterprise applications;...</td>
      <td>Just me - I am a freelancer, sole proprietor, ...</td>
      <td>GBP\tPound sterling</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bash/Shell;HTML/CSS;Python;SQL</td>
      <td>Bash/Shell;HTML/CSS;Python;SQL</td>
      <td>Elasticsearch;PostgreSQL;Redis</td>
      <td>Cassandra;Elasticsearch;PostgreSQL;Redis</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Flask</td>
      <td>Flask</td>
      <td>Apache Spark;Hadoop;NumPy;Pandas</td>
      <td>Hadoop;NumPy;Pandas</td>
      <td>Docker;Git;Kubernetes;Yarn</td>
      <td>Docker;Git;Kubernetes;Yarn</td>
      <td>Atom;IPython/Jupyter;Notepad++;PyCharm;Vim</td>
      <td>Atom;IPython/Jupyter;Notepad++;PyCharm;Vim;Vis...</td>
      <td>Linux-based</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>Yes</td>
      <td>A few times per week</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>NaN</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>NaN</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>83434</th>
      <td>83435</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>Texas</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>6</td>
      <td>5</td>
      <td>Developer, back-end</td>
      <td>20 to 99 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>160500.0</td>
      <td>Yearly</td>
      <td>Clojure;Kotlin;SQL</td>
      <td>Clojure</td>
      <td>Oracle;SQLite</td>
      <td>SQLite</td>
      <td>AWS</td>
      <td>AWS</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>Git;Kubernetes</td>
      <td>IntelliJ;Sublime Text;Vim;Visual Studio Code</td>
      <td>Sublime Text;Vim</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Google it</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>No</td>
      <td>NaN</td>
      <td>No, not at all</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>I have a concentration and/or memory disorder ...</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>160500.0</td>
    </tr>
    <tr>
      <th>83435</th>
      <td>83436</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>BENIN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>4</td>
      <td>2</td>
      <td>Developer, full-stack</td>
      <td>Just me - I am a freelancer, sole proprietor, ...</td>
      <td>XOF\tWest African CFA franc</td>
      <td>200000.0</td>
      <td>Monthly</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Firebase;MariaDB;MySQL;PostgreSQL;Redis;SQLite</td>
      <td>Firebase;MariaDB;MongoDB;MySQL;PostgreSQL;Redi...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Django;jQuery;Laravel;React.js;Ruby on Rails</td>
      <td>Django;Express;jQuery;Laravel;React.js;Ruby on...</td>
      <td>Flutter;Qt</td>
      <td>NaN</td>
      <td>Git;Unity 3D;Unreal Engine</td>
      <td>Docker;Git;Kubernetes</td>
      <td>Android Studio;Eclipse;Emacs;IntelliJ;NetBeans...</td>
      <td>Emacs;IntelliJ;PHPStorm;PyCharm;RStudio;Sublim...</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Multiple times per day</td>
      <td>Yes</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Black or of African descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>3960.0</td>
    </tr>
    <tr>
      <th>83436</th>
      <td>83437</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>New Jersey</td>
      <td>NaN</td>
      <td>Secondary school (e.g. American high school, G...</td>
      <td>11 - 17 years</td>
      <td>School</td>
      <td>10</td>
      <td>4</td>
      <td>Data scientist or machine learning specialist;...</td>
      <td>10,000 or more employees</td>
      <td>USD\tUnited States dollar</td>
      <td>1800.0</td>
      <td>Weekly</td>
      <td>Groovy;Java;Python</td>
      <td>Java;Python</td>
      <td>DynamoDB;Elasticsearch;MongoDB;PostgreSQL;Redis</td>
      <td>DynamoDB;Redis</td>
      <td>AWS;Google Cloud Platform</td>
      <td>AWS</td>
      <td>FastAPI;Flask</td>
      <td>FastAPI;Flask</td>
      <td>Hadoop;Keras;NumPy;Pandas</td>
      <td>Apache Spark;Hadoop;Keras;NumPy;Pandas;TensorFlow</td>
      <td>Ansible;Docker;Git;Terraform</td>
      <td>Docker;Git;Kubernetes;Terraform</td>
      <td>Android Studio;Eclipse;IntelliJ;IPython/Jupyte...</td>
      <td>IntelliJ;IPython/Jupyter;Notepad++;Vim</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>Yes</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>No, not really</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>NaN</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>90000.0</td>
    </tr>
    <tr>
      <th>83437</th>
      <td>83438</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>CANADA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Online Courses or Certification;Books / Physic...</td>
      <td>5</td>
      <td>3</td>
      <td>Developer, back-end</td>
      <td>20 to 99 employees</td>
      <td>CAD\tCanadian dollar</td>
      <td>90000.0</td>
      <td>Monthly</td>
      <td>Bash/Shell;JavaScript;Node.js;Python</td>
      <td>Go;Rust</td>
      <td>Cassandra;Elasticsearch;MongoDB;PostgreSQL;Redis</td>
      <td>NaN</td>
      <td>Heroku</td>
      <td>AWS;DigitalOcean</td>
      <td>Django;Express;Flask;React.js</td>
      <td>NaN</td>
      <td>NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>Ansible;Docker;Git;Terraform</td>
      <td>Kubernetes;Terraform</td>
      <td>PyCharm;Sublime Text</td>
      <td>NaN</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>A few times per month or weekly</td>
      <td>Yes</td>
      <td>Less than once per month or monthly</td>
      <td>No, not really</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>I have a mood or emotional disorder (e.g. depr...</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>816816.0</td>
    </tr>
    <tr>
      <th>83438</th>
      <td>83439</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>BRAZIL</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Professional degree (JD, MD, etc.)</td>
      <td>11 - 17 years</td>
      <td>School</td>
      <td>14</td>
      <td>4</td>
      <td>Developer, front-end;Developer, full-stack;Dev...</td>
      <td>I don’t know</td>
      <td>BRL\tBrazilian real</td>
      <td>7700.0</td>
      <td>Monthly</td>
      <td>Delphi;Elixir;HTML/CSS;Java;JavaScript</td>
      <td>Elixir;HTML/CSS;Java;JavaScript;Node.js;PHP;SQ...</td>
      <td>Oracle;PostgreSQL</td>
      <td>Elasticsearch;MongoDB;MySQL;Oracle;PostgreSQL;...</td>
      <td>Microsoft Azure</td>
      <td>AWS</td>
      <td>Angular;Spring</td>
      <td>Express;Laravel;Spring;Symfony</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>Docker;Git;Kubernetes</td>
      <td>IntelliJ;Visual Studio Code</td>
      <td>IntelliJ;PHPStorm;Visual Studio Code</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange;Stack Overflow f...</td>
      <td>A few times per week</td>
      <td>Yes</td>
      <td>A few times per week</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Hispanic or Latino/a/x</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>21168.0</td>
    </tr>
  </tbody>
</table>
<p>83439 rows × 48 columns</p>
</div>




```python
# Ejemplos de applymap en dataframes
# Ejecuta el código (función) en cada serie del dataframe
datos.applymap
```




    <bound method DataFrame.applymap of        RESPONSEID                                         MAINBRANCH  \
    0               1                     I am a developer by profession   
    1               2             I am a student who is learning to code   
    2               3  I am not primarily a developer, but I write co...   
    3               4                     I am a developer by profession   
    4               5                     I am a developer by profession   
    ...           ...                                                ...   
    83434       83435                     I am a developer by profession   
    83435       83436                     I am a developer by profession   
    83436       83437                     I am a developer by profession   
    83437       83438                     I am a developer by profession   
    83438       83439                     I am a developer by profession   
    
                                                  EMPLOYMENT  \
    0      Independent contractor, freelancer, or self-em...   
    1                                     Student, full-time   
    2                                     Student, full-time   
    3                                     Employed full-time   
    4      Independent contractor, freelancer, or self-em...   
    ...                                                  ...   
    83434                                 Employed full-time   
    83435  Independent contractor, freelancer, or self-em...   
    83436                                 Employed full-time   
    83437                                 Employed full-time   
    83438                                 Employed full-time   
    
                                                     COUNTRY     USSTATE  \
    0                                               SLOVAKIA         NaN   
    1                                            NETHERLANDS         NaN   
    2                                     RUSSIAN FEDERATION         NaN   
    3                                                AUSTRIA         NaN   
    4      UNITED KINGDOM OF GREAT BRITAIN AND NORTHERN I...         NaN   
    ...                                                  ...         ...   
    83434                           UNITED STATES OF AMERICA       Texas   
    83435                                              BENIN         NaN   
    83436                           UNITED STATES OF AMERICA  New Jersey   
    83437                                             CANADA         NaN   
    83438                                             BRAZIL         NaN   
    
          UKCOUNTRY                                            EDLEVEL  \
    0           NaN  Secondary school (e.g. American high school, G...   
    1           NaN       Bachelor’s degree (B.A., B.S., B.Eng., etc.)   
    2           NaN       Bachelor’s degree (B.A., B.S., B.Eng., etc.)   
    3           NaN    Master’s degree (M.A., M.S., M.Eng., MBA, etc.)   
    4       England    Master’s degree (M.A., M.S., M.Eng., MBA, etc.)   
    ...         ...                                                ...   
    83434       NaN       Bachelor’s degree (B.A., B.S., B.Eng., etc.)   
    83435       NaN       Bachelor’s degree (B.A., B.S., B.Eng., etc.)   
    83436       NaN  Secondary school (e.g. American high school, G...   
    83437       NaN       Bachelor’s degree (B.A., B.S., B.Eng., etc.)   
    83438       NaN                 Professional degree (JD, MD, etc.)   
    
              AGE1STCODE                                          LEARNCODE  \
    0      18 - 24 years  Coding Bootcamp;Other online resources (ex: vi...   
    1      11 - 17 years  Other online resources (ex: videos, blogs, etc...   
    2      11 - 17 years  Other online resources (ex: videos, blogs, etc...   
    3      11 - 17 years                                                NaN   
    4       5 - 10 years                            Friend or family member   
    ...              ...                                                ...   
    83434  11 - 17 years  Other online resources (ex: videos, blogs, etc...   
    83435  11 - 17 years  Other online resources (ex: videos, blogs, etc...   
    83436  11 - 17 years                                             School   
    83437  11 - 17 years  Online Courses or Certification;Books / Physic...   
    83438  11 - 17 years                                             School   
    
          YEARSCODE YEARSCODEPRO  \
    0           NaN          NaN   
    1             7          NaN   
    2           NaN          NaN   
    3           NaN          NaN   
    4            17           10   
    ...         ...          ...   
    83434         6            5   
    83435         4            2   
    83436        10            4   
    83437         5            3   
    83438        14            4   
    
                                                     DEVTYPE  \
    0                                      Developer, mobile   
    1                                                    NaN   
    2                                                    NaN   
    3                                   Developer, front-end   
    4      Developer, desktop or enterprise applications;...   
    ...                                                  ...   
    83434                                Developer, back-end   
    83435                              Developer, full-stack   
    83436  Data scientist or machine learning specialist;...   
    83437                                Developer, back-end   
    83438  Developer, front-end;Developer, full-stack;Dev...   
    
                                                     ORGSIZE  \
    0                                     20 to 99 employees   
    1                                                    NaN   
    2                                                    NaN   
    3                                   100 to 499 employees   
    4      Just me - I am a freelancer, sole proprietor, ...   
    ...                                                  ...   
    83434                                 20 to 99 employees   
    83435  Just me - I am a freelancer, sole proprietor, ...   
    83436                           10,000 or more employees   
    83437                                 20 to 99 employees   
    83438                                       I don’t know   
    
                              CURRENCY  COMPTOTAL COMPFREQ  \
    0                EUR European Euro     4800.0  Monthly   
    1                              NaN        NaN      NaN   
    2                              NaN        NaN      NaN   
    3                EUR European Euro        NaN  Monthly   
    4              GBP\tPound sterling        NaN      NaN   
    ...                            ...        ...      ...   
    83434    USD\tUnited States dollar   160500.0   Yearly   
    83435  XOF\tWest African CFA franc   200000.0  Monthly   
    83436    USD\tUnited States dollar     1800.0   Weekly   
    83437         CAD\tCanadian dollar    90000.0  Monthly   
    83438          BRL\tBrazilian real     7700.0  Monthly   
    
                                  LANGUAGEHAVEWORKEDWITH  \
    0      C++;HTML/CSS;JavaScript;Objective-C;PHP;Swift   
    1                                  JavaScript;Python   
    2                           Assembly;C;Python;R;Rust   
    3                              JavaScript;TypeScript   
    4                     Bash/Shell;HTML/CSS;Python;SQL   
    ...                                              ...   
    83434                             Clojure;Kotlin;SQL   
    83435                                            NaN   
    83436                             Groovy;Java;Python   
    83437           Bash/Shell;JavaScript;Node.js;Python   
    83438         Delphi;Elixir;HTML/CSS;Java;JavaScript   
    
                                      LANGUAGEWANTTOWORKWITH  \
    0                                                  Swift   
    1                                                 Python   
    2                                      Julia;Python;Rust   
    3                                  JavaScript;TypeScript   
    4                         Bash/Shell;HTML/CSS;Python;SQL   
    ...                                                  ...   
    83434                                            Clojure   
    83435                                                NaN   
    83436                                        Java;Python   
    83437                                            Go;Rust   
    83438  Elixir;HTML/CSS;Java;JavaScript;Node.js;PHP;SQ...   
    
                                     DATABASEHAVEWORKEDWITH  \
    0                                     PostgreSQL;SQLite   
    1                                            PostgreSQL   
    2                                                SQLite   
    3                                                   NaN   
    4                        Elasticsearch;PostgreSQL;Redis   
    ...                                                 ...   
    83434                                     Oracle;SQLite   
    83435    Firebase;MariaDB;MySQL;PostgreSQL;Redis;SQLite   
    83436   DynamoDB;Elasticsearch;MongoDB;PostgreSQL;Redis   
    83437  Cassandra;Elasticsearch;MongoDB;PostgreSQL;Redis   
    83438                                 Oracle;PostgreSQL   
    
                                      DATABASEWANTTOWORKWITH  \
    0                                                 SQLite   
    1                                                    NaN   
    2                                                 SQLite   
    3                                                    NaN   
    4               Cassandra;Elasticsearch;PostgreSQL;Redis   
    ...                                                  ...   
    83434                                             SQLite   
    83435  Firebase;MariaDB;MongoDB;MySQL;PostgreSQL;Redi...   
    83436                                     DynamoDB;Redis   
    83437                                                NaN   
    83438  Elasticsearch;MongoDB;MySQL;Oracle;PostgreSQL;...   
    
              PLATFORMHAVEWORKEDWITH PLATFORMWANTTOWORKWITH  \
    0                            NaN                    NaN   
    1                            NaN                    NaN   
    2                         Heroku                    NaN   
    3                            NaN                    NaN   
    4                            NaN                    NaN   
    ...                          ...                    ...   
    83434                        AWS                    AWS   
    83435                        NaN                    NaN   
    83436  AWS;Google Cloud Platform                    AWS   
    83437                     Heroku       AWS;DigitalOcean   
    83438            Microsoft Azure                    AWS   
    
                                 WEBFRAMEHAVEWORKEDWITH  \
    0                                   Laravel;Symfony   
    1                              Angular;Flask;Vue.js   
    2                                             Flask   
    3                                    Angular;jQuery   
    4                                             Flask   
    ...                                             ...   
    83434                                           NaN   
    83435  Django;jQuery;Laravel;React.js;Ruby on Rails   
    83436                                 FastAPI;Flask   
    83437                 Django;Express;Flask;React.js   
    83438                                Angular;Spring   
    
                                      WEBFRAMEWANTTOWORKWITH  \
    0                                                    NaN   
    1                                                    NaN   
    2                                                  Flask   
    3                                         Angular;jQuery   
    4                                                  Flask   
    ...                                                  ...   
    83434                                                NaN   
    83435  Django;Express;jQuery;Laravel;React.js;Ruby on...   
    83436                                      FastAPI;Flask   
    83437                                                NaN   
    83438                     Express;Laravel;Spring;Symfony   
    
                          MISCTECHHAVEWORKEDWITH  \
    0                                        NaN   
    1                                    Cordova   
    2      NumPy;Pandas;TensorFlow;Torch/PyTorch   
    3                                        NaN   
    4           Apache Spark;Hadoop;NumPy;Pandas   
    ...                                      ...   
    83434                                    NaN   
    83435                             Flutter;Qt   
    83436              Hadoop;Keras;NumPy;Pandas   
    83437  NumPy;Pandas;TensorFlow;Torch/PyTorch   
    83438                                    NaN   
    
                                      MISCTECHWANTTOWORKWITH  \
    0                                                    NaN   
    1                                                    NaN   
    2            Keras;NumPy;Pandas;TensorFlow;Torch/PyTorch   
    3                                                    NaN   
    4                                    Hadoop;NumPy;Pandas   
    ...                                                  ...   
    83434                                                NaN   
    83435                                                NaN   
    83436  Apache Spark;Hadoop;Keras;NumPy;Pandas;TensorFlow   
    83437              NumPy;Pandas;TensorFlow;Torch/PyTorch   
    83438                                                NaN   
    
                TOOLSTECHHAVEWORKEDWITH          TOOLSTECHWANTTOWORKWITH  \
    0                               NaN                              NaN   
    1                   Docker;Git;Yarn                              Git   
    2                               NaN                              NaN   
    3                               NaN                              NaN   
    4        Docker;Git;Kubernetes;Yarn       Docker;Git;Kubernetes;Yarn   
    ...                             ...                              ...   
    83434                    Docker;Git                   Git;Kubernetes   
    83435    Git;Unity 3D;Unreal Engine            Docker;Git;Kubernetes   
    83436  Ansible;Docker;Git;Terraform  Docker;Git;Kubernetes;Terraform   
    83437  Ansible;Docker;Git;Terraform             Kubernetes;Terraform   
    83438                    Docker;Git            Docker;Git;Kubernetes   
    
                                NEWCOLLABTOOLSHAVEWORKEDWITH  \
    0                                         PHPStorm;Xcode   
    1              Android Studio;IntelliJ;Notepad++;PyCharm   
    2      IPython/Jupyter;PyCharm;RStudio;Sublime Text;V...   
    3                                                    NaN   
    4             Atom;IPython/Jupyter;Notepad++;PyCharm;Vim   
    ...                                                  ...   
    83434       IntelliJ;Sublime Text;Vim;Visual Studio Code   
    83435  Android Studio;Eclipse;Emacs;IntelliJ;NetBeans...   
    83436  Android Studio;Eclipse;IntelliJ;IPython/Jupyte...   
    83437                               PyCharm;Sublime Text   
    83438                        IntelliJ;Visual Studio Code   
    
                                NEWCOLLABTOOLSWANTTOWORKWITH        OPSYS  \
    0                                             Atom;Xcode        MacOS   
    1                                                    NaN      Windows   
    2      IPython/Jupyter;RStudio;Sublime Text;Visual St...        MacOS   
    3                                                    NaN      Windows   
    4      Atom;IPython/Jupyter;Notepad++;PyCharm;Vim;Vis...  Linux-based   
    ...                                                  ...          ...   
    83434                                   Sublime Text;Vim        MacOS   
    83435  Emacs;IntelliJ;PHPStorm;PyCharm;RStudio;Sublim...  Linux-based   
    83436             IntelliJ;IPython/Jupyter;Notepad++;Vim      Windows   
    83437                                                NaN        MacOS   
    83438               IntelliJ;PHPStorm;Visual Studio Code  Linux-based   
    
                                                    NEWSTUCK  \
    0      Call a coworker or friend;Visit Stack Overflow...   
    1                         Visit Stack Overflow;Google it   
    2      Visit Stack Overflow;Google it;Watch help / tu...   
    3      Call a coworker or friend;Visit Stack Overflow...   
    4      Visit Stack Overflow;Go for a walk or other ph...   
    ...                                                  ...   
    83434                Call a coworker or friend;Google it   
    83435  Call a coworker or friend;Visit Stack Overflow...   
    83436  Call a coworker or friend;Visit Stack Overflow...   
    83437  Call a coworker or friend;Visit Stack Overflow...   
    83438  Call a coworker or friend;Visit Stack Overflow...   
    
                                                  NEWSOSITES  \
    0                                         Stack Overflow   
    1                                         Stack Overflow   
    2                          Stack Overflow;Stack Exchange   
    3                                         Stack Overflow   
    4                          Stack Overflow;Stack Exchange   
    ...                                                  ...   
    83434                      Stack Overflow;Stack Exchange   
    83435                      Stack Overflow;Stack Exchange   
    83436                      Stack Overflow;Stack Exchange   
    83437                                     Stack Overflow   
    83438  Stack Overflow;Stack Exchange;Stack Overflow f...   
    
                               SOVISITFREQ SOACCOUNT  \
    0               Multiple times per day       Yes   
    1                Daily or almost daily       Yes   
    2               Multiple times per day       Yes   
    3                Daily or almost daily       Yes   
    4                Daily or almost daily       Yes   
    ...                                ...       ...   
    83434             A few times per week        No   
    83435           Multiple times per day       Yes   
    83436             A few times per week       Yes   
    83437  A few times per month or weekly       Yes   
    83438             A few times per week       Yes   
    
                                                  SOPARTFREQ           SOCOMM  \
    0                        A few times per month or weekly  Yes, definitely   
    1                                  Daily or almost daily  Yes, definitely   
    2                                 Multiple times per day  Yes, definitely   
    3                                  Daily or almost daily          Neutral   
    4                                   A few times per week    Yes, somewhat   
    ...                                                  ...              ...   
    83434                                                NaN   No, not at all   
    83435  I have never participated in Q&A on Stack Over...    Yes, somewhat   
    83436  I have never participated in Q&A on Stack Over...   No, not really   
    83437                Less than once per month or monthly   No, not really   
    83438                               A few times per week    Yes, somewhat   
    
          NEWOTHERCOMMS              AGE GENDER TRANS                SEXUALITY  \
    0                No  25-34 years old    Man    No  Straight / Heterosexual   
    1                No  18-24 years old    Man    No  Straight / Heterosexual   
    2               Yes  18-24 years old    Man    No        Prefer not to say   
    3                No  35-44 years old    Man    No  Straight / Heterosexual   
    4                No  25-34 years old    Man    No                      NaN   
    ...             ...              ...    ...   ...                      ...   
    83434            No  25-34 years old    Man    No  Straight / Heterosexual   
    83435            No  18-24 years old    Man    No  Straight / Heterosexual   
    83436            No  25-34 years old    Man    No                      NaN   
    83437            No  25-34 years old    Man    No  Straight / Heterosexual   
    83438            No  18-24 years old    Man    No  Straight / Heterosexual   
    
                              ETHNICITY                ACCESSIBILITY  \
    0      White or of European descent            None of the above   
    1      White or of European descent            None of the above   
    2                 Prefer not to say            None of the above   
    3      White or of European descent  I am deaf / hard of hearing   
    4      White or of European descent            None of the above   
    ...                             ...                          ...   
    83434  White or of European descent            None of the above   
    83435   Black or of African descent            None of the above   
    83436  White or of European descent            None of the above   
    83437  White or of European descent            None of the above   
    83438        Hispanic or Latino/a/x            None of the above   
    
                                                MENTALHEALTH  \
    0                                      None of the above   
    1                                      None of the above   
    2                                      None of the above   
    3                                                    NaN   
    4                                                    NaN   
    ...                                                  ...   
    83434  I have a concentration and/or memory disorder ...   
    83435                                  None of the above   
    83436                                  None of the above   
    83437  I have a mood or emotional disorder (e.g. depr...   
    83438                                  None of the above   
    
                    SURVEYLENGTH                  SURVEYEASE  CONVERTEDCOMPYEARLY  
    0      Appropriate in length                        Easy              62268.0  
    1      Appropriate in length                        Easy                  NaN  
    2      Appropriate in length                        Easy                  NaN  
    3      Appropriate in length  Neither easy nor difficult                  NaN  
    4      Appropriate in length                        Easy                  NaN  
    ...                      ...                         ...                  ...  
    83434  Appropriate in length                        Easy             160500.0  
    83435  Appropriate in length                        Easy               3960.0  
    83436  Appropriate in length  Neither easy nor difficult              90000.0  
    83437  Appropriate in length  Neither easy nor difficult             816816.0  
    83438  Appropriate in length                        Easy              21168.0  
    
    [83439 rows x 48 columns]>




```python
# El método map solamente funciona con series
# Permite cambiar los valores de las series
datos['SOACCOUNT']
```




    0        Yes
    1        Yes
    2        Yes
    3        Yes
    4        Yes
            ... 
    83434     No
    83435    Yes
    83436    Yes
    83437    Yes
    83438    Yes
    Name: SOACCOUNT, Length: 83439, dtype: object




```python
datos['SOACCOUNT'].map({'Yes': True, 'No': False})
```




    0         True
    1         True
    2         True
    3         True
    4         True
             ...  
    83434    False
    83435     True
    83436     True
    83437     True
    83438     True
    Name: SOACCOUNT, Length: 83439, dtype: object




```python
# Aplicar los cambios
datos['SOACCOUNT'] = datos['SOACCOUNT'].map({'Yes': True, 'No': False})
```


```python
# El método replace permite cambiar los valores de las series
# Se aplican los cambios creando una variable que utilize
# este código como en el ejemplo anterior
datos['COUNTRY'].replace({'NETHERLANDS':'PAISES BAJOS'})
```




    0                                                 SLOVAKIA
    1                                             PAISES BAJOS
    2                                       RUSSIAN FEDERATION
    3                                                  AUSTRIA
    4        UNITED KINGDOM OF GREAT BRITAIN AND NORTHERN I...
                                   ...                        
    83434                             UNITED STATES OF AMERICA
    83435                                                BENIN
    83436                             UNITED STATES OF AMERICA
    83437                                               CANADA
    83438                                               BRAZIL
    Name: COUNTRY, Length: 83439, dtype: object




```python
# Haciendo un join de dos columnas con un espacio para delimitarlas
datos['NEWSTUCK'] + ' ' + datos['NEWSOSITES']
```




    0        Call a coworker or friend;Visit Stack Overflow...
    1            Visit Stack Overflow;Google it Stack Overflow
    2        Visit Stack Overflow;Google it;Watch help / tu...
    3        Call a coworker or friend;Visit Stack Overflow...
    4        Visit Stack Overflow;Go for a walk or other ph...
                                   ...                        
    83434    Call a coworker or friend;Google it Stack Over...
    83435    Call a coworker or friend;Visit Stack Overflow...
    83436    Call a coworker or friend;Visit Stack Overflow...
    83437    Call a coworker or friend;Visit Stack Overflow...
    83438    Call a coworker or friend;Visit Stack Overflow...
    Length: 83439, dtype: object




```python
# Crea la nueva columna AYUDA
datos['AYUDA'] = datos['NEWSTUCK'] + ' ' + datos['NEWSOSITES']
```


```python
datos
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>RESPONSEID</th>
      <th>MAINBRANCH</th>
      <th>EMPLOYMENT</th>
      <th>COUNTRY</th>
      <th>USSTATE</th>
      <th>UKCOUNTRY</th>
      <th>EDLEVEL</th>
      <th>AGE1STCODE</th>
      <th>LEARNCODE</th>
      <th>YEARSCODE</th>
      <th>YEARSCODEPRO</th>
      <th>DEVTYPE</th>
      <th>ORGSIZE</th>
      <th>CURRENCY</th>
      <th>COMPTOTAL</th>
      <th>COMPFREQ</th>
      <th>LANGUAGEHAVEWORKEDWITH</th>
      <th>LANGUAGEWANTTOWORKWITH</th>
      <th>DATABASEHAVEWORKEDWITH</th>
      <th>DATABASEWANTTOWORKWITH</th>
      <th>PLATFORMHAVEWORKEDWITH</th>
      <th>PLATFORMWANTTOWORKWITH</th>
      <th>WEBFRAMEHAVEWORKEDWITH</th>
      <th>WEBFRAMEWANTTOWORKWITH</th>
      <th>...</th>
      <th>MISCTECHWANTTOWORKWITH</th>
      <th>TOOLSTECHHAVEWORKEDWITH</th>
      <th>TOOLSTECHWANTTOWORKWITH</th>
      <th>NEWCOLLABTOOLSHAVEWORKEDWITH</th>
      <th>NEWCOLLABTOOLSWANTTOWORKWITH</th>
      <th>OPSYS</th>
      <th>NEWSTUCK</th>
      <th>NEWSOSITES</th>
      <th>SOVISITFREQ</th>
      <th>SOACCOUNT</th>
      <th>SOPARTFREQ</th>
      <th>SOCOMM</th>
      <th>NEWOTHERCOMMS</th>
      <th>AGE</th>
      <th>GENDER</th>
      <th>TRANS</th>
      <th>SEXUALITY</th>
      <th>ETHNICITY</th>
      <th>ACCESSIBILITY</th>
      <th>MENTALHEALTH</th>
      <th>SURVEYLENGTH</th>
      <th>SURVEYEASE</th>
      <th>CONVERTEDCOMPYEARLY</th>
      <th>AYUDA</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>SLOVAKIA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Secondary school (e.g. American high school, G...</td>
      <td>18 - 24 years</td>
      <td>Coding Bootcamp;Other online resources (ex: vi...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Developer, mobile</td>
      <td>20 to 99 employees</td>
      <td>EUR European Euro</td>
      <td>4800.0</td>
      <td>Monthly</td>
      <td>C++;HTML/CSS;JavaScript;Objective-C;PHP;Swift</td>
      <td>Swift</td>
      <td>PostgreSQL;SQLite</td>
      <td>SQLite</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Laravel;Symfony</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>PHPStorm;Xcode</td>
      <td>Atom;Xcode</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>Multiple times per day</td>
      <td>True</td>
      <td>A few times per month or weekly</td>
      <td>Yes, definitely</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>62268.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>I am a student who is learning to code</td>
      <td>Student, full-time</td>
      <td>NETHERLANDS</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>7</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>JavaScript;Python</td>
      <td>Python</td>
      <td>PostgreSQL</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Angular;Flask;Vue.js</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>Docker;Git;Yarn</td>
      <td>Git</td>
      <td>Android Studio;IntelliJ;Notepad++;PyCharm</td>
      <td>NaN</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Google it</td>
      <td>Stack Overflow</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>Daily or almost daily</td>
      <td>Yes, definitely</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
      <td>Visit Stack Overflow;Google it Stack Overflow</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>I am not primarily a developer, but I write co...</td>
      <td>Student, full-time</td>
      <td>RUSSIAN FEDERATION</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Assembly;C;Python;R;Rust</td>
      <td>Julia;Python;Rust</td>
      <td>SQLite</td>
      <td>SQLite</td>
      <td>Heroku</td>
      <td>NaN</td>
      <td>Flask</td>
      <td>Flask</td>
      <td>...</td>
      <td>Keras;NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>IPython/Jupyter;PyCharm;RStudio;Sublime Text;V...</td>
      <td>IPython/Jupyter;RStudio;Sublime Text;Visual St...</td>
      <td>MacOS</td>
      <td>Visit Stack Overflow;Google it;Watch help / tu...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Multiple times per day</td>
      <td>True</td>
      <td>Multiple times per day</td>
      <td>Yes, definitely</td>
      <td>Yes</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
      <td>Visit Stack Overflow;Google it;Watch help / tu...</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>AUSTRIA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>11 - 17 years</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Developer, front-end</td>
      <td>100 to 499 employees</td>
      <td>EUR European Euro</td>
      <td>NaN</td>
      <td>Monthly</td>
      <td>JavaScript;TypeScript</td>
      <td>JavaScript;TypeScript</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Angular;jQuery</td>
      <td>Angular;jQuery</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>Daily or almost daily</td>
      <td>Neutral</td>
      <td>No</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>I am deaf / hard of hearing</td>
      <td>NaN</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>NaN</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>UNITED KINGDOM OF GREAT BRITAIN AND NORTHERN I...</td>
      <td>NaN</td>
      <td>England</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>5 - 10 years</td>
      <td>Friend or family member</td>
      <td>17</td>
      <td>10</td>
      <td>Developer, desktop or enterprise applications;...</td>
      <td>Just me - I am a freelancer, sole proprietor, ...</td>
      <td>GBP\tPound sterling</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bash/Shell;HTML/CSS;Python;SQL</td>
      <td>Bash/Shell;HTML/CSS;Python;SQL</td>
      <td>Elasticsearch;PostgreSQL;Redis</td>
      <td>Cassandra;Elasticsearch;PostgreSQL;Redis</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Flask</td>
      <td>Flask</td>
      <td>...</td>
      <td>Hadoop;NumPy;Pandas</td>
      <td>Docker;Git;Kubernetes;Yarn</td>
      <td>Docker;Git;Kubernetes;Yarn</td>
      <td>Atom;IPython/Jupyter;Notepad++;PyCharm;Vim</td>
      <td>Atom;IPython/Jupyter;Notepad++;PyCharm;Vim;Vis...</td>
      <td>Linux-based</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>A few times per week</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>NaN</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>NaN</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>83434</th>
      <td>83435</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>Texas</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>6</td>
      <td>5</td>
      <td>Developer, back-end</td>
      <td>20 to 99 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>160500.0</td>
      <td>Yearly</td>
      <td>Clojure;Kotlin;SQL</td>
      <td>Clojure</td>
      <td>Oracle;SQLite</td>
      <td>SQLite</td>
      <td>AWS</td>
      <td>AWS</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>Git;Kubernetes</td>
      <td>IntelliJ;Sublime Text;Vim;Visual Studio Code</td>
      <td>Sublime Text;Vim</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Google it</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>False</td>
      <td>NaN</td>
      <td>No, not at all</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>I have a concentration and/or memory disorder ...</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>160500.0</td>
      <td>Call a coworker or friend;Google it Stack Over...</td>
    </tr>
    <tr>
      <th>83435</th>
      <td>83436</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>BENIN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>4</td>
      <td>2</td>
      <td>Developer, full-stack</td>
      <td>Just me - I am a freelancer, sole proprietor, ...</td>
      <td>XOF\tWest African CFA franc</td>
      <td>200000.0</td>
      <td>Monthly</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Firebase;MariaDB;MySQL;PostgreSQL;Redis;SQLite</td>
      <td>Firebase;MariaDB;MongoDB;MySQL;PostgreSQL;Redi...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Django;jQuery;Laravel;React.js;Ruby on Rails</td>
      <td>Django;Express;jQuery;Laravel;React.js;Ruby on...</td>
      <td>...</td>
      <td>NaN</td>
      <td>Git;Unity 3D;Unreal Engine</td>
      <td>Docker;Git;Kubernetes</td>
      <td>Android Studio;Eclipse;Emacs;IntelliJ;NetBeans...</td>
      <td>Emacs;IntelliJ;PHPStorm;PyCharm;RStudio;Sublim...</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Multiple times per day</td>
      <td>True</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Black or of African descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>3960.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>83436</th>
      <td>83437</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>New Jersey</td>
      <td>NaN</td>
      <td>Secondary school (e.g. American high school, G...</td>
      <td>11 - 17 years</td>
      <td>School</td>
      <td>10</td>
      <td>4</td>
      <td>Data scientist or machine learning specialist;...</td>
      <td>10,000 or more employees</td>
      <td>USD\tUnited States dollar</td>
      <td>1800.0</td>
      <td>Weekly</td>
      <td>Groovy;Java;Python</td>
      <td>Java;Python</td>
      <td>DynamoDB;Elasticsearch;MongoDB;PostgreSQL;Redis</td>
      <td>DynamoDB;Redis</td>
      <td>AWS;Google Cloud Platform</td>
      <td>AWS</td>
      <td>FastAPI;Flask</td>
      <td>FastAPI;Flask</td>
      <td>...</td>
      <td>Apache Spark;Hadoop;Keras;NumPy;Pandas;TensorFlow</td>
      <td>Ansible;Docker;Git;Terraform</td>
      <td>Docker;Git;Kubernetes;Terraform</td>
      <td>Android Studio;Eclipse;IntelliJ;IPython/Jupyte...</td>
      <td>IntelliJ;IPython/Jupyter;Notepad++;Vim</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>True</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>No, not really</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>NaN</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>90000.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>83437</th>
      <td>83438</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>CANADA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Online Courses or Certification;Books / Physic...</td>
      <td>5</td>
      <td>3</td>
      <td>Developer, back-end</td>
      <td>20 to 99 employees</td>
      <td>CAD\tCanadian dollar</td>
      <td>90000.0</td>
      <td>Monthly</td>
      <td>Bash/Shell;JavaScript;Node.js;Python</td>
      <td>Go;Rust</td>
      <td>Cassandra;Elasticsearch;MongoDB;PostgreSQL;Redis</td>
      <td>NaN</td>
      <td>Heroku</td>
      <td>AWS;DigitalOcean</td>
      <td>Django;Express;Flask;React.js</td>
      <td>NaN</td>
      <td>...</td>
      <td>NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>Ansible;Docker;Git;Terraform</td>
      <td>Kubernetes;Terraform</td>
      <td>PyCharm;Sublime Text</td>
      <td>NaN</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>A few times per month or weekly</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>No, not really</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>I have a mood or emotional disorder (e.g. depr...</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>816816.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>83438</th>
      <td>83439</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>BRAZIL</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Professional degree (JD, MD, etc.)</td>
      <td>11 - 17 years</td>
      <td>School</td>
      <td>14</td>
      <td>4</td>
      <td>Developer, front-end;Developer, full-stack;Dev...</td>
      <td>I don’t know</td>
      <td>BRL\tBrazilian real</td>
      <td>7700.0</td>
      <td>Monthly</td>
      <td>Delphi;Elixir;HTML/CSS;Java;JavaScript</td>
      <td>Elixir;HTML/CSS;Java;JavaScript;Node.js;PHP;SQ...</td>
      <td>Oracle;PostgreSQL</td>
      <td>Elasticsearch;MongoDB;MySQL;Oracle;PostgreSQL;...</td>
      <td>Microsoft Azure</td>
      <td>AWS</td>
      <td>Angular;Spring</td>
      <td>Express;Laravel;Spring;Symfony</td>
      <td>...</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>Docker;Git;Kubernetes</td>
      <td>IntelliJ;Visual Studio Code</td>
      <td>IntelliJ;PHPStorm;Visual Studio Code</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange;Stack Overflow f...</td>
      <td>A few times per week</td>
      <td>True</td>
      <td>A few times per week</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Hispanic or Latino/a/x</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>21168.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
  </tbody>
</table>
<p>83439 rows × 49 columns</p>
</div>




```python
# Eliminar columnas
# Otra opción: del datos['nombre_columna']
# Aplicar los cambios con: inplace=True
datos.drop(columns=['NEWSTUCK', 'NEWSOSITES'])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>RESPONSEID</th>
      <th>MAINBRANCH</th>
      <th>EMPLOYMENT</th>
      <th>COUNTRY</th>
      <th>USSTATE</th>
      <th>UKCOUNTRY</th>
      <th>EDLEVEL</th>
      <th>AGE1STCODE</th>
      <th>LEARNCODE</th>
      <th>YEARSCODE</th>
      <th>YEARSCODEPRO</th>
      <th>DEVTYPE</th>
      <th>ORGSIZE</th>
      <th>CURRENCY</th>
      <th>COMPTOTAL</th>
      <th>COMPFREQ</th>
      <th>LANGUAGEHAVEWORKEDWITH</th>
      <th>LANGUAGEWANTTOWORKWITH</th>
      <th>DATABASEHAVEWORKEDWITH</th>
      <th>DATABASEWANTTOWORKWITH</th>
      <th>PLATFORMHAVEWORKEDWITH</th>
      <th>PLATFORMWANTTOWORKWITH</th>
      <th>WEBFRAMEHAVEWORKEDWITH</th>
      <th>WEBFRAMEWANTTOWORKWITH</th>
      <th>MISCTECHHAVEWORKEDWITH</th>
      <th>MISCTECHWANTTOWORKWITH</th>
      <th>TOOLSTECHHAVEWORKEDWITH</th>
      <th>TOOLSTECHWANTTOWORKWITH</th>
      <th>NEWCOLLABTOOLSHAVEWORKEDWITH</th>
      <th>NEWCOLLABTOOLSWANTTOWORKWITH</th>
      <th>OPSYS</th>
      <th>SOVISITFREQ</th>
      <th>SOACCOUNT</th>
      <th>SOPARTFREQ</th>
      <th>SOCOMM</th>
      <th>NEWOTHERCOMMS</th>
      <th>AGE</th>
      <th>GENDER</th>
      <th>TRANS</th>
      <th>SEXUALITY</th>
      <th>ETHNICITY</th>
      <th>ACCESSIBILITY</th>
      <th>MENTALHEALTH</th>
      <th>SURVEYLENGTH</th>
      <th>SURVEYEASE</th>
      <th>CONVERTEDCOMPYEARLY</th>
      <th>AYUDA</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>SLOVAKIA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Secondary school (e.g. American high school, G...</td>
      <td>18 - 24 years</td>
      <td>Coding Bootcamp;Other online resources (ex: vi...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Developer, mobile</td>
      <td>20 to 99 employees</td>
      <td>EUR European Euro</td>
      <td>4800.0</td>
      <td>Monthly</td>
      <td>C++;HTML/CSS;JavaScript;Objective-C;PHP;Swift</td>
      <td>Swift</td>
      <td>PostgreSQL;SQLite</td>
      <td>SQLite</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Laravel;Symfony</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>PHPStorm;Xcode</td>
      <td>Atom;Xcode</td>
      <td>MacOS</td>
      <td>Multiple times per day</td>
      <td>True</td>
      <td>A few times per month or weekly</td>
      <td>Yes, definitely</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>62268.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>I am a student who is learning to code</td>
      <td>Student, full-time</td>
      <td>NETHERLANDS</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>7</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>JavaScript;Python</td>
      <td>Python</td>
      <td>PostgreSQL</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Angular;Flask;Vue.js</td>
      <td>NaN</td>
      <td>Cordova</td>
      <td>NaN</td>
      <td>Docker;Git;Yarn</td>
      <td>Git</td>
      <td>Android Studio;IntelliJ;Notepad++;PyCharm</td>
      <td>NaN</td>
      <td>Windows</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>Daily or almost daily</td>
      <td>Yes, definitely</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
      <td>Visit Stack Overflow;Google it Stack Overflow</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>I am not primarily a developer, but I write co...</td>
      <td>Student, full-time</td>
      <td>RUSSIAN FEDERATION</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Assembly;C;Python;R;Rust</td>
      <td>Julia;Python;Rust</td>
      <td>SQLite</td>
      <td>SQLite</td>
      <td>Heroku</td>
      <td>NaN</td>
      <td>Flask</td>
      <td>Flask</td>
      <td>NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>Keras;NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>IPython/Jupyter;PyCharm;RStudio;Sublime Text;V...</td>
      <td>IPython/Jupyter;RStudio;Sublime Text;Visual St...</td>
      <td>MacOS</td>
      <td>Multiple times per day</td>
      <td>True</td>
      <td>Multiple times per day</td>
      <td>Yes, definitely</td>
      <td>Yes</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
      <td>Visit Stack Overflow;Google it;Watch help / tu...</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>AUSTRIA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>11 - 17 years</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Developer, front-end</td>
      <td>100 to 499 employees</td>
      <td>EUR European Euro</td>
      <td>NaN</td>
      <td>Monthly</td>
      <td>JavaScript;TypeScript</td>
      <td>JavaScript;TypeScript</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Angular;jQuery</td>
      <td>Angular;jQuery</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Windows</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>Daily or almost daily</td>
      <td>Neutral</td>
      <td>No</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>I am deaf / hard of hearing</td>
      <td>NaN</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>NaN</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>UNITED KINGDOM OF GREAT BRITAIN AND NORTHERN I...</td>
      <td>NaN</td>
      <td>England</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>5 - 10 years</td>
      <td>Friend or family member</td>
      <td>17</td>
      <td>10</td>
      <td>Developer, desktop or enterprise applications;...</td>
      <td>Just me - I am a freelancer, sole proprietor, ...</td>
      <td>GBP\tPound sterling</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bash/Shell;HTML/CSS;Python;SQL</td>
      <td>Bash/Shell;HTML/CSS;Python;SQL</td>
      <td>Elasticsearch;PostgreSQL;Redis</td>
      <td>Cassandra;Elasticsearch;PostgreSQL;Redis</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Flask</td>
      <td>Flask</td>
      <td>Apache Spark;Hadoop;NumPy;Pandas</td>
      <td>Hadoop;NumPy;Pandas</td>
      <td>Docker;Git;Kubernetes;Yarn</td>
      <td>Docker;Git;Kubernetes;Yarn</td>
      <td>Atom;IPython/Jupyter;Notepad++;PyCharm;Vim</td>
      <td>Atom;IPython/Jupyter;Notepad++;PyCharm;Vim;Vis...</td>
      <td>Linux-based</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>A few times per week</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>NaN</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>NaN</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>83434</th>
      <td>83435</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>Texas</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>6</td>
      <td>5</td>
      <td>Developer, back-end</td>
      <td>20 to 99 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>160500.0</td>
      <td>Yearly</td>
      <td>Clojure;Kotlin;SQL</td>
      <td>Clojure</td>
      <td>Oracle;SQLite</td>
      <td>SQLite</td>
      <td>AWS</td>
      <td>AWS</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>Git;Kubernetes</td>
      <td>IntelliJ;Sublime Text;Vim;Visual Studio Code</td>
      <td>Sublime Text;Vim</td>
      <td>MacOS</td>
      <td>A few times per week</td>
      <td>False</td>
      <td>NaN</td>
      <td>No, not at all</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>I have a concentration and/or memory disorder ...</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>160500.0</td>
      <td>Call a coworker or friend;Google it Stack Over...</td>
    </tr>
    <tr>
      <th>83435</th>
      <td>83436</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>BENIN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>4</td>
      <td>2</td>
      <td>Developer, full-stack</td>
      <td>Just me - I am a freelancer, sole proprietor, ...</td>
      <td>XOF\tWest African CFA franc</td>
      <td>200000.0</td>
      <td>Monthly</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Firebase;MariaDB;MySQL;PostgreSQL;Redis;SQLite</td>
      <td>Firebase;MariaDB;MongoDB;MySQL;PostgreSQL;Redi...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Django;jQuery;Laravel;React.js;Ruby on Rails</td>
      <td>Django;Express;jQuery;Laravel;React.js;Ruby on...</td>
      <td>Flutter;Qt</td>
      <td>NaN</td>
      <td>Git;Unity 3D;Unreal Engine</td>
      <td>Docker;Git;Kubernetes</td>
      <td>Android Studio;Eclipse;Emacs;IntelliJ;NetBeans...</td>
      <td>Emacs;IntelliJ;PHPStorm;PyCharm;RStudio;Sublim...</td>
      <td>Linux-based</td>
      <td>Multiple times per day</td>
      <td>True</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Black or of African descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>3960.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>83436</th>
      <td>83437</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>New Jersey</td>
      <td>NaN</td>
      <td>Secondary school (e.g. American high school, G...</td>
      <td>11 - 17 years</td>
      <td>School</td>
      <td>10</td>
      <td>4</td>
      <td>Data scientist or machine learning specialist;...</td>
      <td>10,000 or more employees</td>
      <td>USD\tUnited States dollar</td>
      <td>1800.0</td>
      <td>Weekly</td>
      <td>Groovy;Java;Python</td>
      <td>Java;Python</td>
      <td>DynamoDB;Elasticsearch;MongoDB;PostgreSQL;Redis</td>
      <td>DynamoDB;Redis</td>
      <td>AWS;Google Cloud Platform</td>
      <td>AWS</td>
      <td>FastAPI;Flask</td>
      <td>FastAPI;Flask</td>
      <td>Hadoop;Keras;NumPy;Pandas</td>
      <td>Apache Spark;Hadoop;Keras;NumPy;Pandas;TensorFlow</td>
      <td>Ansible;Docker;Git;Terraform</td>
      <td>Docker;Git;Kubernetes;Terraform</td>
      <td>Android Studio;Eclipse;IntelliJ;IPython/Jupyte...</td>
      <td>IntelliJ;IPython/Jupyter;Notepad++;Vim</td>
      <td>Windows</td>
      <td>A few times per week</td>
      <td>True</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>No, not really</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>NaN</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>90000.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>83437</th>
      <td>83438</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>CANADA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Online Courses or Certification;Books / Physic...</td>
      <td>5</td>
      <td>3</td>
      <td>Developer, back-end</td>
      <td>20 to 99 employees</td>
      <td>CAD\tCanadian dollar</td>
      <td>90000.0</td>
      <td>Monthly</td>
      <td>Bash/Shell;JavaScript;Node.js;Python</td>
      <td>Go;Rust</td>
      <td>Cassandra;Elasticsearch;MongoDB;PostgreSQL;Redis</td>
      <td>NaN</td>
      <td>Heroku</td>
      <td>AWS;DigitalOcean</td>
      <td>Django;Express;Flask;React.js</td>
      <td>NaN</td>
      <td>NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>Ansible;Docker;Git;Terraform</td>
      <td>Kubernetes;Terraform</td>
      <td>PyCharm;Sublime Text</td>
      <td>NaN</td>
      <td>MacOS</td>
      <td>A few times per month or weekly</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>No, not really</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>I have a mood or emotional disorder (e.g. depr...</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>816816.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>83438</th>
      <td>83439</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>BRAZIL</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Professional degree (JD, MD, etc.)</td>
      <td>11 - 17 years</td>
      <td>School</td>
      <td>14</td>
      <td>4</td>
      <td>Developer, front-end;Developer, full-stack;Dev...</td>
      <td>I don’t know</td>
      <td>BRL\tBrazilian real</td>
      <td>7700.0</td>
      <td>Monthly</td>
      <td>Delphi;Elixir;HTML/CSS;Java;JavaScript</td>
      <td>Elixir;HTML/CSS;Java;JavaScript;Node.js;PHP;SQ...</td>
      <td>Oracle;PostgreSQL</td>
      <td>Elasticsearch;MongoDB;MySQL;Oracle;PostgreSQL;...</td>
      <td>Microsoft Azure</td>
      <td>AWS</td>
      <td>Angular;Spring</td>
      <td>Express;Laravel;Spring;Symfony</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>Docker;Git;Kubernetes</td>
      <td>IntelliJ;Visual Studio Code</td>
      <td>IntelliJ;PHPStorm;Visual Studio Code</td>
      <td>Linux-based</td>
      <td>A few times per week</td>
      <td>True</td>
      <td>A few times per week</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Hispanic or Latino/a/x</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>21168.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
  </tbody>
</table>
<p>83439 rows × 47 columns</p>
</div>




```python
# Dividir una columna
# datos[['datos1', 'datos2']] = datos['nombre_columna'].str.split(' ', expand=True)
```


```python
# Agregar una fila o registro
datos.append({'LANGUAGEWANTTOWORKWITH':'Python'}, ignore_index=True)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>RESPONSEID</th>
      <th>MAINBRANCH</th>
      <th>EMPLOYMENT</th>
      <th>COUNTRY</th>
      <th>USSTATE</th>
      <th>UKCOUNTRY</th>
      <th>EDLEVEL</th>
      <th>AGE1STCODE</th>
      <th>LEARNCODE</th>
      <th>YEARSCODE</th>
      <th>YEARSCODEPRO</th>
      <th>DEVTYPE</th>
      <th>ORGSIZE</th>
      <th>CURRENCY</th>
      <th>COMPTOTAL</th>
      <th>COMPFREQ</th>
      <th>LANGUAGEHAVEWORKEDWITH</th>
      <th>LANGUAGEWANTTOWORKWITH</th>
      <th>DATABASEHAVEWORKEDWITH</th>
      <th>DATABASEWANTTOWORKWITH</th>
      <th>PLATFORMHAVEWORKEDWITH</th>
      <th>PLATFORMWANTTOWORKWITH</th>
      <th>WEBFRAMEHAVEWORKEDWITH</th>
      <th>WEBFRAMEWANTTOWORKWITH</th>
      <th>...</th>
      <th>MISCTECHWANTTOWORKWITH</th>
      <th>TOOLSTECHHAVEWORKEDWITH</th>
      <th>TOOLSTECHWANTTOWORKWITH</th>
      <th>NEWCOLLABTOOLSHAVEWORKEDWITH</th>
      <th>NEWCOLLABTOOLSWANTTOWORKWITH</th>
      <th>OPSYS</th>
      <th>NEWSTUCK</th>
      <th>NEWSOSITES</th>
      <th>SOVISITFREQ</th>
      <th>SOACCOUNT</th>
      <th>SOPARTFREQ</th>
      <th>SOCOMM</th>
      <th>NEWOTHERCOMMS</th>
      <th>AGE</th>
      <th>GENDER</th>
      <th>TRANS</th>
      <th>SEXUALITY</th>
      <th>ETHNICITY</th>
      <th>ACCESSIBILITY</th>
      <th>MENTALHEALTH</th>
      <th>SURVEYLENGTH</th>
      <th>SURVEYEASE</th>
      <th>CONVERTEDCOMPYEARLY</th>
      <th>AYUDA</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1.0</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>SLOVAKIA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Secondary school (e.g. American high school, G...</td>
      <td>18 - 24 years</td>
      <td>Coding Bootcamp;Other online resources (ex: vi...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Developer, mobile</td>
      <td>20 to 99 employees</td>
      <td>EUR European Euro</td>
      <td>4800.0</td>
      <td>Monthly</td>
      <td>C++;HTML/CSS;JavaScript;Objective-C;PHP;Swift</td>
      <td>Swift</td>
      <td>PostgreSQL;SQLite</td>
      <td>SQLite</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Laravel;Symfony</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>PHPStorm;Xcode</td>
      <td>Atom;Xcode</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>Multiple times per day</td>
      <td>True</td>
      <td>A few times per month or weekly</td>
      <td>Yes, definitely</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>62268.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2.0</td>
      <td>I am a student who is learning to code</td>
      <td>Student, full-time</td>
      <td>NETHERLANDS</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>7</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>JavaScript;Python</td>
      <td>Python</td>
      <td>PostgreSQL</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Angular;Flask;Vue.js</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>Docker;Git;Yarn</td>
      <td>Git</td>
      <td>Android Studio;IntelliJ;Notepad++;PyCharm</td>
      <td>NaN</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Google it</td>
      <td>Stack Overflow</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>Daily or almost daily</td>
      <td>Yes, definitely</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
      <td>Visit Stack Overflow;Google it Stack Overflow</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3.0</td>
      <td>I am not primarily a developer, but I write co...</td>
      <td>Student, full-time</td>
      <td>RUSSIAN FEDERATION</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Assembly;C;Python;R;Rust</td>
      <td>Julia;Python;Rust</td>
      <td>SQLite</td>
      <td>SQLite</td>
      <td>Heroku</td>
      <td>NaN</td>
      <td>Flask</td>
      <td>Flask</td>
      <td>...</td>
      <td>Keras;NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>IPython/Jupyter;PyCharm;RStudio;Sublime Text;V...</td>
      <td>IPython/Jupyter;RStudio;Sublime Text;Visual St...</td>
      <td>MacOS</td>
      <td>Visit Stack Overflow;Google it;Watch help / tu...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Multiple times per day</td>
      <td>True</td>
      <td>Multiple times per day</td>
      <td>Yes, definitely</td>
      <td>Yes</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
      <td>Visit Stack Overflow;Google it;Watch help / tu...</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4.0</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>AUSTRIA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>11 - 17 years</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Developer, front-end</td>
      <td>100 to 499 employees</td>
      <td>EUR European Euro</td>
      <td>NaN</td>
      <td>Monthly</td>
      <td>JavaScript;TypeScript</td>
      <td>JavaScript;TypeScript</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Angular;jQuery</td>
      <td>Angular;jQuery</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>Daily or almost daily</td>
      <td>Neutral</td>
      <td>No</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>I am deaf / hard of hearing</td>
      <td>NaN</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>NaN</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5.0</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>UNITED KINGDOM OF GREAT BRITAIN AND NORTHERN I...</td>
      <td>NaN</td>
      <td>England</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>5 - 10 years</td>
      <td>Friend or family member</td>
      <td>17</td>
      <td>10</td>
      <td>Developer, desktop or enterprise applications;...</td>
      <td>Just me - I am a freelancer, sole proprietor, ...</td>
      <td>GBP\tPound sterling</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bash/Shell;HTML/CSS;Python;SQL</td>
      <td>Bash/Shell;HTML/CSS;Python;SQL</td>
      <td>Elasticsearch;PostgreSQL;Redis</td>
      <td>Cassandra;Elasticsearch;PostgreSQL;Redis</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Flask</td>
      <td>Flask</td>
      <td>...</td>
      <td>Hadoop;NumPy;Pandas</td>
      <td>Docker;Git;Kubernetes;Yarn</td>
      <td>Docker;Git;Kubernetes;Yarn</td>
      <td>Atom;IPython/Jupyter;Notepad++;PyCharm;Vim</td>
      <td>Atom;IPython/Jupyter;Notepad++;PyCharm;Vim;Vis...</td>
      <td>Linux-based</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>A few times per week</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>NaN</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>NaN</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>83435</th>
      <td>83436.0</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>BENIN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>4</td>
      <td>2</td>
      <td>Developer, full-stack</td>
      <td>Just me - I am a freelancer, sole proprietor, ...</td>
      <td>XOF\tWest African CFA franc</td>
      <td>200000.0</td>
      <td>Monthly</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Firebase;MariaDB;MySQL;PostgreSQL;Redis;SQLite</td>
      <td>Firebase;MariaDB;MongoDB;MySQL;PostgreSQL;Redi...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Django;jQuery;Laravel;React.js;Ruby on Rails</td>
      <td>Django;Express;jQuery;Laravel;React.js;Ruby on...</td>
      <td>...</td>
      <td>NaN</td>
      <td>Git;Unity 3D;Unreal Engine</td>
      <td>Docker;Git;Kubernetes</td>
      <td>Android Studio;Eclipse;Emacs;IntelliJ;NetBeans...</td>
      <td>Emacs;IntelliJ;PHPStorm;PyCharm;RStudio;Sublim...</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Multiple times per day</td>
      <td>True</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Black or of African descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>3960.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>83436</th>
      <td>83437.0</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>New Jersey</td>
      <td>NaN</td>
      <td>Secondary school (e.g. American high school, G...</td>
      <td>11 - 17 years</td>
      <td>School</td>
      <td>10</td>
      <td>4</td>
      <td>Data scientist or machine learning specialist;...</td>
      <td>10,000 or more employees</td>
      <td>USD\tUnited States dollar</td>
      <td>1800.0</td>
      <td>Weekly</td>
      <td>Groovy;Java;Python</td>
      <td>Java;Python</td>
      <td>DynamoDB;Elasticsearch;MongoDB;PostgreSQL;Redis</td>
      <td>DynamoDB;Redis</td>
      <td>AWS;Google Cloud Platform</td>
      <td>AWS</td>
      <td>FastAPI;Flask</td>
      <td>FastAPI;Flask</td>
      <td>...</td>
      <td>Apache Spark;Hadoop;Keras;NumPy;Pandas;TensorFlow</td>
      <td>Ansible;Docker;Git;Terraform</td>
      <td>Docker;Git;Kubernetes;Terraform</td>
      <td>Android Studio;Eclipse;IntelliJ;IPython/Jupyte...</td>
      <td>IntelliJ;IPython/Jupyter;Notepad++;Vim</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>True</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>No, not really</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>NaN</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>90000.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>83437</th>
      <td>83438.0</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>CANADA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Online Courses or Certification;Books / Physic...</td>
      <td>5</td>
      <td>3</td>
      <td>Developer, back-end</td>
      <td>20 to 99 employees</td>
      <td>CAD\tCanadian dollar</td>
      <td>90000.0</td>
      <td>Monthly</td>
      <td>Bash/Shell;JavaScript;Node.js;Python</td>
      <td>Go;Rust</td>
      <td>Cassandra;Elasticsearch;MongoDB;PostgreSQL;Redis</td>
      <td>NaN</td>
      <td>Heroku</td>
      <td>AWS;DigitalOcean</td>
      <td>Django;Express;Flask;React.js</td>
      <td>NaN</td>
      <td>...</td>
      <td>NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>Ansible;Docker;Git;Terraform</td>
      <td>Kubernetes;Terraform</td>
      <td>PyCharm;Sublime Text</td>
      <td>NaN</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>A few times per month or weekly</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>No, not really</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>I have a mood or emotional disorder (e.g. depr...</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>816816.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>83438</th>
      <td>83439.0</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>BRAZIL</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Professional degree (JD, MD, etc.)</td>
      <td>11 - 17 years</td>
      <td>School</td>
      <td>14</td>
      <td>4</td>
      <td>Developer, front-end;Developer, full-stack;Dev...</td>
      <td>I don’t know</td>
      <td>BRL\tBrazilian real</td>
      <td>7700.0</td>
      <td>Monthly</td>
      <td>Delphi;Elixir;HTML/CSS;Java;JavaScript</td>
      <td>Elixir;HTML/CSS;Java;JavaScript;Node.js;PHP;SQ...</td>
      <td>Oracle;PostgreSQL</td>
      <td>Elasticsearch;MongoDB;MySQL;Oracle;PostgreSQL;...</td>
      <td>Microsoft Azure</td>
      <td>AWS</td>
      <td>Angular;Spring</td>
      <td>Express;Laravel;Spring;Symfony</td>
      <td>...</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>Docker;Git;Kubernetes</td>
      <td>IntelliJ;Visual Studio Code</td>
      <td>IntelliJ;PHPStorm;Visual Studio Code</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange;Stack Overflow f...</td>
      <td>A few times per week</td>
      <td>True</td>
      <td>A few times per week</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Hispanic or Latino/a/x</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>21168.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>83439</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Python</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>83440 rows × 49 columns</p>
</div>




```python
# Agregar otro dataframe
datos_doble = datos.append(datos)
```


```python
datos_doble
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>RESPONSEID</th>
      <th>MAINBRANCH</th>
      <th>EMPLOYMENT</th>
      <th>COUNTRY</th>
      <th>USSTATE</th>
      <th>UKCOUNTRY</th>
      <th>EDLEVEL</th>
      <th>AGE1STCODE</th>
      <th>LEARNCODE</th>
      <th>YEARSCODE</th>
      <th>YEARSCODEPRO</th>
      <th>DEVTYPE</th>
      <th>ORGSIZE</th>
      <th>CURRENCY</th>
      <th>COMPTOTAL</th>
      <th>COMPFREQ</th>
      <th>LANGUAGEHAVEWORKEDWITH</th>
      <th>LANGUAGEWANTTOWORKWITH</th>
      <th>DATABASEHAVEWORKEDWITH</th>
      <th>DATABASEWANTTOWORKWITH</th>
      <th>PLATFORMHAVEWORKEDWITH</th>
      <th>PLATFORMWANTTOWORKWITH</th>
      <th>WEBFRAMEHAVEWORKEDWITH</th>
      <th>WEBFRAMEWANTTOWORKWITH</th>
      <th>...</th>
      <th>MISCTECHWANTTOWORKWITH</th>
      <th>TOOLSTECHHAVEWORKEDWITH</th>
      <th>TOOLSTECHWANTTOWORKWITH</th>
      <th>NEWCOLLABTOOLSHAVEWORKEDWITH</th>
      <th>NEWCOLLABTOOLSWANTTOWORKWITH</th>
      <th>OPSYS</th>
      <th>NEWSTUCK</th>
      <th>NEWSOSITES</th>
      <th>SOVISITFREQ</th>
      <th>SOACCOUNT</th>
      <th>SOPARTFREQ</th>
      <th>SOCOMM</th>
      <th>NEWOTHERCOMMS</th>
      <th>AGE</th>
      <th>GENDER</th>
      <th>TRANS</th>
      <th>SEXUALITY</th>
      <th>ETHNICITY</th>
      <th>ACCESSIBILITY</th>
      <th>MENTALHEALTH</th>
      <th>SURVEYLENGTH</th>
      <th>SURVEYEASE</th>
      <th>CONVERTEDCOMPYEARLY</th>
      <th>AYUDA</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>SLOVAKIA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Secondary school (e.g. American high school, G...</td>
      <td>18 - 24 years</td>
      <td>Coding Bootcamp;Other online resources (ex: vi...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Developer, mobile</td>
      <td>20 to 99 employees</td>
      <td>EUR European Euro</td>
      <td>4800.0</td>
      <td>Monthly</td>
      <td>C++;HTML/CSS;JavaScript;Objective-C;PHP;Swift</td>
      <td>Swift</td>
      <td>PostgreSQL;SQLite</td>
      <td>SQLite</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Laravel;Symfony</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>PHPStorm;Xcode</td>
      <td>Atom;Xcode</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>Multiple times per day</td>
      <td>True</td>
      <td>A few times per month or weekly</td>
      <td>Yes, definitely</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>62268.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>I am a student who is learning to code</td>
      <td>Student, full-time</td>
      <td>NETHERLANDS</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>7</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>JavaScript;Python</td>
      <td>Python</td>
      <td>PostgreSQL</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Angular;Flask;Vue.js</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>Docker;Git;Yarn</td>
      <td>Git</td>
      <td>Android Studio;IntelliJ;Notepad++;PyCharm</td>
      <td>NaN</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Google it</td>
      <td>Stack Overflow</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>Daily or almost daily</td>
      <td>Yes, definitely</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
      <td>Visit Stack Overflow;Google it Stack Overflow</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>I am not primarily a developer, but I write co...</td>
      <td>Student, full-time</td>
      <td>RUSSIAN FEDERATION</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Assembly;C;Python;R;Rust</td>
      <td>Julia;Python;Rust</td>
      <td>SQLite</td>
      <td>SQLite</td>
      <td>Heroku</td>
      <td>NaN</td>
      <td>Flask</td>
      <td>Flask</td>
      <td>...</td>
      <td>Keras;NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>IPython/Jupyter;PyCharm;RStudio;Sublime Text;V...</td>
      <td>IPython/Jupyter;RStudio;Sublime Text;Visual St...</td>
      <td>MacOS</td>
      <td>Visit Stack Overflow;Google it;Watch help / tu...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Multiple times per day</td>
      <td>True</td>
      <td>Multiple times per day</td>
      <td>Yes, definitely</td>
      <td>Yes</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
      <td>Visit Stack Overflow;Google it;Watch help / tu...</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>AUSTRIA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>11 - 17 years</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Developer, front-end</td>
      <td>100 to 499 employees</td>
      <td>EUR European Euro</td>
      <td>NaN</td>
      <td>Monthly</td>
      <td>JavaScript;TypeScript</td>
      <td>JavaScript;TypeScript</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Angular;jQuery</td>
      <td>Angular;jQuery</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>Daily or almost daily</td>
      <td>Neutral</td>
      <td>No</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>I am deaf / hard of hearing</td>
      <td>NaN</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>NaN</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>UNITED KINGDOM OF GREAT BRITAIN AND NORTHERN I...</td>
      <td>NaN</td>
      <td>England</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>5 - 10 years</td>
      <td>Friend or family member</td>
      <td>17</td>
      <td>10</td>
      <td>Developer, desktop or enterprise applications;...</td>
      <td>Just me - I am a freelancer, sole proprietor, ...</td>
      <td>GBP\tPound sterling</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bash/Shell;HTML/CSS;Python;SQL</td>
      <td>Bash/Shell;HTML/CSS;Python;SQL</td>
      <td>Elasticsearch;PostgreSQL;Redis</td>
      <td>Cassandra;Elasticsearch;PostgreSQL;Redis</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Flask</td>
      <td>Flask</td>
      <td>...</td>
      <td>Hadoop;NumPy;Pandas</td>
      <td>Docker;Git;Kubernetes;Yarn</td>
      <td>Docker;Git;Kubernetes;Yarn</td>
      <td>Atom;IPython/Jupyter;Notepad++;PyCharm;Vim</td>
      <td>Atom;IPython/Jupyter;Notepad++;PyCharm;Vim;Vis...</td>
      <td>Linux-based</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>A few times per week</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>NaN</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>NaN</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>83434</th>
      <td>83435</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>Texas</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>6</td>
      <td>5</td>
      <td>Developer, back-end</td>
      <td>20 to 99 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>160500.0</td>
      <td>Yearly</td>
      <td>Clojure;Kotlin;SQL</td>
      <td>Clojure</td>
      <td>Oracle;SQLite</td>
      <td>SQLite</td>
      <td>AWS</td>
      <td>AWS</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>Git;Kubernetes</td>
      <td>IntelliJ;Sublime Text;Vim;Visual Studio Code</td>
      <td>Sublime Text;Vim</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Google it</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>False</td>
      <td>NaN</td>
      <td>No, not at all</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>I have a concentration and/or memory disorder ...</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>160500.0</td>
      <td>Call a coworker or friend;Google it Stack Over...</td>
    </tr>
    <tr>
      <th>83435</th>
      <td>83436</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>BENIN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>4</td>
      <td>2</td>
      <td>Developer, full-stack</td>
      <td>Just me - I am a freelancer, sole proprietor, ...</td>
      <td>XOF\tWest African CFA franc</td>
      <td>200000.0</td>
      <td>Monthly</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Firebase;MariaDB;MySQL;PostgreSQL;Redis;SQLite</td>
      <td>Firebase;MariaDB;MongoDB;MySQL;PostgreSQL;Redi...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Django;jQuery;Laravel;React.js;Ruby on Rails</td>
      <td>Django;Express;jQuery;Laravel;React.js;Ruby on...</td>
      <td>...</td>
      <td>NaN</td>
      <td>Git;Unity 3D;Unreal Engine</td>
      <td>Docker;Git;Kubernetes</td>
      <td>Android Studio;Eclipse;Emacs;IntelliJ;NetBeans...</td>
      <td>Emacs;IntelliJ;PHPStorm;PyCharm;RStudio;Sublim...</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Multiple times per day</td>
      <td>True</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Black or of African descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>3960.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>83436</th>
      <td>83437</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>New Jersey</td>
      <td>NaN</td>
      <td>Secondary school (e.g. American high school, G...</td>
      <td>11 - 17 years</td>
      <td>School</td>
      <td>10</td>
      <td>4</td>
      <td>Data scientist or machine learning specialist;...</td>
      <td>10,000 or more employees</td>
      <td>USD\tUnited States dollar</td>
      <td>1800.0</td>
      <td>Weekly</td>
      <td>Groovy;Java;Python</td>
      <td>Java;Python</td>
      <td>DynamoDB;Elasticsearch;MongoDB;PostgreSQL;Redis</td>
      <td>DynamoDB;Redis</td>
      <td>AWS;Google Cloud Platform</td>
      <td>AWS</td>
      <td>FastAPI;Flask</td>
      <td>FastAPI;Flask</td>
      <td>...</td>
      <td>Apache Spark;Hadoop;Keras;NumPy;Pandas;TensorFlow</td>
      <td>Ansible;Docker;Git;Terraform</td>
      <td>Docker;Git;Kubernetes;Terraform</td>
      <td>Android Studio;Eclipse;IntelliJ;IPython/Jupyte...</td>
      <td>IntelliJ;IPython/Jupyter;Notepad++;Vim</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>True</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>No, not really</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>NaN</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>90000.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>83437</th>
      <td>83438</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>CANADA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Online Courses or Certification;Books / Physic...</td>
      <td>5</td>
      <td>3</td>
      <td>Developer, back-end</td>
      <td>20 to 99 employees</td>
      <td>CAD\tCanadian dollar</td>
      <td>90000.0</td>
      <td>Monthly</td>
      <td>Bash/Shell;JavaScript;Node.js;Python</td>
      <td>Go;Rust</td>
      <td>Cassandra;Elasticsearch;MongoDB;PostgreSQL;Redis</td>
      <td>NaN</td>
      <td>Heroku</td>
      <td>AWS;DigitalOcean</td>
      <td>Django;Express;Flask;React.js</td>
      <td>NaN</td>
      <td>...</td>
      <td>NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>Ansible;Docker;Git;Terraform</td>
      <td>Kubernetes;Terraform</td>
      <td>PyCharm;Sublime Text</td>
      <td>NaN</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>A few times per month or weekly</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>No, not really</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>I have a mood or emotional disorder (e.g. depr...</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>816816.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>83438</th>
      <td>83439</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>BRAZIL</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Professional degree (JD, MD, etc.)</td>
      <td>11 - 17 years</td>
      <td>School</td>
      <td>14</td>
      <td>4</td>
      <td>Developer, front-end;Developer, full-stack;Dev...</td>
      <td>I don’t know</td>
      <td>BRL\tBrazilian real</td>
      <td>7700.0</td>
      <td>Monthly</td>
      <td>Delphi;Elixir;HTML/CSS;Java;JavaScript</td>
      <td>Elixir;HTML/CSS;Java;JavaScript;Node.js;PHP;SQ...</td>
      <td>Oracle;PostgreSQL</td>
      <td>Elasticsearch;MongoDB;MySQL;Oracle;PostgreSQL;...</td>
      <td>Microsoft Azure</td>
      <td>AWS</td>
      <td>Angular;Spring</td>
      <td>Express;Laravel;Spring;Symfony</td>
      <td>...</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>Docker;Git;Kubernetes</td>
      <td>IntelliJ;Visual Studio Code</td>
      <td>IntelliJ;PHPStorm;Visual Studio Code</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange;Stack Overflow f...</td>
      <td>A few times per week</td>
      <td>True</td>
      <td>A few times per week</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Hispanic or Latino/a/x</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>21168.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
  </tbody>
</table>
<p>166878 rows × 49 columns</p>
</div>




```python
datos_doble = datos_doble.drop_duplicates()
```


```python
datos_doble.shape
```




    (83439, 49)




```python
# Eliminar una fila o registro
datos.drop(index=83438)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>RESPONSEID</th>
      <th>MAINBRANCH</th>
      <th>EMPLOYMENT</th>
      <th>COUNTRY</th>
      <th>USSTATE</th>
      <th>UKCOUNTRY</th>
      <th>EDLEVEL</th>
      <th>AGE1STCODE</th>
      <th>LEARNCODE</th>
      <th>YEARSCODE</th>
      <th>YEARSCODEPRO</th>
      <th>DEVTYPE</th>
      <th>ORGSIZE</th>
      <th>CURRENCY</th>
      <th>COMPTOTAL</th>
      <th>COMPFREQ</th>
      <th>LANGUAGEHAVEWORKEDWITH</th>
      <th>LANGUAGEWANTTOWORKWITH</th>
      <th>DATABASEHAVEWORKEDWITH</th>
      <th>DATABASEWANTTOWORKWITH</th>
      <th>PLATFORMHAVEWORKEDWITH</th>
      <th>PLATFORMWANTTOWORKWITH</th>
      <th>WEBFRAMEHAVEWORKEDWITH</th>
      <th>WEBFRAMEWANTTOWORKWITH</th>
      <th>...</th>
      <th>MISCTECHWANTTOWORKWITH</th>
      <th>TOOLSTECHHAVEWORKEDWITH</th>
      <th>TOOLSTECHWANTTOWORKWITH</th>
      <th>NEWCOLLABTOOLSHAVEWORKEDWITH</th>
      <th>NEWCOLLABTOOLSWANTTOWORKWITH</th>
      <th>OPSYS</th>
      <th>NEWSTUCK</th>
      <th>NEWSOSITES</th>
      <th>SOVISITFREQ</th>
      <th>SOACCOUNT</th>
      <th>SOPARTFREQ</th>
      <th>SOCOMM</th>
      <th>NEWOTHERCOMMS</th>
      <th>AGE</th>
      <th>GENDER</th>
      <th>TRANS</th>
      <th>SEXUALITY</th>
      <th>ETHNICITY</th>
      <th>ACCESSIBILITY</th>
      <th>MENTALHEALTH</th>
      <th>SURVEYLENGTH</th>
      <th>SURVEYEASE</th>
      <th>CONVERTEDCOMPYEARLY</th>
      <th>AYUDA</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>SLOVAKIA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Secondary school (e.g. American high school, G...</td>
      <td>18 - 24 years</td>
      <td>Coding Bootcamp;Other online resources (ex: vi...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Developer, mobile</td>
      <td>20 to 99 employees</td>
      <td>EUR European Euro</td>
      <td>4800.0</td>
      <td>Monthly</td>
      <td>C++;HTML/CSS;JavaScript;Objective-C;PHP;Swift</td>
      <td>Swift</td>
      <td>PostgreSQL;SQLite</td>
      <td>SQLite</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Laravel;Symfony</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>PHPStorm;Xcode</td>
      <td>Atom;Xcode</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>Multiple times per day</td>
      <td>True</td>
      <td>A few times per month or weekly</td>
      <td>Yes, definitely</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>62268.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>I am a student who is learning to code</td>
      <td>Student, full-time</td>
      <td>NETHERLANDS</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>7</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>JavaScript;Python</td>
      <td>Python</td>
      <td>PostgreSQL</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Angular;Flask;Vue.js</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>Docker;Git;Yarn</td>
      <td>Git</td>
      <td>Android Studio;IntelliJ;Notepad++;PyCharm</td>
      <td>NaN</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Google it</td>
      <td>Stack Overflow</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>Daily or almost daily</td>
      <td>Yes, definitely</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
      <td>Visit Stack Overflow;Google it Stack Overflow</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>I am not primarily a developer, but I write co...</td>
      <td>Student, full-time</td>
      <td>RUSSIAN FEDERATION</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Assembly;C;Python;R;Rust</td>
      <td>Julia;Python;Rust</td>
      <td>SQLite</td>
      <td>SQLite</td>
      <td>Heroku</td>
      <td>NaN</td>
      <td>Flask</td>
      <td>Flask</td>
      <td>...</td>
      <td>Keras;NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>IPython/Jupyter;PyCharm;RStudio;Sublime Text;V...</td>
      <td>IPython/Jupyter;RStudio;Sublime Text;Visual St...</td>
      <td>MacOS</td>
      <td>Visit Stack Overflow;Google it;Watch help / tu...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Multiple times per day</td>
      <td>True</td>
      <td>Multiple times per day</td>
      <td>Yes, definitely</td>
      <td>Yes</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
      <td>Visit Stack Overflow;Google it;Watch help / tu...</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>AUSTRIA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>11 - 17 years</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Developer, front-end</td>
      <td>100 to 499 employees</td>
      <td>EUR European Euro</td>
      <td>NaN</td>
      <td>Monthly</td>
      <td>JavaScript;TypeScript</td>
      <td>JavaScript;TypeScript</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Angular;jQuery</td>
      <td>Angular;jQuery</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>Daily or almost daily</td>
      <td>Neutral</td>
      <td>No</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>I am deaf / hard of hearing</td>
      <td>NaN</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>NaN</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>UNITED KINGDOM OF GREAT BRITAIN AND NORTHERN I...</td>
      <td>NaN</td>
      <td>England</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>5 - 10 years</td>
      <td>Friend or family member</td>
      <td>17</td>
      <td>10</td>
      <td>Developer, desktop or enterprise applications;...</td>
      <td>Just me - I am a freelancer, sole proprietor, ...</td>
      <td>GBP\tPound sterling</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bash/Shell;HTML/CSS;Python;SQL</td>
      <td>Bash/Shell;HTML/CSS;Python;SQL</td>
      <td>Elasticsearch;PostgreSQL;Redis</td>
      <td>Cassandra;Elasticsearch;PostgreSQL;Redis</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Flask</td>
      <td>Flask</td>
      <td>...</td>
      <td>Hadoop;NumPy;Pandas</td>
      <td>Docker;Git;Kubernetes;Yarn</td>
      <td>Docker;Git;Kubernetes;Yarn</td>
      <td>Atom;IPython/Jupyter;Notepad++;PyCharm;Vim</td>
      <td>Atom;IPython/Jupyter;Notepad++;PyCharm;Vim;Vis...</td>
      <td>Linux-based</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>A few times per week</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>NaN</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>NaN</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>83433</th>
      <td>83434</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>BRAZIL</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>18 - 24 years</td>
      <td>Online Forum;Online Courses or Certification;O...</td>
      <td>15</td>
      <td>11</td>
      <td>Developer, mobile;Developer, front-end;Develop...</td>
      <td>1,000 to 4,999 employees</td>
      <td>BRL\tBrazilian real</td>
      <td>80000.0</td>
      <td>Yearly</td>
      <td>Java;JavaScript;Kotlin;Objective-C;TypeScript</td>
      <td>Kotlin</td>
      <td>Firebase;MongoDB;MySQL;SQLite</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>React.js</td>
      <td>NaN</td>
      <td>...</td>
      <td>Flutter</td>
      <td>Docker;Git;Yarn</td>
      <td>Docker;Git</td>
      <td>Android Studio;Visual Studio Code;Xcode</td>
      <td>Android Studio;Xcode</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>A few times per month or weekly</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Hispanic or Latino/a/x</td>
      <td>None of the above</td>
      <td>I have an anxiety disorder</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>18326.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>83434</th>
      <td>83435</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>Texas</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>6</td>
      <td>5</td>
      <td>Developer, back-end</td>
      <td>20 to 99 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>160500.0</td>
      <td>Yearly</td>
      <td>Clojure;Kotlin;SQL</td>
      <td>Clojure</td>
      <td>Oracle;SQLite</td>
      <td>SQLite</td>
      <td>AWS</td>
      <td>AWS</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>Git;Kubernetes</td>
      <td>IntelliJ;Sublime Text;Vim;Visual Studio Code</td>
      <td>Sublime Text;Vim</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Google it</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>False</td>
      <td>NaN</td>
      <td>No, not at all</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>I have a concentration and/or memory disorder ...</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>160500.0</td>
      <td>Call a coworker or friend;Google it Stack Over...</td>
    </tr>
    <tr>
      <th>83435</th>
      <td>83436</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>BENIN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>4</td>
      <td>2</td>
      <td>Developer, full-stack</td>
      <td>Just me - I am a freelancer, sole proprietor, ...</td>
      <td>XOF\tWest African CFA franc</td>
      <td>200000.0</td>
      <td>Monthly</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Firebase;MariaDB;MySQL;PostgreSQL;Redis;SQLite</td>
      <td>Firebase;MariaDB;MongoDB;MySQL;PostgreSQL;Redi...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Django;jQuery;Laravel;React.js;Ruby on Rails</td>
      <td>Django;Express;jQuery;Laravel;React.js;Ruby on...</td>
      <td>...</td>
      <td>NaN</td>
      <td>Git;Unity 3D;Unreal Engine</td>
      <td>Docker;Git;Kubernetes</td>
      <td>Android Studio;Eclipse;Emacs;IntelliJ;NetBeans...</td>
      <td>Emacs;IntelliJ;PHPStorm;PyCharm;RStudio;Sublim...</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Multiple times per day</td>
      <td>True</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Black or of African descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>3960.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>83436</th>
      <td>83437</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>New Jersey</td>
      <td>NaN</td>
      <td>Secondary school (e.g. American high school, G...</td>
      <td>11 - 17 years</td>
      <td>School</td>
      <td>10</td>
      <td>4</td>
      <td>Data scientist or machine learning specialist;...</td>
      <td>10,000 or more employees</td>
      <td>USD\tUnited States dollar</td>
      <td>1800.0</td>
      <td>Weekly</td>
      <td>Groovy;Java;Python</td>
      <td>Java;Python</td>
      <td>DynamoDB;Elasticsearch;MongoDB;PostgreSQL;Redis</td>
      <td>DynamoDB;Redis</td>
      <td>AWS;Google Cloud Platform</td>
      <td>AWS</td>
      <td>FastAPI;Flask</td>
      <td>FastAPI;Flask</td>
      <td>...</td>
      <td>Apache Spark;Hadoop;Keras;NumPy;Pandas;TensorFlow</td>
      <td>Ansible;Docker;Git;Terraform</td>
      <td>Docker;Git;Kubernetes;Terraform</td>
      <td>Android Studio;Eclipse;IntelliJ;IPython/Jupyte...</td>
      <td>IntelliJ;IPython/Jupyter;Notepad++;Vim</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>True</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>No, not really</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>NaN</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>90000.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>83437</th>
      <td>83438</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>CANADA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Online Courses or Certification;Books / Physic...</td>
      <td>5</td>
      <td>3</td>
      <td>Developer, back-end</td>
      <td>20 to 99 employees</td>
      <td>CAD\tCanadian dollar</td>
      <td>90000.0</td>
      <td>Monthly</td>
      <td>Bash/Shell;JavaScript;Node.js;Python</td>
      <td>Go;Rust</td>
      <td>Cassandra;Elasticsearch;MongoDB;PostgreSQL;Redis</td>
      <td>NaN</td>
      <td>Heroku</td>
      <td>AWS;DigitalOcean</td>
      <td>Django;Express;Flask;React.js</td>
      <td>NaN</td>
      <td>...</td>
      <td>NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>Ansible;Docker;Git;Terraform</td>
      <td>Kubernetes;Terraform</td>
      <td>PyCharm;Sublime Text</td>
      <td>NaN</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>A few times per month or weekly</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>No, not really</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>I have a mood or emotional disorder (e.g. depr...</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>816816.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
  </tbody>
</table>
<p>83438 rows × 49 columns</p>
</div>




```python
import numpy as np
import pandas as pd
```


```python
pip install matplotlib
```

    Note: you may need to restart the kernel to use updated packages.Collecting matplotlib
    
      Downloading matplotlib-3.5.0-cp310-cp310-win_amd64.whl (7.2 MB)
    Collecting kiwisolver>=1.0.1
      Downloading kiwisolver-1.3.2-cp310-cp310-win_amd64.whl (52 kB)
    Requirement already satisfied: python-dateutil>=2.7 in d:\curso_python\codigo\cursopython2021\lib\site-packages (from matplotlib) (2.8.2)
    Requirement already satisfied: pyparsing>=2.2.1 in d:\curso_python\codigo\cursopython2021\lib\site-packages (from matplotlib) (3.0.6)
    Collecting cycler>=0.10
      Downloading cycler-0.11.0-py3-none-any.whl (6.4 kB)
    Collecting fonttools>=4.22.0
      Downloading fonttools-4.28.3-py3-none-any.whl (884 kB)
    Requirement already satisfied: numpy>=1.17 in d:\curso_python\codigo\cursopython2021\lib\site-packages (from matplotlib) (1.21.4)
    Requirement already satisfied: packaging>=20.0 in d:\curso_python\codigo\cursopython2021\lib\site-packages (from matplotlib) (21.3)
    Collecting pillow>=6.2.0
      Downloading Pillow-8.4.0-cp310-cp310-win_amd64.whl (3.2 MB)
    Collecting setuptools-scm>=4
      Downloading setuptools_scm-6.3.2-py3-none-any.whl (33 kB)
    Requirement already satisfied: six>=1.5 in d:\curso_python\codigo\cursopython2021\lib\site-packages (from python-dateutil>=2.7->matplotlib) (1.16.0)
    Requirement already satisfied: setuptools in d:\curso_python\codigo\cursopython2021\lib\site-packages (from setuptools-scm>=4->matplotlib) (58.3.0)
    Collecting tomli>=1.0.0
      Downloading tomli-1.2.2-py3-none-any.whl (12 kB)
    Installing collected packages: tomli, setuptools-scm, pillow, kiwisolver, fonttools, cycler, matplotlib
    Successfully installed cycler-0.11.0 fonttools-4.28.3 kiwisolver-1.3.2 matplotlib-3.5.0 pillow-8.4.0 setuptools-scm-6.3.2 tomli-1.2.2
    


```python
import matplotlib.pyplot as plt
```


```python
# Creamos la variable grafico
grafico = (datos.COUNTRY.value_counts())
```


```python
grafico.plot()
```




    <AxesSubplot:>




    
![png](output_83_1.png)
    



```python
datos.sort_values(by="COUNTRY")
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>RESPONSEID</th>
      <th>MAINBRANCH</th>
      <th>EMPLOYMENT</th>
      <th>COUNTRY</th>
      <th>USSTATE</th>
      <th>UKCOUNTRY</th>
      <th>EDLEVEL</th>
      <th>AGE1STCODE</th>
      <th>LEARNCODE</th>
      <th>YEARSCODE</th>
      <th>YEARSCODEPRO</th>
      <th>DEVTYPE</th>
      <th>ORGSIZE</th>
      <th>CURRENCY</th>
      <th>COMPTOTAL</th>
      <th>COMPFREQ</th>
      <th>LANGUAGEHAVEWORKEDWITH</th>
      <th>LANGUAGEWANTTOWORKWITH</th>
      <th>DATABASEHAVEWORKEDWITH</th>
      <th>DATABASEWANTTOWORKWITH</th>
      <th>PLATFORMHAVEWORKEDWITH</th>
      <th>PLATFORMWANTTOWORKWITH</th>
      <th>WEBFRAMEHAVEWORKEDWITH</th>
      <th>WEBFRAMEWANTTOWORKWITH</th>
      <th>...</th>
      <th>MISCTECHWANTTOWORKWITH</th>
      <th>TOOLSTECHHAVEWORKEDWITH</th>
      <th>TOOLSTECHWANTTOWORKWITH</th>
      <th>NEWCOLLABTOOLSHAVEWORKEDWITH</th>
      <th>NEWCOLLABTOOLSWANTTOWORKWITH</th>
      <th>OPSYS</th>
      <th>NEWSTUCK</th>
      <th>NEWSOSITES</th>
      <th>SOVISITFREQ</th>
      <th>SOACCOUNT</th>
      <th>SOPARTFREQ</th>
      <th>SOCOMM</th>
      <th>NEWOTHERCOMMS</th>
      <th>AGE</th>
      <th>GENDER</th>
      <th>TRANS</th>
      <th>SEXUALITY</th>
      <th>ETHNICITY</th>
      <th>ACCESSIBILITY</th>
      <th>MENTALHEALTH</th>
      <th>SURVEYLENGTH</th>
      <th>SURVEYEASE</th>
      <th>CONVERTEDCOMPYEARLY</th>
      <th>AYUDA</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>14882</th>
      <td>14883</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>AFGHANISTAN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>18 - 24 years</td>
      <td>Coding Bootcamp;Other online resources (ex: vi...</td>
      <td>8</td>
      <td>4</td>
      <td>Developer, front-end;Developer, full-stack;Dev...</td>
      <td>20 to 99 employees</td>
      <td>AFN\tAfghan afghani</td>
      <td>6500.0</td>
      <td>Weekly</td>
      <td>HTML/CSS;JavaScript;PHP;SQL</td>
      <td>HTML/CSS;JavaScript;Node.js;PHP;SQL</td>
      <td>Elasticsearch;Firebase;MongoDB;MySQL;Redis;SQLite</td>
      <td>Elasticsearch;Firebase;MariaDB;MySQL</td>
      <td>AWS;DigitalOcean;Heroku;IBM Cloud or Watson</td>
      <td>AWS;DigitalOcean;Heroku</td>
      <td>Angular;Angular.js;Drupal;jQuery;Laravel;React.js</td>
      <td>Angular;Angular.js;Drupal;jQuery;Laravel;React.js</td>
      <td>...</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>Docker;Git</td>
      <td>Atom;Eclipse;NetBeans;Notepad++;PHPStorm;Subli...</td>
      <td>Notepad++;Sublime Text;Visual Studio Code</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>A few times per month or weekly</td>
      <td>Yes, somewhat</td>
      <td>Yes</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>NaN</td>
      <td>South Asian</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>4200.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>41840</th>
      <td>41841</td>
      <td>None of these</td>
      <td>I prefer not to say</td>
      <td>AFGHANISTAN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Something else</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Linux-based</td>
      <td>Visit another developer community (please name):</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>No, not really</td>
      <td>Yes</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Too long</td>
      <td>Difficult</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4544</th>
      <td>4545</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>AFGHANISTAN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>18 - 24 years</td>
      <td>Coding Bootcamp</td>
      <td>4</td>
      <td>2</td>
      <td>Developer, mobile;Developer, front-end;Develop...</td>
      <td>20 to 99 employees</td>
      <td>CAD\tCanadian dollar</td>
      <td>NaN</td>
      <td>Monthly</td>
      <td>Dart;HTML/CSS;JavaScript;Python;TypeScript</td>
      <td>Dart;HTML/CSS;JavaScript;Node.js;Python;Rust;S...</td>
      <td>Oracle;PostgreSQL;SQLite</td>
      <td>Firebase;MongoDB;PostgreSQL;SQLite</td>
      <td>Google Cloud Platform;Heroku</td>
      <td>AWS;Google Cloud Platform;Heroku;Microsoft Azure</td>
      <td>Django;Flask;React.js</td>
      <td>Django;FastAPI;Flask;React.js</td>
      <td>...</td>
      <td>Flutter;Keras;NumPy;Pandas;TensorFlow;Torch/Py...</td>
      <td>Docker;Git;Yarn</td>
      <td>Deno;Docker;Git;Unity 3D;Yarn</td>
      <td>Android Studio;Sublime Text;Visual Studio Code</td>
      <td>Android Studio;Visual Studio Code;Xcode</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
      <td>Stack Overflow</td>
      <td>A few times per week</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Middle Eastern</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
    </tr>
    <tr>
      <th>28378</th>
      <td>28379</td>
      <td>None of these</td>
      <td>Not employed, and not looking for work</td>
      <td>AFGHANISTAN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Secondary school (e.g. American high school, G...</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc)</td>
      <td>3</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>HTML/CSS;JavaScript</td>
      <td>HTML/CSS;JavaScript</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>Unity 3D</td>
      <td>NaN</td>
      <td>Notepad++;Visual Studio Code</td>
      <td>NaN</td>
      <td>Windows</td>
      <td>Google it;Watch help / tutorial videos;Do othe...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Less than once per month or monthly</td>
      <td>False</td>
      <td>NaN</td>
      <td>No, not at all</td>
      <td>No</td>
      <td>Under 18 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Southeast Asian</td>
      <td>Or, in your own words:</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
      <td>Google it;Watch help / tutorial videos;Do othe...</td>
    </tr>
    <tr>
      <th>55624</th>
      <td>55625</td>
      <td>I code primarily as a hobby</td>
      <td>I prefer not to say</td>
      <td>AFGHANISTAN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Professional degree (JD, MD, etc.)</td>
      <td>5 - 10 years</td>
      <td>Other (please specify):</td>
      <td>4</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>APL;Assembly;Bash/Shell;C;C#;C++;Clojure;COBOL...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>React.js;Ruby on Rails</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Visual Studio;Visual Studio Code;Xcode</td>
      <td>NaN</td>
      <td>Windows</td>
      <td>Visit Stack Overflow</td>
      <td>Stack Overflow;Stack Exchange;Stack Overflow f...</td>
      <td>A few times per week</td>
      <td>True</td>
      <td>A few times per week</td>
      <td>Not sure</td>
      <td>No</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Too long</td>
      <td>Neither easy nor difficult</td>
      <td>NaN</td>
      <td>Visit Stack Overflow Stack Overflow;Stack Exch...</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>75693</th>
      <td>75694</td>
      <td>I am a student who is learning to code</td>
      <td>Student, full-time</td>
      <td>ZIMBABWE</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Secondary school (e.g. American high school, G...</td>
      <td>18 - 24 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>2</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Python</td>
      <td>HTML/CSS;JavaScript</td>
      <td>MySQL</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Django</td>
      <td>ASP.NET</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Android Studio;Visual Studio</td>
      <td>Visual Studio Code;Xcode</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per month or weekly</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>Yes, somewhat</td>
      <td>Yes</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Black or of African descent</td>
      <td>None of the above</td>
      <td>I have an anxiety disorder</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>NaN</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
    </tr>
    <tr>
      <th>73741</th>
      <td>73742</td>
      <td>I am a developer by profession</td>
      <td>Student, part-time</td>
      <td>ZIMBABWE</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Some college/university study without earning ...</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>5</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bash/Shell;C#;Go;HTML/CSS;JavaScript;PowerShel...</td>
      <td>NaN</td>
      <td>PostgreSQL;SQLite</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Angular;Django;jQuery;React.js</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>Git</td>
      <td>NaN</td>
      <td>Android Studio;IPython/Jupyter;Sublime Text;Vi...</td>
      <td>NaN</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>A few times per week</td>
      <td>True</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>Yes, definitely</td>
      <td>Yes</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Black or of African descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>NaN</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>44094</th>
      <td>44095</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>ZIMBABWE</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>25 - 34 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>7</td>
      <td>6</td>
      <td>Developer, mobile;Developer, back-end</td>
      <td>20 to 99 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>NaN</td>
      <td>Monthly</td>
      <td>Dart;Go;Java;Python;Scala</td>
      <td>Dart;Go;Java;Kotlin;Python</td>
      <td>MySQL;Redis</td>
      <td>Elasticsearch;MySQL;PostgreSQL;Redis</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Angular.js;Django;Spring</td>
      <td>React.js;Vue.js</td>
      <td>...</td>
      <td>Flutter</td>
      <td>Docker;Git</td>
      <td>Deno;Docker;Git;Kubernetes</td>
      <td>Android Studio;IntelliJ;Neovim;Vim;Visual Stud...</td>
      <td>IntelliJ;Neovim;Vim</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per month or weekly</td>
      <td>True</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>No, not really</td>
      <td>No</td>
      <td>NaN</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Black or of African descent</td>
      <td>Prefer not to say</td>
      <td>None of the above</td>
      <td>Too short</td>
      <td>Neither easy nor difficult</td>
      <td>NaN</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>13194</th>
      <td>13195</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>ZIMBABWE</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>18 - 24 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>18</td>
      <td>14</td>
      <td>Developer, back-end;Database administrator;Sys...</td>
      <td>2 to 9 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Rust</td>
      <td>Rust</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>Git</td>
      <td>Git</td>
      <td>Vim</td>
      <td>Vim</td>
      <td>Linux-based</td>
      <td>Visit Stack Overflow;Google it;Watch help / tu...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>True</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>Yes, somewhat</td>
      <td>Yes</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Black or of African descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Too long</td>
      <td>Easy</td>
      <td>NaN</td>
      <td>Visit Stack Overflow;Google it;Watch help / tu...</td>
    </tr>
    <tr>
      <th>54148</th>
      <td>54149</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>ZIMBABWE</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>18 - 24 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>13</td>
      <td>9</td>
      <td>Developer, front-end;Developer, desktop or ent...</td>
      <td>10 to 19 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>1461.0</td>
      <td>Monthly</td>
      <td>C#;HTML/CSS;JavaScript</td>
      <td>C#;HTML/CSS;JavaScript;Python;TypeScript</td>
      <td>Microsoft SQL Server</td>
      <td>Microsoft SQL Server;MongoDB;PostgreSQL</td>
      <td>Microsoft Azure</td>
      <td>AWS;Microsoft Azure</td>
      <td>ASP.NET;ASP.NET Core ;React.js</td>
      <td>ASP.NET Core ;React.js</td>
      <td>...</td>
      <td>.NET Core / .NET 5;Qt;React Native;TensorFlow;...</td>
      <td>Git</td>
      <td>Git;Kubernetes;Xamarin</td>
      <td>Visual Studio;Visual Studio Code</td>
      <td>Visual Studio;Visual Studio Code</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>True</td>
      <td>A few times per month or weekly</td>
      <td>Yes, somewhat</td>
      <td>Yes</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Black or of African descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>17532.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
  </tbody>
</table>
<p>83439 rows × 49 columns</p>
</div>




```python
datos.sort_values(by="COUNTRY", ascending=False)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>RESPONSEID</th>
      <th>MAINBRANCH</th>
      <th>EMPLOYMENT</th>
      <th>COUNTRY</th>
      <th>USSTATE</th>
      <th>UKCOUNTRY</th>
      <th>EDLEVEL</th>
      <th>AGE1STCODE</th>
      <th>LEARNCODE</th>
      <th>YEARSCODE</th>
      <th>YEARSCODEPRO</th>
      <th>DEVTYPE</th>
      <th>ORGSIZE</th>
      <th>CURRENCY</th>
      <th>COMPTOTAL</th>
      <th>COMPFREQ</th>
      <th>LANGUAGEHAVEWORKEDWITH</th>
      <th>LANGUAGEWANTTOWORKWITH</th>
      <th>DATABASEHAVEWORKEDWITH</th>
      <th>DATABASEWANTTOWORKWITH</th>
      <th>PLATFORMHAVEWORKEDWITH</th>
      <th>PLATFORMWANTTOWORKWITH</th>
      <th>WEBFRAMEHAVEWORKEDWITH</th>
      <th>WEBFRAMEWANTTOWORKWITH</th>
      <th>...</th>
      <th>MISCTECHWANTTOWORKWITH</th>
      <th>TOOLSTECHHAVEWORKEDWITH</th>
      <th>TOOLSTECHWANTTOWORKWITH</th>
      <th>NEWCOLLABTOOLSHAVEWORKEDWITH</th>
      <th>NEWCOLLABTOOLSWANTTOWORKWITH</th>
      <th>OPSYS</th>
      <th>NEWSTUCK</th>
      <th>NEWSOSITES</th>
      <th>SOVISITFREQ</th>
      <th>SOACCOUNT</th>
      <th>SOPARTFREQ</th>
      <th>SOCOMM</th>
      <th>NEWOTHERCOMMS</th>
      <th>AGE</th>
      <th>GENDER</th>
      <th>TRANS</th>
      <th>SEXUALITY</th>
      <th>ETHNICITY</th>
      <th>ACCESSIBILITY</th>
      <th>MENTALHEALTH</th>
      <th>SURVEYLENGTH</th>
      <th>SURVEYEASE</th>
      <th>CONVERTEDCOMPYEARLY</th>
      <th>AYUDA</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>71232</th>
      <td>71233</td>
      <td>I am a student who is learning to code</td>
      <td>Not employed, but looking for work</td>
      <td>ZIMBABWE</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>18 - 24 years</td>
      <td>School;Online Courses or Certification;Books /...</td>
      <td>4</td>
      <td>NaN</td>
      <td>Student</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>C;C++;Dart;HTML/CSS;Java;JavaScript;PHP;Python...</td>
      <td>NaN</td>
      <td>MySQL;SQLite</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>React.js</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Android Studio;Atom;Visual Studio Code</td>
      <td>NaN</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>True</td>
      <td>A few times per month or weekly</td>
      <td>Yes, definitely</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Black or of African descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Too long</td>
      <td>Neither easy nor difficult</td>
      <td>NaN</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>61695</th>
      <td>61696</td>
      <td>I am a developer by profession</td>
      <td>Employed part-time</td>
      <td>ZIMBABWE</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>8</td>
      <td>4</td>
      <td>Developer, mobile;Developer, front-end;Develop...</td>
      <td>2 to 9 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>4000.0</td>
      <td>Yearly</td>
      <td>C#;Java;JavaScript;Node.js</td>
      <td>NaN</td>
      <td>Firebase;Microsoft SQL Server;MongoDB</td>
      <td>NaN</td>
      <td>Google Cloud Platform</td>
      <td>AWS;DigitalOcean;Heroku;IBM Cloud or Watson;Mi...</td>
      <td>React.js</td>
      <td>ASP.NET;Drupal;Express;Laravel</td>
      <td>...</td>
      <td>NaN</td>
      <td>Git;Yarn</td>
      <td>Xamarin;Yarn</td>
      <td>Android Studio;Atom;Eclipse;Notepad++;Visual S...</td>
      <td>NaN</td>
      <td>MacOS</td>
      <td>Visit Stack Overflow;Google it;Visit another d...</td>
      <td>Stack Overflow;Stack Exchange;Stack Overflow f...</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>Yes, definitely</td>
      <td>Yes</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Black or of African descent</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Too long</td>
      <td>Neither easy nor difficult</td>
      <td>4000.0</td>
      <td>Visit Stack Overflow;Google it;Visit another d...</td>
    </tr>
    <tr>
      <th>59222</th>
      <td>59223</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>ZIMBABWE</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Something else</td>
      <td>5 - 10 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>10</td>
      <td>3</td>
      <td>Developer, mobile;Developer, desktop or enterp...</td>
      <td>2 to 9 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Dart;HTML/CSS;Python</td>
      <td>Dart;HTML/CSS;Python</td>
      <td>Firebase;MySQL;PostgreSQL;Redis</td>
      <td>MySQL;PostgreSQL;Redis</td>
      <td>Heroku</td>
      <td>Heroku</td>
      <td>Django</td>
      <td>Django</td>
      <td>...</td>
      <td>Flutter</td>
      <td>Git</td>
      <td>Docker;Git</td>
      <td>Android Studio;Atom;IntelliJ;IPython/Jupyter;P...</td>
      <td>Android Studio;Atom;IntelliJ;IPython/Jupyter;P...</td>
      <td>Linux-based</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Multiple times per day</td>
      <td>True</td>
      <td>A few times per week</td>
      <td>Yes, somewhat</td>
      <td>Yes</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Black or of African descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>NaN</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
    </tr>
    <tr>
      <th>13194</th>
      <td>13195</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>ZIMBABWE</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>18 - 24 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>18</td>
      <td>14</td>
      <td>Developer, back-end;Database administrator;Sys...</td>
      <td>2 to 9 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Rust</td>
      <td>Rust</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>Git</td>
      <td>Git</td>
      <td>Vim</td>
      <td>Vim</td>
      <td>Linux-based</td>
      <td>Visit Stack Overflow;Google it;Watch help / tu...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>True</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>Yes, somewhat</td>
      <td>Yes</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Black or of African descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Too long</td>
      <td>Easy</td>
      <td>NaN</td>
      <td>Visit Stack Overflow;Google it;Watch help / tu...</td>
    </tr>
    <tr>
      <th>13395</th>
      <td>13396</td>
      <td>I am a developer by profession</td>
      <td>Not employed, but looking for work</td>
      <td>ZIMBABWE</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>School</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Developer, mobile;Developer, front-end;Develop...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bash/Shell;Java;Rust;SQL;TypeScript</td>
      <td>Rust;SQL;TypeScript</td>
      <td>Firebase;MariaDB;MongoDB</td>
      <td>MariaDB</td>
      <td>AWS;IBM Cloud or Watson;Microsoft Azure</td>
      <td>NaN</td>
      <td>Laravel;React.js;Vue.js</td>
      <td>React.js</td>
      <td>...</td>
      <td>TensorFlow</td>
      <td>Yarn</td>
      <td>Yarn</td>
      <td>Android Studio;IntelliJ;Neovim;Vim;Visual Stud...</td>
      <td>Neovim;Visual Studio Code</td>
      <td>Linux-based</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per month or weekly</td>
      <td>True</td>
      <td>A few times per month or weekly</td>
      <td>Yes, somewhat</td>
      <td>Yes</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Black or of African descent</td>
      <td>None of the above</td>
      <td>I have a mood or emotional disorder (e.g. depr...</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>72314</th>
      <td>72315</td>
      <td>None of these</td>
      <td>Retired</td>
      <td>AFGHANISTAN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Primary/elementary school</td>
      <td>Older than 64 years</td>
      <td>Other (please specify):</td>
      <td>Less than 1 year</td>
      <td>Less than 1 year</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Assembly;Bash/Shell;C;COBOL;Erlang</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Vim</td>
      <td>NaN</td>
      <td>Other (please specify):</td>
      <td>Meditate;Panic;Visit another developer communi...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Multiple times per day</td>
      <td>True</td>
      <td>Multiple times per day</td>
      <td>Yes, definitely</td>
      <td>Yes</td>
      <td>65 years or older</td>
      <td>Or, in your own words:</td>
      <td>Yes</td>
      <td>Straight / Heterosexual;Bisexual;Prefer to sel...</td>
      <td>Multiracial;East Asian;Biracial;Or, in your ow...</td>
      <td>I am deaf / hard of hearing;I am blind / have ...</td>
      <td>I have a concentration and/or memory disorder ...</td>
      <td>Too short</td>
      <td>Easy</td>
      <td>NaN</td>
      <td>Meditate;Panic;Visit another developer communi...</td>
    </tr>
    <tr>
      <th>72548</th>
      <td>72549</td>
      <td>I am a developer by profession</td>
      <td>Employed part-time</td>
      <td>AFGHANISTAN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Primary/elementary school</td>
      <td>25 - 34 years</td>
      <td>Coding Bootcamp;Books / Physical media</td>
      <td>7</td>
      <td>5</td>
      <td>Academic researcher</td>
      <td>10 to 19 employees</td>
      <td>AUD\tAustralian dollar</td>
      <td>NaN</td>
      <td>Monthly</td>
      <td>C#;Clojure;Crystal</td>
      <td>NaN</td>
      <td>Couchbase;Elasticsearch;MariaDB;Microsoft SQL ...</td>
      <td>NaN</td>
      <td>AWS;Heroku;IBM Cloud or Watson;Microsoft Azure</td>
      <td>NaN</td>
      <td>ASP.NET;ASP.NET Core ;Django;FastAPI</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>Chef;Deno;Docker;Git;Pulumi</td>
      <td>NaN</td>
      <td>Emacs;IntelliJ;NetBeans;PHPStorm</td>
      <td>NaN</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per month or weekly</td>
      <td>True</td>
      <td>A few times per month or weekly</td>
      <td>Neutral</td>
      <td>Yes</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>Yes</td>
      <td>Bisexual;Gay or Lesbian</td>
      <td>White or of European descent;Middle Eastern</td>
      <td>I am deaf / hard of hearing;I am unable to / f...</td>
      <td>I have a mood or emotional disorder (e.g. depr...</td>
      <td>Too long</td>
      <td>Easy</td>
      <td>NaN</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>20301</th>
      <td>20302</td>
      <td>I am a developer by profession</td>
      <td>Student, part-time</td>
      <td>AFGHANISTAN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>18 - 24 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>2</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>HTML/CSS;JavaScript;PHP</td>
      <td>Java;JavaScript;PHP;TypeScript</td>
      <td>MySQL</td>
      <td>MongoDB;MySQL;PostgreSQL</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Laravel</td>
      <td>Laravel;Vue.js</td>
      <td>...</td>
      <td>NaN</td>
      <td>Git</td>
      <td>Git</td>
      <td>PHPStorm;Visual Studio Code</td>
      <td>Visual Studio Code</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per month or weekly</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>Yes, somewhat</td>
      <td>Yes</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Middle Eastern;East Asian</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Too long</td>
      <td>Easy</td>
      <td>NaN</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>67508</th>
      <td>67509</td>
      <td>I am a student who is learning to code</td>
      <td>I prefer not to say</td>
      <td>AFGHANISTAN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Primary/elementary school</td>
      <td>Younger than 5 years</td>
      <td>Books / Physical media</td>
      <td>Less than 1 year</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>APL</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Other (please specify):</td>
      <td>Panic</td>
      <td>I have never visited Stack Overflow or the Sta...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Yes</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>Yes</td>
      <td>Bisexual</td>
      <td>Indigenous (such as Native American, Pacific I...</td>
      <td>I am unable to / find it difficult to walk or ...</td>
      <td>I have autism / an autism spectrum disorder (e...</td>
      <td>Too long</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Panic I have never visited Stack Overflow or t...</td>
    </tr>
    <tr>
      <th>24552</th>
      <td>24553</td>
      <td>I am a student who is learning to code</td>
      <td>Student, part-time</td>
      <td>AFGHANISTAN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Some college/university study without earning ...</td>
      <td>18 - 24 years</td>
      <td>School</td>
      <td>3</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>C;HTML/CSS;Java;JavaScript;SQL</td>
      <td>HTML/CSS;JavaScript;Node.js;Python;SQL;TypeScript</td>
      <td>MySQL</td>
      <td>MySQL;Oracle</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Atom;PyCharm;Sublime Text;Visual Studio Code</td>
      <td>Android Studio;Sublime Text;Visual Studio Code...</td>
      <td>Linux-based</td>
      <td>Google it;Watch help / tutorial videos;Do othe...</td>
      <td>Stack Overflow</td>
      <td>A few times per month or weekly</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>Or, in your own words:</td>
      <td>Straight / Heterosexual</td>
      <td>I don't know</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>NaN</td>
      <td>Google it;Watch help / tutorial videos;Do othe...</td>
    </tr>
  </tbody>
</table>
<p>83439 rows × 49 columns</p>
</div>




```python
datos.sort_values(by=["COUNTRY", "CONVERTEDCOMPYEARLY"])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>RESPONSEID</th>
      <th>MAINBRANCH</th>
      <th>EMPLOYMENT</th>
      <th>COUNTRY</th>
      <th>USSTATE</th>
      <th>UKCOUNTRY</th>
      <th>EDLEVEL</th>
      <th>AGE1STCODE</th>
      <th>LEARNCODE</th>
      <th>YEARSCODE</th>
      <th>YEARSCODEPRO</th>
      <th>DEVTYPE</th>
      <th>ORGSIZE</th>
      <th>CURRENCY</th>
      <th>COMPTOTAL</th>
      <th>COMPFREQ</th>
      <th>LANGUAGEHAVEWORKEDWITH</th>
      <th>LANGUAGEWANTTOWORKWITH</th>
      <th>DATABASEHAVEWORKEDWITH</th>
      <th>DATABASEWANTTOWORKWITH</th>
      <th>PLATFORMHAVEWORKEDWITH</th>
      <th>PLATFORMWANTTOWORKWITH</th>
      <th>WEBFRAMEHAVEWORKEDWITH</th>
      <th>WEBFRAMEWANTTOWORKWITH</th>
      <th>...</th>
      <th>MISCTECHWANTTOWORKWITH</th>
      <th>TOOLSTECHHAVEWORKEDWITH</th>
      <th>TOOLSTECHWANTTOWORKWITH</th>
      <th>NEWCOLLABTOOLSHAVEWORKEDWITH</th>
      <th>NEWCOLLABTOOLSWANTTOWORKWITH</th>
      <th>OPSYS</th>
      <th>NEWSTUCK</th>
      <th>NEWSOSITES</th>
      <th>SOVISITFREQ</th>
      <th>SOACCOUNT</th>
      <th>SOPARTFREQ</th>
      <th>SOCOMM</th>
      <th>NEWOTHERCOMMS</th>
      <th>AGE</th>
      <th>GENDER</th>
      <th>TRANS</th>
      <th>SEXUALITY</th>
      <th>ETHNICITY</th>
      <th>ACCESSIBILITY</th>
      <th>MENTALHEALTH</th>
      <th>SURVEYLENGTH</th>
      <th>SURVEYEASE</th>
      <th>CONVERTEDCOMPYEARLY</th>
      <th>AYUDA</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>55150</th>
      <td>55151</td>
      <td>I am a developer by profession</td>
      <td>Retired</td>
      <td>AFGHANISTAN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Secondary school (e.g. American high school, G...</td>
      <td>Younger than 5 years</td>
      <td>Coding Bootcamp;Other online resources (ex: vi...</td>
      <td>Less than 1 year</td>
      <td>More than 50 years</td>
      <td>NaN</td>
      <td>10,000 or more employees</td>
      <td>AWG\tAruban florin</td>
      <td>3.0</td>
      <td>Weekly</td>
      <td>APL;Assembly;C;Delphi;Objective-C;PowerShell</td>
      <td>Assembly;Bash/Shell;Clojure;Java;JavaScript;Ob...</td>
      <td>DynamoDB</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Ruby on Rails;Spring</td>
      <td>Symfony;Vue.js</td>
      <td>...</td>
      <td>NaN</td>
      <td>Deno</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Stack Overflow for Teams (private knowledge sh...</td>
      <td>A few times per week</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>No, not at all</td>
      <td>No</td>
      <td>35-44 years old</td>
      <td>Man;Woman;Non-binary, genderqueer, or gender n...</td>
      <td>Or, in your own words:</td>
      <td>Straight / Heterosexual;Prefer to self-describe:</td>
      <td>Black or of African descent</td>
      <td>Or, in your own words:</td>
      <td>Or, in your own words:</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>100.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>17120</th>
      <td>17121</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>AFGHANISTAN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>18 - 24 years</td>
      <td>Online Courses or Certification;Colleague</td>
      <td>3</td>
      <td>1</td>
      <td>Developer, front-end;Developer, full-stack;Dev...</td>
      <td>100 to 499 employees</td>
      <td>AFN\tAfghan afghani</td>
      <td>20000.0</td>
      <td>Monthly</td>
      <td>HTML/CSS;JavaScript;Node.js;PHP;Python;SQL;Typ...</td>
      <td>HTML/CSS;JavaScript;Node.js;PHP;Python;SQL;Typ...</td>
      <td>MariaDB;MySQL</td>
      <td>MariaDB;MySQL;PostgreSQL</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Angular.js;jQuery;Laravel;React.js;Vue.js</td>
      <td>Django;jQuery;Laravel;React.js</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Android Studio;Atom;IntelliJ;IPython/Jupyter;V...</td>
      <td>Android Studio;Visual Studio;Visual Studio Code</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>A few times per week</td>
      <td>Yes, definitely</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Bisexual</td>
      <td>Middle Eastern</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Too long</td>
      <td>Neither easy nor difficult</td>
      <td>3108.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>14882</th>
      <td>14883</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>AFGHANISTAN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>18 - 24 years</td>
      <td>Coding Bootcamp;Other online resources (ex: vi...</td>
      <td>8</td>
      <td>4</td>
      <td>Developer, front-end;Developer, full-stack;Dev...</td>
      <td>20 to 99 employees</td>
      <td>AFN\tAfghan afghani</td>
      <td>6500.0</td>
      <td>Weekly</td>
      <td>HTML/CSS;JavaScript;PHP;SQL</td>
      <td>HTML/CSS;JavaScript;Node.js;PHP;SQL</td>
      <td>Elasticsearch;Firebase;MongoDB;MySQL;Redis;SQLite</td>
      <td>Elasticsearch;Firebase;MariaDB;MySQL</td>
      <td>AWS;DigitalOcean;Heroku;IBM Cloud or Watson</td>
      <td>AWS;DigitalOcean;Heroku</td>
      <td>Angular;Angular.js;Drupal;jQuery;Laravel;React.js</td>
      <td>Angular;Angular.js;Drupal;jQuery;Laravel;React.js</td>
      <td>...</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>Docker;Git</td>
      <td>Atom;Eclipse;NetBeans;Notepad++;PHPStorm;Subli...</td>
      <td>Notepad++;Sublime Text;Visual Studio Code</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>A few times per month or weekly</td>
      <td>Yes, somewhat</td>
      <td>Yes</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>NaN</td>
      <td>South Asian</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>4200.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>51428</th>
      <td>51429</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>AFGHANISTAN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>18 - 24 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>7</td>
      <td>3</td>
      <td>Developer, mobile;Developer, front-end;Develop...</td>
      <td>10 to 19 employees</td>
      <td>AFN\tAfghan afghani</td>
      <td>30000.0</td>
      <td>Monthly</td>
      <td>Java;JavaScript;Kotlin;Node.js;PHP;TypeScript</td>
      <td>Dart;JavaScript;Kotlin;Node.js;Python</td>
      <td>MySQL</td>
      <td>MongoDB;MySQL</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Angular;jQuery;Laravel</td>
      <td>Angular;Express;jQuery</td>
      <td>...</td>
      <td>Flutter;TensorFlow</td>
      <td>Git;Yarn</td>
      <td>Git;Yarn</td>
      <td>Android Studio;Eclipse;IntelliJ;Notepad++;Subl...</td>
      <td>Android Studio;IntelliJ;Notepad++;Sublime Text...</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Google it;Watch help / tu...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Multiple times per day</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>Yes, definitely</td>
      <td>Yes</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>East Asian</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Too short</td>
      <td>Easy</td>
      <td>4668.0</td>
      <td>Visit Stack Overflow;Google it;Watch help / tu...</td>
    </tr>
    <tr>
      <th>17486</th>
      <td>17487</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>AFGHANISTAN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>18 - 24 years</td>
      <td>Online Courses or Certification</td>
      <td>7</td>
      <td>3</td>
      <td>Developer, mobile;Developer, front-end;Develop...</td>
      <td>10 to 19 employees</td>
      <td>AFN\tAfghan afghani</td>
      <td>35000.0</td>
      <td>Monthly</td>
      <td>Java;JavaScript;Kotlin;PHP;SQL</td>
      <td>Dart;Java;JavaScript;Kotlin;Node.js;PHP;Python...</td>
      <td>MySQL</td>
      <td>MongoDB;MySQL</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Angular</td>
      <td>Angular;Laravel</td>
      <td>...</td>
      <td>Flutter</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Android Studio;Visual Studio Code</td>
      <td>Android Studio;Visual Studio Code</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Google it;Watch help / tu...</td>
      <td>Stack Overflow</td>
      <td>A few times per week</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>Yes, definitely</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>East Asian</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>5448.0</td>
      <td>Visit Stack Overflow;Google it;Watch help / tu...</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>75693</th>
      <td>75694</td>
      <td>I am a student who is learning to code</td>
      <td>Student, full-time</td>
      <td>ZIMBABWE</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Secondary school (e.g. American high school, G...</td>
      <td>18 - 24 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>2</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Python</td>
      <td>HTML/CSS;JavaScript</td>
      <td>MySQL</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Django</td>
      <td>ASP.NET</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Android Studio;Visual Studio</td>
      <td>Visual Studio Code;Xcode</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per month or weekly</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>Yes, somewhat</td>
      <td>Yes</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Black or of African descent</td>
      <td>None of the above</td>
      <td>I have an anxiety disorder</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>NaN</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
    </tr>
    <tr>
      <th>76082</th>
      <td>76083</td>
      <td>I am a developer by profession</td>
      <td>Not employed, but looking for work</td>
      <td>ZIMBABWE</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>18 - 24 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>3</td>
      <td>NaN</td>
      <td>Developer, full-stack</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>C++;Dart;Java;JavaScript;Python</td>
      <td>Dart;Python</td>
      <td>PostgreSQL;SQLite</td>
      <td>PostgreSQL;SQLite</td>
      <td>Heroku</td>
      <td>Heroku</td>
      <td>Django</td>
      <td>Django</td>
      <td>...</td>
      <td>Flutter</td>
      <td>Git</td>
      <td>Git</td>
      <td>IntelliJ;PyCharm;Visual Studio Code;Xcode</td>
      <td>IntelliJ;PyCharm;Visual Studio Code;Xcode</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>A few times per month or weekly</td>
      <td>Yes, definitely</td>
      <td>Yes</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Black or of African descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>79301</th>
      <td>79302</td>
      <td>I am a student who is learning to code</td>
      <td>Student, part-time</td>
      <td>ZIMBABWE</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Secondary school (e.g. American high school, G...</td>
      <td>35 - 44 years</td>
      <td>Other online resources (ex: videos, blogs, etc)</td>
      <td>1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>MySQL;PostgreSQL;SQLite</td>
      <td>MySQL;PostgreSQL;SQLite</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Django</td>
      <td>Django;React.js</td>
      <td>...</td>
      <td>NaN</td>
      <td>Git</td>
      <td>Ansible;Docker;Git</td>
      <td>Android Studio;PyCharm;Sublime Text;Visual Stu...</td>
      <td>Android Studio;PyCharm;Sublime Text;Visual Stu...</td>
      <td>Linux-based</td>
      <td>Visit Stack Overflow;Google it</td>
      <td>Stack Overflow</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>NaN</td>
      <td>Black or of African descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Too long</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Visit Stack Overflow;Google it Stack Overflow</td>
    </tr>
    <tr>
      <th>80996</th>
      <td>80997</td>
      <td>I code primarily as a hobby</td>
      <td>Not employed, and not looking for work</td>
      <td>ZIMBABWE</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Primary/elementary school</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>Less than 1 year</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>HTML/CSS;JavaScript;Node.js;Python</td>
      <td>Assembly;C#;C++;Go;Java;Kotlin;Node.js;Python</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>React.js</td>
      <td>Angular.js;Django;Express;jQuery</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Notepad++;PyCharm;Visual Studio Code</td>
      <td>Android Studio;PyCharm;Visual Studio Code</td>
      <td>Windows</td>
      <td>Watch help / tutorial videos;Do other work and...</td>
      <td>Stack Overflow</td>
      <td>A few times per month or weekly</td>
      <td>True</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>No, not really</td>
      <td>No</td>
      <td>Under 18 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Black or of African descent</td>
      <td>I am blind / have difficulty seeing</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
      <td>Watch help / tutorial videos;Do other work and...</td>
    </tr>
    <tr>
      <th>82406</th>
      <td>82407</td>
      <td>I am a student who is learning to code</td>
      <td>Employed part-time</td>
      <td>ZIMBABWE</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Some college/university study without earning ...</td>
      <td>18 - 24 years</td>
      <td>School;Books / Physical media</td>
      <td>3</td>
      <td>NaN</td>
      <td>Developer, front-end;Developer, back-end;Datab...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>C#;JavaScript;PHP;Python</td>
      <td>C#;Java;JavaScript;Kotlin;Matlab;Node.js;PHP;P...</td>
      <td>MySQL</td>
      <td>DynamoDB;MariaDB;MySQL;Oracle;SQLite</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>ASP.NET</td>
      <td>Angular.js;Django;jQuery</td>
      <td>...</td>
      <td>.NET Framework;Flutter;NumPy;Pandas;Torch/PyTorch</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>IPython/Jupyter;NetBeans;Notepad++;PyCharm;Sub...</td>
      <td>Android Studio;Atom;IPython/Jupyter;NetBeans;P...</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>Daily or almost daily</td>
      <td>Yes, definitely</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>Prefer not to say</td>
      <td>Straight / Heterosexual</td>
      <td>Black or of African descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>NaN</td>
      <td>Neither easy nor difficult</td>
      <td>NaN</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
  </tbody>
</table>
<p>83439 rows × 49 columns</p>
</div>




```python
# COUNTRY ascendente, CONVERTEDCOMPYEARLY descendente
datos.sort_values(by=["COUNTRY", "CONVERTEDCOMPYEARLY"], ascending=[True, False])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>RESPONSEID</th>
      <th>MAINBRANCH</th>
      <th>EMPLOYMENT</th>
      <th>COUNTRY</th>
      <th>USSTATE</th>
      <th>UKCOUNTRY</th>
      <th>EDLEVEL</th>
      <th>AGE1STCODE</th>
      <th>LEARNCODE</th>
      <th>YEARSCODE</th>
      <th>YEARSCODEPRO</th>
      <th>DEVTYPE</th>
      <th>ORGSIZE</th>
      <th>CURRENCY</th>
      <th>COMPTOTAL</th>
      <th>COMPFREQ</th>
      <th>LANGUAGEHAVEWORKEDWITH</th>
      <th>LANGUAGEWANTTOWORKWITH</th>
      <th>DATABASEHAVEWORKEDWITH</th>
      <th>DATABASEWANTTOWORKWITH</th>
      <th>PLATFORMHAVEWORKEDWITH</th>
      <th>PLATFORMWANTTOWORKWITH</th>
      <th>WEBFRAMEHAVEWORKEDWITH</th>
      <th>WEBFRAMEWANTTOWORKWITH</th>
      <th>...</th>
      <th>MISCTECHWANTTOWORKWITH</th>
      <th>TOOLSTECHHAVEWORKEDWITH</th>
      <th>TOOLSTECHWANTTOWORKWITH</th>
      <th>NEWCOLLABTOOLSHAVEWORKEDWITH</th>
      <th>NEWCOLLABTOOLSWANTTOWORKWITH</th>
      <th>OPSYS</th>
      <th>NEWSTUCK</th>
      <th>NEWSOSITES</th>
      <th>SOVISITFREQ</th>
      <th>SOACCOUNT</th>
      <th>SOPARTFREQ</th>
      <th>SOCOMM</th>
      <th>NEWOTHERCOMMS</th>
      <th>AGE</th>
      <th>GENDER</th>
      <th>TRANS</th>
      <th>SEXUALITY</th>
      <th>ETHNICITY</th>
      <th>ACCESSIBILITY</th>
      <th>MENTALHEALTH</th>
      <th>SURVEYLENGTH</th>
      <th>SURVEYEASE</th>
      <th>CONVERTEDCOMPYEARLY</th>
      <th>AYUDA</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>65399</th>
      <td>65400</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>AFGHANISTAN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>25 - 34 years</td>
      <td>Online Courses or Certification</td>
      <td>7</td>
      <td>3</td>
      <td>Developer, desktop or enterprise applications;...</td>
      <td>500 to 999 employees</td>
      <td>ANG Netherlands Antillean guilder</td>
      <td>4544242.0</td>
      <td>Monthly</td>
      <td>Bash/Shell;C++;Elixir;LISP;Node.js;Ruby;Rust;S...</td>
      <td>Clojure;Crystal;Dart;Matlab;Node.js;Python;R</td>
      <td>Couchbase;Elasticsearch;MariaDB</td>
      <td>MySQL;Oracle</td>
      <td>AWS;IBM Cloud or Watson</td>
      <td>Oracle Cloud Infrastructure</td>
      <td>ASP.NET;Drupal;Laravel;Svelte</td>
      <td>Angular;ASP.NET;Django;Express;Flask;jQuery;Ru...</td>
      <td>...</td>
      <td>Flutter;Pandas;Qt</td>
      <td>Docker;Flow;Terraform</td>
      <td>Chef;Docker;Git</td>
      <td>NetBeans;PHPStorm;RubyMine</td>
      <td>Eclipse;NetBeans</td>
      <td>Linux-based</td>
      <td>Watch help / tutorial videos;Play games</td>
      <td>Stack Overflow;Stack Overflow for Teams (priva...</td>
      <td>A few times per month or weekly</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>No, not at all</td>
      <td>Yes</td>
      <td>35-44 years old</td>
      <td>Man;Non-binary, genderqueer, or gender non-con...</td>
      <td>Yes</td>
      <td>Bisexual;Prefer to self-describe:;Gay or Lesbi...</td>
      <td>South Asian;Hispanic or Latino/a/x;Black or of...</td>
      <td>I am unable to / find it difficult to walk or ...</td>
      <td>I have a mood or emotional disorder (e.g. depr...</td>
      <td>Too short</td>
      <td>Difficult</td>
      <td>30468516.0</td>
      <td>Watch help / tutorial videos;Play games Stack ...</td>
    </tr>
    <tr>
      <th>22666</th>
      <td>22667</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>AFGHANISTAN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>45 - 54 years</td>
      <td>School</td>
      <td>5</td>
      <td>Less than 1 year</td>
      <td>System administrator</td>
      <td>Just me - I am a freelancer, sole proprietor, ...</td>
      <td>AFN\tAfghan afghani</td>
      <td>1000000.0</td>
      <td>Monthly</td>
      <td>Assembly;C#;C++;JavaScript;VBA</td>
      <td>HTML/CSS;Java;PHP;Python;R;SQL</td>
      <td>Microsoft SQL Server</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Windows</td>
      <td>Visit another developer community (please name):</td>
      <td>Stack Overflow;Stack Exchange;Stack Overflow f...</td>
      <td>Multiple times per day</td>
      <td>True</td>
      <td>Multiple times per day</td>
      <td>Yes, definitely</td>
      <td>Yes</td>
      <td>45-54 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>155496.0</td>
      <td>Visit another developer community (please name...</td>
    </tr>
    <tr>
      <th>27198</th>
      <td>27199</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>AFGHANISTAN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>5 - 10 years</td>
      <td>Online Courses or Certification</td>
      <td>3</td>
      <td>3</td>
      <td>Academic researcher;Student</td>
      <td>20 to 99 employees</td>
      <td>JPY\tJapanese yen</td>
      <td>480000.0</td>
      <td>Monthly</td>
      <td>Go;JavaScript;Python</td>
      <td>Go;JavaScript;Python</td>
      <td>MySQL</td>
      <td>MySQL</td>
      <td>Google Cloud Platform</td>
      <td>Google Cloud Platform</td>
      <td>Express;React.js</td>
      <td>Express;React.js</td>
      <td>...</td>
      <td>React Native</td>
      <td>Docker;Git;Pulumi</td>
      <td>Docker</td>
      <td>Visual Studio</td>
      <td>Visual Studio</td>
      <td>Linux-based</td>
      <td>Visit Stack Overflow</td>
      <td>Stack Exchange</td>
      <td>A few times per month or weekly</td>
      <td>False</td>
      <td>NaN</td>
      <td>No, not really</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>East Asian</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>Too long</td>
      <td>Difficult</td>
      <td>51804.0</td>
      <td>Visit Stack Overflow Stack Exchange</td>
    </tr>
    <tr>
      <th>31086</th>
      <td>31087</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>AFGHANISTAN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>16</td>
      <td>13</td>
      <td>Developer, mobile;Developer, front-end;Develop...</td>
      <td>500 to 999 employees</td>
      <td>AFN\tAfghan afghani</td>
      <td>154100.0</td>
      <td>Monthly</td>
      <td>HTML/CSS;JavaScript;Node.js;PHP;SQL;VBA</td>
      <td>HTML/CSS;JavaScript;Kotlin;Node.js;Objective-C...</td>
      <td>Firebase;MariaDB;MySQL;Redis;SQLite</td>
      <td>Couchbase;DynamoDB;Elasticsearch;Firebase;Mari...</td>
      <td>AWS;DigitalOcean</td>
      <td>Microsoft Azure</td>
      <td>Express;jQuery;Laravel;Vue.js</td>
      <td>jQuery;Laravel;React.js;Svelte;Vue.js</td>
      <td>...</td>
      <td>Flutter;React Native</td>
      <td>Docker;Git;Puppet;Yarn</td>
      <td>Docker;Git;Kubernetes;Terraform;Yarn</td>
      <td>Android Studio;NetBeans;Notepad++;Sublime Text...</td>
      <td>Android Studio;Sublime Text;Vim;Visual Studio ...</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per month or weekly</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Hispanic or Latino/a/x</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Too long</td>
      <td>Neither easy nor difficult</td>
      <td>23964.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>44640</th>
      <td>44641</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>AFGHANISTAN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Online Courses or Certification</td>
      <td>7</td>
      <td>6</td>
      <td>Developer, full-stack</td>
      <td>10 to 19 employees</td>
      <td>AFN\tAfghan afghani</td>
      <td>97333.0</td>
      <td>Monthly</td>
      <td>C#;HTML/CSS;JavaScript;PHP;SQL</td>
      <td>C#;Dart;HTML/CSS;JavaScript;PHP;Python;SQL</td>
      <td>MariaDB;Microsoft SQL Server;MySQL</td>
      <td>Firebase;MariaDB;Microsoft SQL Server;MongoDB;...</td>
      <td>AWS</td>
      <td>AWS;Google Cloud Platform;Microsoft Azure</td>
      <td>ASP.NET;ASP.NET Core ;jQuery;Laravel;Vue.js</td>
      <td>Angular;ASP.NET Core ;Django;jQuery;Laravel;Re...</td>
      <td>...</td>
      <td>.NET Core / .NET 5;Flutter;NumPy;Pandas;Qt;Ten...</td>
      <td>Git;Yarn</td>
      <td>Docker;Git;Xamarin;Yarn</td>
      <td>PHPStorm;Visual Studio;Visual Studio Code;Webs...</td>
      <td>Android Studio;PHPStorm;PyCharm;Rider;Visual S...</td>
      <td>MacOS</td>
      <td>Visit Stack Overflow;Google it;Meditate</td>
      <td>Stack Overflow</td>
      <td>A few times per week</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>Yes, definitely</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>East Asian</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Too long</td>
      <td>Neither easy nor difficult</td>
      <td>15132.0</td>
      <td>Visit Stack Overflow;Google it;Meditate Stack ...</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>75693</th>
      <td>75694</td>
      <td>I am a student who is learning to code</td>
      <td>Student, full-time</td>
      <td>ZIMBABWE</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Secondary school (e.g. American high school, G...</td>
      <td>18 - 24 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>2</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Python</td>
      <td>HTML/CSS;JavaScript</td>
      <td>MySQL</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Django</td>
      <td>ASP.NET</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Android Studio;Visual Studio</td>
      <td>Visual Studio Code;Xcode</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per month or weekly</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>Yes, somewhat</td>
      <td>Yes</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Black or of African descent</td>
      <td>None of the above</td>
      <td>I have an anxiety disorder</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>NaN</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
    </tr>
    <tr>
      <th>76082</th>
      <td>76083</td>
      <td>I am a developer by profession</td>
      <td>Not employed, but looking for work</td>
      <td>ZIMBABWE</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>18 - 24 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>3</td>
      <td>NaN</td>
      <td>Developer, full-stack</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>C++;Dart;Java;JavaScript;Python</td>
      <td>Dart;Python</td>
      <td>PostgreSQL;SQLite</td>
      <td>PostgreSQL;SQLite</td>
      <td>Heroku</td>
      <td>Heroku</td>
      <td>Django</td>
      <td>Django</td>
      <td>...</td>
      <td>Flutter</td>
      <td>Git</td>
      <td>Git</td>
      <td>IntelliJ;PyCharm;Visual Studio Code;Xcode</td>
      <td>IntelliJ;PyCharm;Visual Studio Code;Xcode</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>A few times per month or weekly</td>
      <td>Yes, definitely</td>
      <td>Yes</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Black or of African descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>79301</th>
      <td>79302</td>
      <td>I am a student who is learning to code</td>
      <td>Student, part-time</td>
      <td>ZIMBABWE</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Secondary school (e.g. American high school, G...</td>
      <td>35 - 44 years</td>
      <td>Other online resources (ex: videos, blogs, etc)</td>
      <td>1</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>MySQL;PostgreSQL;SQLite</td>
      <td>MySQL;PostgreSQL;SQLite</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Django</td>
      <td>Django;React.js</td>
      <td>...</td>
      <td>NaN</td>
      <td>Git</td>
      <td>Ansible;Docker;Git</td>
      <td>Android Studio;PyCharm;Sublime Text;Visual Stu...</td>
      <td>Android Studio;PyCharm;Sublime Text;Visual Stu...</td>
      <td>Linux-based</td>
      <td>Visit Stack Overflow;Google it</td>
      <td>Stack Overflow</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>NaN</td>
      <td>Black or of African descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Too long</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Visit Stack Overflow;Google it Stack Overflow</td>
    </tr>
    <tr>
      <th>80996</th>
      <td>80997</td>
      <td>I code primarily as a hobby</td>
      <td>Not employed, and not looking for work</td>
      <td>ZIMBABWE</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Primary/elementary school</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>Less than 1 year</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>HTML/CSS;JavaScript;Node.js;Python</td>
      <td>Assembly;C#;C++;Go;Java;Kotlin;Node.js;Python</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>React.js</td>
      <td>Angular.js;Django;Express;jQuery</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Notepad++;PyCharm;Visual Studio Code</td>
      <td>Android Studio;PyCharm;Visual Studio Code</td>
      <td>Windows</td>
      <td>Watch help / tutorial videos;Do other work and...</td>
      <td>Stack Overflow</td>
      <td>A few times per month or weekly</td>
      <td>True</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>No, not really</td>
      <td>No</td>
      <td>Under 18 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Black or of African descent</td>
      <td>I am blind / have difficulty seeing</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
      <td>Watch help / tutorial videos;Do other work and...</td>
    </tr>
    <tr>
      <th>82406</th>
      <td>82407</td>
      <td>I am a student who is learning to code</td>
      <td>Employed part-time</td>
      <td>ZIMBABWE</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Some college/university study without earning ...</td>
      <td>18 - 24 years</td>
      <td>School;Books / Physical media</td>
      <td>3</td>
      <td>NaN</td>
      <td>Developer, front-end;Developer, back-end;Datab...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>C#;JavaScript;PHP;Python</td>
      <td>C#;Java;JavaScript;Kotlin;Matlab;Node.js;PHP;P...</td>
      <td>MySQL</td>
      <td>DynamoDB;MariaDB;MySQL;Oracle;SQLite</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>ASP.NET</td>
      <td>Angular.js;Django;jQuery</td>
      <td>...</td>
      <td>.NET Framework;Flutter;NumPy;Pandas;Torch/PyTorch</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>IPython/Jupyter;NetBeans;Notepad++;PyCharm;Sub...</td>
      <td>Android Studio;Atom;IPython/Jupyter;NetBeans;P...</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>Daily or almost daily</td>
      <td>Yes, definitely</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>Prefer not to say</td>
      <td>Straight / Heterosexual</td>
      <td>Black or of African descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>NaN</td>
      <td>Neither easy nor difficult</td>
      <td>NaN</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
  </tbody>
</table>
<p>83439 rows × 49 columns</p>
</div>




```python
# Modifica datos
# datos.sort_values(by=["COUNTRY", "CONVERTEDCOMPYEARLY"], ascending=[True, False], inplace=True)
# Reestablece el orden original
# datos.sort_index()
```


```python
# Ordena una columna
datos["COUNTRY"].sort_values()
```




    14882    AFGHANISTAN
    41840    AFGHANISTAN
    4544     AFGHANISTAN
    28378    AFGHANISTAN
    55624    AFGHANISTAN
                ...     
    75693       ZIMBABWE
    73741       ZIMBABWE
    44094       ZIMBABWE
    13194       ZIMBABWE
    54148       ZIMBABWE
    Name: COUNTRY, Length: 83439, dtype: object




```python
datos["COUNTRY"].head(20)
```




    0                                              SLOVAKIA
    1                                           NETHERLANDS
    2                                    RUSSIAN FEDERATION
    3                                               AUSTRIA
    4     UNITED KINGDOM OF GREAT BRITAIN AND NORTHERN I...
    5                              UNITED STATES OF AMERICA
    6                              UNITED STATES OF AMERICA
    7                                              MALAYSIA
    8                                                 INDIA
    9                                                SWEDEN
    10    UNITED KINGDOM OF GREAT BRITAIN AND NORTHERN I...
    11                                               ESPAÑA
    12                                              GERMANY
    13                                                 PERU
    14    UNITED KINGDOM OF GREAT BRITAIN AND NORTHERN I...
    15                             UNITED STATES OF AMERICA
    16                                               TURKEY
    17                                               CANADA
    18                                            SINGAPORE
    19                                               BRAZIL
    Name: COUNTRY, dtype: object




```python
datos.sort_values(by=["CONVERTEDCOMPYEARLY", "COUNTRY"], ascending=[False, True]).head(50)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>RESPONSEID</th>
      <th>MAINBRANCH</th>
      <th>EMPLOYMENT</th>
      <th>COUNTRY</th>
      <th>USSTATE</th>
      <th>UKCOUNTRY</th>
      <th>EDLEVEL</th>
      <th>AGE1STCODE</th>
      <th>LEARNCODE</th>
      <th>YEARSCODE</th>
      <th>YEARSCODEPRO</th>
      <th>DEVTYPE</th>
      <th>ORGSIZE</th>
      <th>CURRENCY</th>
      <th>COMPTOTAL</th>
      <th>COMPFREQ</th>
      <th>LANGUAGEHAVEWORKEDWITH</th>
      <th>LANGUAGEWANTTOWORKWITH</th>
      <th>DATABASEHAVEWORKEDWITH</th>
      <th>DATABASEWANTTOWORKWITH</th>
      <th>PLATFORMHAVEWORKEDWITH</th>
      <th>PLATFORMWANTTOWORKWITH</th>
      <th>WEBFRAMEHAVEWORKEDWITH</th>
      <th>WEBFRAMEWANTTOWORKWITH</th>
      <th>...</th>
      <th>MISCTECHWANTTOWORKWITH</th>
      <th>TOOLSTECHHAVEWORKEDWITH</th>
      <th>TOOLSTECHWANTTOWORKWITH</th>
      <th>NEWCOLLABTOOLSHAVEWORKEDWITH</th>
      <th>NEWCOLLABTOOLSWANTTOWORKWITH</th>
      <th>OPSYS</th>
      <th>NEWSTUCK</th>
      <th>NEWSOSITES</th>
      <th>SOVISITFREQ</th>
      <th>SOACCOUNT</th>
      <th>SOPARTFREQ</th>
      <th>SOCOMM</th>
      <th>NEWOTHERCOMMS</th>
      <th>AGE</th>
      <th>GENDER</th>
      <th>TRANS</th>
      <th>SEXUALITY</th>
      <th>ETHNICITY</th>
      <th>ACCESSIBILITY</th>
      <th>MENTALHEALTH</th>
      <th>SURVEYLENGTH</th>
      <th>SURVEYEASE</th>
      <th>CONVERTEDCOMPYEARLY</th>
      <th>AYUDA</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>66910</th>
      <td>66911</td>
      <td>I am a developer by profession</td>
      <td>I prefer not to say</td>
      <td>BELGIUM</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Primary/elementary school</td>
      <td>55 - 64 years</td>
      <td>Books / Physical media</td>
      <td>1</td>
      <td>21</td>
      <td>NaN</td>
      <td>Just me - I am a freelancer, sole proprietor, ...</td>
      <td>ALL\tAlbanian lek</td>
      <td>5.123468e+09</td>
      <td>Yearly</td>
      <td>APL</td>
      <td>NaN</td>
      <td>Couchbase</td>
      <td>NaN</td>
      <td>AWS</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>IntelliJ;PyCharm</td>
      <td>NaN</td>
      <td>Other (please specify):</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
      <td>Stack Overflow for Teams (private knowledge sh...</td>
      <td>Less than once per month or monthly</td>
      <td>True</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>No, not at all</td>
      <td>Yes</td>
      <td>55-64 years old</td>
      <td>NaN</td>
      <td>Yes</td>
      <td>NaN</td>
      <td>Black or of African descent</td>
      <td>I am blind / have difficulty seeing</td>
      <td>I have a concentration and/or memory disorder ...</td>
      <td>Too short</td>
      <td>NaN</td>
      <td>45241312.0</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
    </tr>
    <tr>
      <th>65399</th>
      <td>65400</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>AFGHANISTAN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>25 - 34 years</td>
      <td>Online Courses or Certification</td>
      <td>7</td>
      <td>3</td>
      <td>Developer, desktop or enterprise applications;...</td>
      <td>500 to 999 employees</td>
      <td>ANG Netherlands Antillean guilder</td>
      <td>4.544242e+06</td>
      <td>Monthly</td>
      <td>Bash/Shell;C++;Elixir;LISP;Node.js;Ruby;Rust;S...</td>
      <td>Clojure;Crystal;Dart;Matlab;Node.js;Python;R</td>
      <td>Couchbase;Elasticsearch;MariaDB</td>
      <td>MySQL;Oracle</td>
      <td>AWS;IBM Cloud or Watson</td>
      <td>Oracle Cloud Infrastructure</td>
      <td>ASP.NET;Drupal;Laravel;Svelte</td>
      <td>Angular;ASP.NET;Django;Express;Flask;jQuery;Ru...</td>
      <td>...</td>
      <td>Flutter;Pandas;Qt</td>
      <td>Docker;Flow;Terraform</td>
      <td>Chef;Docker;Git</td>
      <td>NetBeans;PHPStorm;RubyMine</td>
      <td>Eclipse;NetBeans</td>
      <td>Linux-based</td>
      <td>Watch help / tutorial videos;Play games</td>
      <td>Stack Overflow;Stack Overflow for Teams (priva...</td>
      <td>A few times per month or weekly</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>No, not at all</td>
      <td>Yes</td>
      <td>35-44 years old</td>
      <td>Man;Non-binary, genderqueer, or gender non-con...</td>
      <td>Yes</td>
      <td>Bisexual;Prefer to self-describe:;Gay or Lesbi...</td>
      <td>South Asian;Hispanic or Latino/a/x;Black or of...</td>
      <td>I am unable to / find it difficult to walk or ...</td>
      <td>I have a mood or emotional disorder (e.g. depr...</td>
      <td>Too short</td>
      <td>Difficult</td>
      <td>30468516.0</td>
      <td>Watch help / tutorial videos;Play games Stack ...</td>
    </tr>
    <tr>
      <th>40586</th>
      <td>40587</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>California</td>
      <td>NaN</td>
      <td>Some college/university study without earning ...</td>
      <td>Younger than 5 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>37</td>
      <td>13</td>
      <td>Other (please specify):</td>
      <td>10,000 or more employees</td>
      <td>USD\tUnited States dollar</td>
      <td>4.364450e+05</td>
      <td>Weekly</td>
      <td>Bash/Shell;HTML/CSS;Java;JavaScript;Node.js;Py...</td>
      <td>Bash/Shell;Haskell;HTML/CSS;Java;JavaScript;No...</td>
      <td>MariaDB;MySQL;SQLite</td>
      <td>MariaDB;MySQL;SQLite</td>
      <td>Microsoft Azure</td>
      <td>Microsoft Azure</td>
      <td>Flask</td>
      <td>Express;Flask;React.js;Svelte</td>
      <td>...</td>
      <td>NaN</td>
      <td>Git</td>
      <td>Docker;Git</td>
      <td>IntelliJ;Visual Studio Code</td>
      <td>IntelliJ;Visual Studio;Visual Studio Code</td>
      <td>MacOS</td>
      <td>Visit Stack Overflow;Google it;Do other work a...</td>
      <td>Stack Overflow;Stack Exchange;Stack Overflow f...</td>
      <td>Multiple times per day</td>
      <td>True</td>
      <td>Daily or almost daily</td>
      <td>Yes, somewhat</td>
      <td>Yes</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Bisexual</td>
      <td>White or of European descent</td>
      <td>I am blind / have difficulty seeing</td>
      <td>I have a concentration and/or memory disorder ...</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>21822250.0</td>
      <td>Visit Stack Overflow;Google it;Do other work a...</td>
    </tr>
    <tr>
      <th>28791</th>
      <td>28792</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>INDIA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>35 - 44 years</td>
      <td>Coding Bootcamp;Other online resources (ex: vi...</td>
      <td>11</td>
      <td>9</td>
      <td>Developer, desktop or enterprise applications;...</td>
      <td>100 to 499 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>2.000000e+07</td>
      <td>Yearly</td>
      <td>C#;C++;Groovy;HTML/CSS;Java;JavaScript;Node.js...</td>
      <td>Ruby;Swift</td>
      <td>Microsoft SQL Server;MySQL;Oracle;PostgreSQL;S...</td>
      <td>MongoDB</td>
      <td>AWS;DigitalOcean;Heroku</td>
      <td>IBM Cloud or Watson;Microsoft Azure</td>
      <td>Angular.js;Drupal;Laravel;Ruby on Rails;Symfony</td>
      <td>Angular;ASP.NET</td>
      <td>...</td>
      <td>.NET Framework</td>
      <td>Git</td>
      <td>Chef;Docker;Kubernetes;Puppet</td>
      <td>Android Studio;Atom;Eclipse;IPython/Jupyter;Ne...</td>
      <td>Visual Studio Code</td>
      <td>MacOS</td>
      <td>Visit Stack Overflow;Google it;Visit another d...</td>
      <td>Stack Overflow;Stack Exchange;Stack Overflow f...</td>
      <td>A few times per month or weekly</td>
      <td>True</td>
      <td>A few times per month or weekly</td>
      <td>Neutral</td>
      <td>Yes</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>20000000.0</td>
      <td>Visit Stack Overflow;Google it;Visit another d...</td>
    </tr>
    <tr>
      <th>12700</th>
      <td>12701</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>INDIA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>25 - 34 years</td>
      <td>Online Forum</td>
      <td>5</td>
      <td>5</td>
      <td>Developer, full-stack</td>
      <td>100 to 499 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>1.600000e+06</td>
      <td>Monthly</td>
      <td>JavaScript</td>
      <td>JavaScript</td>
      <td>MongoDB;MySQL;PostgreSQL</td>
      <td>MongoDB;MySQL;PostgreSQL</td>
      <td>AWS;Heroku</td>
      <td>AWS;Heroku</td>
      <td>React.js</td>
      <td>React.js</td>
      <td>...</td>
      <td>NaN</td>
      <td>Git</td>
      <td>Git</td>
      <td>Eclipse;Visual Studio Code</td>
      <td>Eclipse;Visual Studio Code</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Google it;Visit another d...</td>
      <td>Stack Exchange</td>
      <td>A few times per week</td>
      <td>True</td>
      <td>A few times per week</td>
      <td>Neutral</td>
      <td>Yes</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>South Asian</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>19200000.0</td>
      <td>Visit Stack Overflow;Google it;Visit another d...</td>
    </tr>
    <tr>
      <th>9608</th>
      <td>9609</td>
      <td>I am not primarily a developer, but I write co...</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>New York</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>18 - 24 years</td>
      <td>School</td>
      <td>25</td>
      <td>21</td>
      <td>Senior Executive (C-Suite, VP, etc.)</td>
      <td>20 to 99 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>3.500000e+05</td>
      <td>Weekly</td>
      <td>Bash/Shell;Go;HTML/CSS;Java;JavaScript;Kotlin;...</td>
      <td>NaN</td>
      <td>Elasticsearch;IBM DB2;MariaDB;MongoDB;MySQL;Or...</td>
      <td>NaN</td>
      <td>AWS;DigitalOcean</td>
      <td>NaN</td>
      <td>Angular;jQuery;Spring</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>Git;Kubernetes</td>
      <td>NaN</td>
      <td>Android Studio;IntelliJ;Notepad++;PHPStorm;Vim...</td>
      <td>NaN</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Google it</td>
      <td>Stack Overflow</td>
      <td>Less than once per month or monthly</td>
      <td>False</td>
      <td>NaN</td>
      <td>Neutral</td>
      <td>Yes</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>17500000.0</td>
      <td>Call a coworker or friend;Google it Stack Over...</td>
    </tr>
    <tr>
      <th>5305</th>
      <td>5306</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>New Jersey</td>
      <td>NaN</td>
      <td>Professional degree (JD, MD, etc.)</td>
      <td>11 - 17 years</td>
      <td>Friend or family member;Books / Physical media</td>
      <td>25</td>
      <td>5</td>
      <td>Developer, full-stack;DevOps specialist</td>
      <td>Just me - I am a freelancer, sole proprietor, ...</td>
      <td>USD\tUnited States dollar</td>
      <td>3.000000e+05</td>
      <td>Weekly</td>
      <td>Python</td>
      <td>Python;Rust;SQL</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>AWS;Google Cloud Platform</td>
      <td>NaN</td>
      <td>Flask</td>
      <td>Django</td>
      <td>...</td>
      <td>NaN</td>
      <td>Ansible;Docker;Git;Terraform</td>
      <td>Docker;Git</td>
      <td>Vim</td>
      <td>Vim</td>
      <td>Linux-based</td>
      <td>Other (please specify):</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>Yes, somewhat</td>
      <td>Yes</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>NaN</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Too long</td>
      <td>Easy</td>
      <td>15000000.0</td>
      <td>Other (please specify): Stack Overflow;Stack E...</td>
    </tr>
    <tr>
      <th>12903</th>
      <td>12904</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>SERBIA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>6</td>
      <td>1</td>
      <td>Developer, front-end;Developer, full-stack;Dev...</td>
      <td>100 to 499 employees</td>
      <td>EUR European Euro</td>
      <td>1.111000e+06</td>
      <td>Monthly</td>
      <td>C#;JavaScript;Node.js;Python</td>
      <td>C#;Python</td>
      <td>MySQL;PostgreSQL</td>
      <td>MySQL;PostgreSQL</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Angular;ASP.NET;ASP.NET Core ;Django;jQuery;Re...</td>
      <td>Angular;ASP.NET Core ;Django;React.js</td>
      <td>...</td>
      <td>.NET Core / .NET 5</td>
      <td>Docker;Git</td>
      <td>Docker;Git</td>
      <td>PyCharm;Visual Studio;Visual Studio Code</td>
      <td>PyCharm;Visual Studio;Visual Studio Code</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Google it;Watch help / tu...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>False</td>
      <td>NaN</td>
      <td>Neutral</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Too long</td>
      <td>Neither easy nor difficult</td>
      <td>14411628.0</td>
      <td>Visit Stack Overflow;Google it;Watch help / tu...</td>
    </tr>
    <tr>
      <th>66488</th>
      <td>66489</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>Washington</td>
      <td>NaN</td>
      <td>Some college/university study without earning ...</td>
      <td>18 - 24 years</td>
      <td>School;Online Courses or Certification;Books /...</td>
      <td>5</td>
      <td>3</td>
      <td>Developer, desktop or enterprise applications;...</td>
      <td>20 to 99 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>2.550000e+05</td>
      <td>Weekly</td>
      <td>Bash/Shell;Go;HTML/CSS;Java;JavaScript;Kotlin;...</td>
      <td>Node.js;SQL;TypeScript</td>
      <td>DynamoDB;Elasticsearch;Firebase;MySQL;PostgreS...</td>
      <td>DynamoDB;Redis</td>
      <td>AWS;Google Cloud Platform</td>
      <td>AWS</td>
      <td>Express;React.js;Spring</td>
      <td>Express;React.js</td>
      <td>...</td>
      <td>NumPy;Pandas</td>
      <td>Docker;Git;Yarn</td>
      <td>Git</td>
      <td>Atom;IntelliJ;PyCharm;Sublime Text;Visual Stud...</td>
      <td>Visual Studio Code</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Google it;Meditate</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>No, not really</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>12750000.0</td>
      <td>Call a coworker or friend;Google it;Meditate S...</td>
    </tr>
    <tr>
      <th>7205</th>
      <td>7206</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>South Carolina</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>5 - 10 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>30</td>
      <td>20</td>
      <td>Developer, front-end;Developer, desktop or ent...</td>
      <td>Just me - I am a freelancer, sole proprietor, ...</td>
      <td>USD\tUnited States dollar</td>
      <td>2.500000e+05</td>
      <td>Weekly</td>
      <td>Bash/Shell;C#;HTML/CSS;JavaScript;PHP;PowerShe...</td>
      <td>Bash/Shell;C#;HTML/CSS;JavaScript;SQL</td>
      <td>Microsoft SQL Server;MySQL;Oracle</td>
      <td>Microsoft SQL Server;PostgreSQL</td>
      <td>Microsoft Azure</td>
      <td>Microsoft Azure</td>
      <td>ASP.NET;ASP.NET Core ;jQuery</td>
      <td>Angular;ASP.NET;ASP.NET Core ;jQuery</td>
      <td>...</td>
      <td>.NET Framework;.NET Core / .NET 5</td>
      <td>Git</td>
      <td>NaN</td>
      <td>Notepad++;Visual Studio</td>
      <td>Notepad++;Visual Studio;Visual Studio Code</td>
      <td>Windows</td>
      <td>Go for a walk or other physical activity;Googl...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per month or weekly</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>Yes, somewhat</td>
      <td>Yes</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>12500000.0</td>
      <td>Go for a walk or other physical activity;Googl...</td>
    </tr>
    <tr>
      <th>47563</th>
      <td>47564</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>Colorado</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Books / Physical media</td>
      <td>24</td>
      <td>13</td>
      <td>Developer, front-end</td>
      <td>10,000 or more employees</td>
      <td>USD\tUnited States dollar</td>
      <td>2.500000e+05</td>
      <td>Weekly</td>
      <td>Go;HTML/CSS;JavaScript;Python;TypeScript</td>
      <td>HTML/CSS;JavaScript;Python;Rust;TypeScript</td>
      <td>PostgreSQL</td>
      <td>PostgreSQL</td>
      <td>AWS</td>
      <td>NaN</td>
      <td>React.js;Vue.js</td>
      <td>React.js;Vue.js</td>
      <td>...</td>
      <td>NaN</td>
      <td>Docker;Git;Kubernetes;Yarn</td>
      <td>Git;Yarn</td>
      <td>Visual Studio Code</td>
      <td>Visual Studio Code</td>
      <td>MacOS</td>
      <td>Go for a walk or other physical activity;Googl...</td>
      <td>Stack Overflow</td>
      <td>A few times per month or weekly</td>
      <td>True</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>Neutral</td>
      <td>No</td>
      <td>35-44 years old</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>None of the above</td>
      <td>I have an anxiety disorder</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>12500000.0</td>
      <td>Go for a walk or other physical activity;Googl...</td>
    </tr>
    <tr>
      <th>3733</th>
      <td>3734</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>Virginia</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Friend or family member</td>
      <td>28</td>
      <td>19</td>
      <td>Developer, back-end</td>
      <td>Just me - I am a freelancer, sole proprietor, ...</td>
      <td>USD\tUnited States dollar</td>
      <td>2.250000e+05</td>
      <td>Weekly</td>
      <td>Bash/Shell;Groovy;HTML/CSS;Java;JavaScript;Nod...</td>
      <td>Bash/Shell;Groovy;HTML/CSS;Java;JavaScript;Nod...</td>
      <td>MariaDB;MongoDB;Oracle</td>
      <td>MariaDB;MongoDB;PostgreSQL</td>
      <td>AWS</td>
      <td>AWS</td>
      <td>Spring</td>
      <td>React.js;Spring;Vue.js</td>
      <td>...</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>Docker;Git</td>
      <td>Eclipse;IntelliJ;Visual Studio Code</td>
      <td>IntelliJ</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>No, not really</td>
      <td>No</td>
      <td>35-44 years old</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>11250000.0</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
    </tr>
    <tr>
      <th>33255</th>
      <td>33256</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>Florida</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>School;Other (please specify):;Books / Physica...</td>
      <td>37</td>
      <td>33</td>
      <td>Developer, mobile;Developer, front-end;Develop...</td>
      <td>100 to 499 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>2.250000e+05</td>
      <td>Weekly</td>
      <td>Bash/Shell;C;C#;C++;Go;HTML/CSS;Java;JavaScrip...</td>
      <td>Bash/Shell;C;Go;HTML/CSS;Kotlin;Node.js;TypeSc...</td>
      <td>DynamoDB;Elasticsearch;Firebase;Microsoft SQL ...</td>
      <td>Elasticsearch;Microsoft SQL Server;Redis</td>
      <td>AWS;DigitalOcean;Google Cloud Platform;Microso...</td>
      <td>AWS;DigitalOcean;Microsoft Azure</td>
      <td>ASP.NET;ASP.NET Core ;Express;jQuery;Spring;Vu...</td>
      <td>Express;jQuery;Svelte;Vue.js</td>
      <td>...</td>
      <td>NaN</td>
      <td>Docker;Git;Kubernetes;Yarn</td>
      <td>Docker;Git;Kubernetes;Yarn</td>
      <td>Eclipse;IntelliJ;Notepad++;Vim;Visual Studio;V...</td>
      <td>Vim;Visual Studio Code</td>
      <td>MacOS</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>False</td>
      <td>NaN</td>
      <td>Neutral</td>
      <td>Yes</td>
      <td>55-64 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Too long</td>
      <td>Easy</td>
      <td>11250000.0</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
    </tr>
    <tr>
      <th>35779</th>
      <td>35780</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>Pennsylvania</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>18 - 24 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>13</td>
      <td>13</td>
      <td>Developer, full-stack</td>
      <td>20 to 99 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>2.200000e+05</td>
      <td>Weekly</td>
      <td>Bash/Shell;HTML/CSS;JavaScript;Node.js;Ruby;SQL</td>
      <td>Bash/Shell;HTML/CSS;JavaScript;Node.js;Ruby;SQL</td>
      <td>DynamoDB;Elasticsearch;PostgreSQL;Redis</td>
      <td>DynamoDB;Elasticsearch;PostgreSQL;Redis</td>
      <td>AWS;Google Cloud Platform;Heroku</td>
      <td>AWS;Heroku</td>
      <td>Express;React.js;Ruby on Rails</td>
      <td>React.js;Ruby on Rails</td>
      <td>...</td>
      <td>React Native;TensorFlow</td>
      <td>Yarn</td>
      <td>Yarn</td>
      <td>Android Studio;TextMate;Visual Studio Code;Xcode</td>
      <td>Android Studio;Visual Studio Code</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Multiple times per day</td>
      <td>False</td>
      <td>NaN</td>
      <td>No, not really</td>
      <td>No</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>11000000.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>7904</th>
      <td>7905</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>Washington</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>18 - 24 years</td>
      <td>School;Books / Physical media</td>
      <td>11</td>
      <td>7</td>
      <td>Developer, mobile</td>
      <td>5,000 to 9,999 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>2.100000e+05</td>
      <td>Weekly</td>
      <td>Bash/Shell;C++;Objective-C;Swift</td>
      <td>Objective-C;Swift</td>
      <td>SQLite</td>
      <td>SQLite</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>Git</td>
      <td>Git</td>
      <td>Sublime Text;Vim;Visual Studio Code;Xcode</td>
      <td>Sublime Text;Vim;Visual Studio Code;Xcode</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Go for a walk or oth...</td>
      <td>Stack Overflow;Stack Overflow for Teams (priva...</td>
      <td>Multiple times per day</td>
      <td>True</td>
      <td>A few times per month or weekly</td>
      <td>Neutral</td>
      <td>Yes</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>10500000.0</td>
      <td>Call a coworker or friend;Go for a walk or oth...</td>
    </tr>
    <tr>
      <th>10372</th>
      <td>10373</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>Connecticut</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>5 - 10 years</td>
      <td>School;Books / Physical media</td>
      <td>35</td>
      <td>21</td>
      <td>Developer, front-end;Developer, full-stack</td>
      <td>10,000 or more employees</td>
      <td>USD\tUnited States dollar</td>
      <td>2.070000e+05</td>
      <td>Weekly</td>
      <td>HTML/CSS;Java;JavaScript;Node.js;SQL;TypeScript</td>
      <td>Java;Node.js;TypeScript</td>
      <td>Microsoft SQL Server;PostgreSQL</td>
      <td>NaN</td>
      <td>AWS</td>
      <td>NaN</td>
      <td>Angular</td>
      <td>Angular</td>
      <td>...</td>
      <td>NaN</td>
      <td>Docker</td>
      <td>Docker</td>
      <td>IntelliJ</td>
      <td>IntelliJ;Visual Studio Code</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Go for a walk or oth...</td>
      <td>Stack Overflow</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>A few times per month or weekly</td>
      <td>Yes, somewhat</td>
      <td>Yes</td>
      <td>45-54 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual;Prefer to self-describe:</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>Or, in your own words:</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>10350000.0</td>
      <td>Call a coworker or friend;Go for a walk or oth...</td>
    </tr>
    <tr>
      <th>9189</th>
      <td>9190</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>Washington</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>5 - 10 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>35</td>
      <td>24</td>
      <td>Developer, back-end;Engineering manager</td>
      <td>10,000 or more employees</td>
      <td>USD\tUnited States dollar</td>
      <td>8.500000e+05</td>
      <td>Monthly</td>
      <td>Bash/Shell;Go;Java;Kotlin;Node.js;TypeScript</td>
      <td>Bash/Shell;Go;Kotlin;Node.js;TypeScript</td>
      <td>MariaDB;SQLite</td>
      <td>MariaDB;SQLite</td>
      <td>AWS;Google Cloud Platform;Microsoft Azure</td>
      <td>AWS;Google Cloud Platform;Microsoft Azure</td>
      <td>Express;jQuery</td>
      <td>Express;jQuery</td>
      <td>...</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>Git</td>
      <td>Android Studio;IntelliJ;RStudio;Visual Studio;...</td>
      <td>Android Studio;IntelliJ;Visual Studio;Visual S...</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Go for a walk or oth...</td>
      <td>Stack Overflow</td>
      <td>A few times per month or weekly</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>No, not really</td>
      <td>Yes</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent;Southeast Asian</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>10200000.0</td>
      <td>Call a coworker or friend;Go for a walk or oth...</td>
    </tr>
    <tr>
      <th>20908</th>
      <td>20909</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>Texas</td>
      <td>NaN</td>
      <td>Some college/university study without earning ...</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>20</td>
      <td>20</td>
      <td>Developer, front-end;Developer, desktop or ent...</td>
      <td>5,000 to 9,999 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>2.000000e+05</td>
      <td>Weekly</td>
      <td>C#;HTML/CSS;JavaScript;PowerShell;Python;SQL;T...</td>
      <td>C#;HTML/CSS;JavaScript;PowerShell;Python;SQL;T...</td>
      <td>Microsoft SQL Server;MySQL;Redis</td>
      <td>Microsoft SQL Server;MySQL;Redis</td>
      <td>Microsoft Azure</td>
      <td>Microsoft Azure</td>
      <td>Angular;ASP.NET Core ;React.js;Vue.js</td>
      <td>Angular;ASP.NET Core ;React.js;Vue.js</td>
      <td>...</td>
      <td>.NET Core / .NET 5</td>
      <td>Docker;Git;Kubernetes</td>
      <td>Docker;Git;Kubernetes;Unity 3D</td>
      <td>Notepad++;Visual Studio;Visual Studio Code</td>
      <td>Notepad++;Visual Studio;Visual Studio Code</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Do other work and come ba...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>True</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>Yes, definitely</td>
      <td>No</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>Or, in your own words:</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>10000000.0</td>
      <td>Visit Stack Overflow;Do other work and come ba...</td>
    </tr>
    <tr>
      <th>52070</th>
      <td>52071</td>
      <td>I am not primarily a developer, but I write co...</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>California</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>5 - 10 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>20</td>
      <td>10</td>
      <td>Developer, front-end;Data scientist or machine...</td>
      <td>1,000 to 4,999 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>2.000000e+05</td>
      <td>Weekly</td>
      <td>Bash/Shell;C++;JavaScript;Python;Rust</td>
      <td>Bash/Shell;JavaScript;Python;Rust</td>
      <td>SQLite</td>
      <td>NaN</td>
      <td>AWS</td>
      <td>NaN</td>
      <td>Angular.js;jQuery</td>
      <td>jQuery</td>
      <td>...</td>
      <td>NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>Docker;Git</td>
      <td>Docker;Git</td>
      <td>Atom;Vim;Visual Studio Code</td>
      <td>Atom;Vim;Visual Studio Code</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>A few times per week</td>
      <td>Yes, somewhat</td>
      <td>Yes</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Too short</td>
      <td>Easy</td>
      <td>10000000.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>53028</th>
      <td>53029</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>Missouri</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>5 - 10 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>20</td>
      <td>15</td>
      <td>Developer, full-stack</td>
      <td>10,000 or more employees</td>
      <td>USD\tUnited States dollar</td>
      <td>2.000000e+05</td>
      <td>Weekly</td>
      <td>C;C++;Go;HTML/CSS;Java;JavaScript;Node.js;Pyth...</td>
      <td>C;C++;Go;HTML/CSS;Java;JavaScript;Node.js;Pyth...</td>
      <td>DynamoDB;Elasticsearch;MySQL;Oracle;PostgreSQL...</td>
      <td>Cassandra;DynamoDB;Elasticsearch;PostgreSQL;Redis</td>
      <td>AWS;DigitalOcean;Google Cloud Platform;Heroku;...</td>
      <td>AWS;Google Cloud Platform</td>
      <td>Express;React.js</td>
      <td>Express</td>
      <td>...</td>
      <td>TensorFlow</td>
      <td>Docker;Flow;Git</td>
      <td>Terraform;Unreal Engine</td>
      <td>IntelliJ;Vim;Visual Studio Code</td>
      <td>Vim</td>
      <td>MacOS</td>
      <td>Go for a walk or other physical activity;Do ot...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>Neutral</td>
      <td>Yes</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>10000000.0</td>
      <td>Go for a walk or other physical activity;Do ot...</td>
    </tr>
    <tr>
      <th>64111</th>
      <td>64112</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>California</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>12</td>
      <td>7</td>
      <td>Developer, back-end</td>
      <td>20 to 99 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>2.000000e+05</td>
      <td>Weekly</td>
      <td>Go;Java</td>
      <td>Go</td>
      <td>PostgreSQL</td>
      <td>PostgreSQL</td>
      <td>Google Cloud Platform</td>
      <td>Google Cloud Platform</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>Docker;Git;Kubernetes</td>
      <td>Docker;Git;Kubernetes</td>
      <td>IntelliJ;Visual Studio Code</td>
      <td>IntelliJ;Visual Studio Code</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>No, not really</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Too short</td>
      <td>Easy</td>
      <td>10000000.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>66323</th>
      <td>66324</td>
      <td>I am not primarily a developer, but I write co...</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>Indiana</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>5 - 10 years</td>
      <td>Coding Bootcamp;School</td>
      <td>33</td>
      <td>23</td>
      <td>Developer, embedded applications or devices</td>
      <td>10,000 or more employees</td>
      <td>USD\tUnited States dollar</td>
      <td>2.000000e+05</td>
      <td>Weekly</td>
      <td>C</td>
      <td>C;Python</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>Git</td>
      <td>Git</td>
      <td>Eclipse;Notepad++</td>
      <td>Eclipse;Notepad++</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Google it</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per month or weekly</td>
      <td>False</td>
      <td>NaN</td>
      <td>No, not at all</td>
      <td>Yes</td>
      <td>45-54 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>10000000.0</td>
      <td>Visit Stack Overflow;Google it Stack Overflow;...</td>
    </tr>
    <tr>
      <th>82156</th>
      <td>82157</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>IRAN, ISLAMIC REPUBLIC OF...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>25 - 34 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>NaN</td>
      <td>5</td>
      <td>Developer, back-end</td>
      <td>10 to 19 employees</td>
      <td>IRR\tIranian rial</td>
      <td>3.500000e+10</td>
      <td>Monthly</td>
      <td>HTML/CSS;JavaScript;PHP</td>
      <td>HTML/CSS;JavaScript;PHP;SQL</td>
      <td>MySQL</td>
      <td>MySQL</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>jQuery</td>
      <td>Angular;Django;jQuery;Laravel;Vue.js</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Android Studio;PHPStorm</td>
      <td>PHPStorm</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>A few times per week</td>
      <td>Yes, definitely</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Woman</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Middle Eastern</td>
      <td>NaN</td>
      <td>None of the above</td>
      <td>Too long</td>
      <td>Neither easy nor difficult</td>
      <td>9975060.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>7134</th>
      <td>7135</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>California</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>School;Friend or family member;Online Courses ...</td>
      <td>13</td>
      <td>9</td>
      <td>Developer, full-stack</td>
      <td>2 to 9 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>1.900000e+05</td>
      <td>Weekly</td>
      <td>Bash/Shell;JavaScript;Node.js;Rust;SQL;Swift;T...</td>
      <td>Node.js;Rust;SQL;TypeScript</td>
      <td>Microsoft SQL Server;MongoDB;MySQL;PostgreSQL;...</td>
      <td>PostgreSQL;Redis</td>
      <td>AWS;Google Cloud Platform;Microsoft Azure</td>
      <td>AWS;Google Cloud Platform</td>
      <td>Angular;Angular.js</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>Docker;Git;Kubernetes</td>
      <td>Docker;Git;Kubernetes</td>
      <td>IntelliJ;Webstorm;Xcode</td>
      <td>IntelliJ;Neovim;Webstorm</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>Multiple times per day</td>
      <td>False</td>
      <td>NaN</td>
      <td>No, not really</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man;Non-binary, genderqueer, or gender non-con...</td>
      <td>Prefer not to say</td>
      <td>Bisexual;Queer</td>
      <td>White or of European descent;Southeast Asian;B...</td>
      <td>None of the above</td>
      <td>I have a concentration and/or memory disorder ...</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>9500000.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>60701</th>
      <td>60702</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>Colorado</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Coding Bootcamp;School;Friend or family member...</td>
      <td>14</td>
      <td>11</td>
      <td>Engineer, data;Data scientist or machine learn...</td>
      <td>100 to 499 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>1.900000e+05</td>
      <td>Weekly</td>
      <td>Bash/Shell;Java;Python;Ruby;SQL</td>
      <td>Python;Scala;SQL</td>
      <td>DynamoDB;PostgreSQL</td>
      <td>PostgreSQL</td>
      <td>AWS</td>
      <td>AWS</td>
      <td>Flask;Ruby on Rails</td>
      <td>Flask;Ruby on Rails</td>
      <td>...</td>
      <td>Apache Spark;NumPy;Pandas;TensorFlow;Torch/PyT...</td>
      <td>Docker;Git;Kubernetes;Yarn</td>
      <td>Docker;Git;Kubernetes;Terraform</td>
      <td>IPython/Jupyter;Vim</td>
      <td>IPython/Jupyter;Vim</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>Yes, somewhat</td>
      <td>Yes</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>NaN</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>9500000.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>66417</th>
      <td>66418</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>Texas</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>18 - 24 years</td>
      <td>School;Books / Physical media</td>
      <td>38</td>
      <td>35</td>
      <td>Developer, embedded applications or devices</td>
      <td>10,000 or more employees</td>
      <td>USD\tUnited States dollar</td>
      <td>1.820000e+05</td>
      <td>Weekly</td>
      <td>Assembly;C;Python</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>Git</td>
      <td>Docker</td>
      <td>Eclipse;Notepad++</td>
      <td>NaN</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>Multiple times per day</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>Neutral</td>
      <td>Yes</td>
      <td>55-64 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>9100000.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>64281</th>
      <td>64282</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>Illinois</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>17</td>
      <td>11</td>
      <td>Developer, full-stack;DevOps specialist</td>
      <td>1,000 to 4,999 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>1.800000e+05</td>
      <td>Weekly</td>
      <td>C#;Groovy;PowerShell</td>
      <td>C#;Go;JavaScript;Node.js;PowerShell</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Microsoft Azure</td>
      <td>Microsoft Azure</td>
      <td>ASP.NET;ASP.NET Core</td>
      <td>ASP.NET Core</td>
      <td>...</td>
      <td>.NET Framework;.NET Core / .NET 5</td>
      <td>Chef;Docker;Git;Kubernetes;Terraform</td>
      <td>Docker;Git;Kubernetes</td>
      <td>Notepad++;Visual Studio;Visual Studio Code</td>
      <td>Notepad++;Visual Studio;Visual Studio Code</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per month or weekly</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>No, not really</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>I have an anxiety disorder</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>9000000.0</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
    </tr>
    <tr>
      <th>51240</th>
      <td>51241</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>Ohio</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>11 - 17 years</td>
      <td>Books / Physical media</td>
      <td>30</td>
      <td>26</td>
      <td>Developer, mobile;Developer, front-end;Develop...</td>
      <td>500 to 999 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>1.770000e+05</td>
      <td>Weekly</td>
      <td>C#;Delphi;HTML/CSS;PHP;SQL</td>
      <td>C#;Delphi;HTML/CSS;SQL</td>
      <td>MariaDB;Microsoft SQL Server;MySQL;PostgreSQL;...</td>
      <td>MariaDB;MySQL;SQLite</td>
      <td>AWS;DigitalOcean;Microsoft Azure</td>
      <td>DigitalOcean</td>
      <td>ASP.NET</td>
      <td>ASP.NET</td>
      <td>...</td>
      <td>.NET Framework</td>
      <td>Docker;Git;Xamarin</td>
      <td>Git</td>
      <td>Android Studio;Eclipse;Notepad++;Visual Studio...</td>
      <td>Notepad++;Visual Studio</td>
      <td>Windows</td>
      <td>Google it</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per month or weekly</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>No, not really</td>
      <td>Yes</td>
      <td>45-54 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>8850000.0</td>
      <td>Google it Stack Overflow;Stack Exchange</td>
    </tr>
    <tr>
      <th>33313</th>
      <td>33314</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>NEW ZEALAND</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>38</td>
      <td>30</td>
      <td>Developer, full-stack;Engineering manager</td>
      <td>10 to 19 employees</td>
      <td>NZD\tNew Zealand dollar</td>
      <td>1.350000e+07</td>
      <td>Yearly</td>
      <td>Delphi</td>
      <td>C++;Delphi;Python;Rust</td>
      <td>Microsoft SQL Server</td>
      <td>MySQL</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>Docker;Git;Terraform</td>
      <td>Eclipse;PyCharm;Vim;Visual Studio Code</td>
      <td>Atom;Eclipse;PyCharm;Vim</td>
      <td>Linux-based</td>
      <td>Visit Stack Overflow;Google it;Watch help / tu...</td>
      <td>Stack Overflow</td>
      <td>A few times per week</td>
      <td>False</td>
      <td>NaN</td>
      <td>No, not really</td>
      <td>Yes</td>
      <td>55-64 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Hispanic or Latino/a/x</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>8625145.0</td>
      <td>Visit Stack Overflow;Google it;Watch help / tu...</td>
    </tr>
    <tr>
      <th>47536</th>
      <td>47537</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>Pennsylvania</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>25 - 34 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>5</td>
      <td>5</td>
      <td>Developer, full-stack;DevOps specialist</td>
      <td>20 to 99 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>1.700000e+05</td>
      <td>Weekly</td>
      <td>HTML/CSS;JavaScript;Python;SQL;TypeScript</td>
      <td>Python;Rust;TypeScript</td>
      <td>DynamoDB;MariaDB;MySQL;PostgreSQL;Redis</td>
      <td>MySQL;PostgreSQL;Redis</td>
      <td>AWS;DigitalOcean;Google Cloud Platform;Heroku</td>
      <td>AWS;DigitalOcean;Heroku</td>
      <td>Django;Flask;Vue.js</td>
      <td>Django;FastAPI;Flask;Vue.js</td>
      <td>...</td>
      <td>NaN</td>
      <td>Docker;Git;Kubernetes;Pulumi;Yarn</td>
      <td>Docker;Git;Kubernetes;Pulumi;Yarn</td>
      <td>IPython/Jupyter;Vim;Visual Studio Code</td>
      <td>IPython/Jupyter;PyCharm;Vim;Visual Studio Code</td>
      <td>Linux-based</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
      <td>Stack Overflow;Stack Exchange;Stack Overflow f...</td>
      <td>Multiple times per day</td>
      <td>True</td>
      <td>A few times per month or weekly</td>
      <td>Yes, definitely</td>
      <td>Yes</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>NaN</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>8500000.0</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
    </tr>
    <tr>
      <th>51010</th>
      <td>51011</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>New York</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>5 - 10 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>8</td>
      <td>4</td>
      <td>Developer, desktop or enterprise applications;...</td>
      <td>10,000 or more employees</td>
      <td>USD\tUnited States dollar</td>
      <td>1.650000e+05</td>
      <td>Weekly</td>
      <td>Bash/Shell;Groovy;HTML/CSS;Java;JavaScript;Typ...</td>
      <td>Bash/Shell;Groovy;HTML/CSS;Java;JavaScript;Nod...</td>
      <td>MongoDB;MySQL</td>
      <td>Elasticsearch;Firebase;MongoDB;MySQL</td>
      <td>AWS</td>
      <td>AWS;Google Cloud Platform;Heroku</td>
      <td>Angular.js;Gatsby;jQuery;React.js;Spring</td>
      <td>Django;Gatsby;React.js;Spring</td>
      <td>...</td>
      <td>NumPy;Pandas;TensorFlow</td>
      <td>Chef;Git;Yarn</td>
      <td>Chef;Deno;Docker;Git;Kubernetes;Yarn</td>
      <td>IntelliJ;Visual Studio Code</td>
      <td>IntelliJ;Visual Studio Code</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per month or weekly</td>
      <td>False</td>
      <td>NaN</td>
      <td>No, not really</td>
      <td>Yes</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>Or, in your own words:</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>8250000.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>47210</th>
      <td>47211</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>Massachusetts</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>24</td>
      <td>14</td>
      <td>Developer, mobile</td>
      <td>100 to 499 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>1.620000e+05</td>
      <td>Weekly</td>
      <td>Swift</td>
      <td>Rust;Swift;TypeScript</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>Git</td>
      <td>Git</td>
      <td>Visual Studio Code;Xcode</td>
      <td>Visual Studio Code;Xcode</td>
      <td>MacOS</td>
      <td>Visit Stack Overflow;Google it;Do other work a...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per month or weekly</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>No, not really</td>
      <td>Yes</td>
      <td>35-44 years old</td>
      <td>Prefer not to say</td>
      <td>Yes</td>
      <td>Prefer not to say</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>Prefer not to say</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>8100000.0</td>
      <td>Visit Stack Overflow;Google it;Do other work a...</td>
    </tr>
    <tr>
      <th>45288</th>
      <td>45289</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>UNITED KINGDOM OF GREAT BRITAIN AND NORTHERN I...</td>
      <td>NaN</td>
      <td>England</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>17</td>
      <td>8</td>
      <td>Data scientist or machine learning specialist</td>
      <td>10,000 or more employees</td>
      <td>GBP\tPound sterling</td>
      <td>1.250000e+05</td>
      <td>Weekly</td>
      <td>Bash/Shell;Python</td>
      <td>C++;Rust</td>
      <td>PostgreSQL</td>
      <td>NaN</td>
      <td>AWS;Microsoft Azure</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>Docker;Git;Kubernetes</td>
      <td>NaN</td>
      <td>IPython/Jupyter;PyCharm</td>
      <td>NaN</td>
      <td>Linux-based</td>
      <td>Google it</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Multiple times per day</td>
      <td>True</td>
      <td>A few times per week</td>
      <td>Yes, somewhat</td>
      <td>Yes</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>8078700.0</td>
      <td>Google it Stack Overflow;Stack Exchange</td>
    </tr>
    <tr>
      <th>33919</th>
      <td>33920</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>Pennsylvania</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>School;Books / Physical media</td>
      <td>25</td>
      <td>20</td>
      <td>Developer, full-stack</td>
      <td>1,000 to 4,999 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>1.600000e+05</td>
      <td>Weekly</td>
      <td>C#</td>
      <td>C#</td>
      <td>Microsoft SQL Server;SQLite</td>
      <td>Microsoft SQL Server;SQLite</td>
      <td>Microsoft Azure</td>
      <td>Microsoft Azure</td>
      <td>ASP.NET Core</td>
      <td>ASP.NET Core</td>
      <td>...</td>
      <td>.NET Framework;.NET Core / .NET 5</td>
      <td>Git</td>
      <td>Git</td>
      <td>Visual Studio</td>
      <td>Visual Studio</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Google it;Watch help / tu...</td>
      <td>Stack Overflow</td>
      <td>A few times per week</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>No, not really</td>
      <td>No</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>8000000.0</td>
      <td>Visit Stack Overflow;Google it;Watch help / tu...</td>
    </tr>
    <tr>
      <th>55534</th>
      <td>55535</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>California</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>25 - 34 years</td>
      <td>Coding Bootcamp</td>
      <td>6</td>
      <td>5</td>
      <td>Developer, full-stack</td>
      <td>1,000 to 4,999 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>1.600000e+05</td>
      <td>Weekly</td>
      <td>Bash/Shell;HTML/CSS;Ruby;SQL;TypeScript</td>
      <td>Bash/Shell;Ruby;TypeScript</td>
      <td>Elasticsearch;PostgreSQL</td>
      <td>NaN</td>
      <td>AWS;Heroku</td>
      <td>AWS</td>
      <td>React.js;Ruby on Rails</td>
      <td>React.js;Ruby on Rails</td>
      <td>...</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>Git</td>
      <td>Visual Studio Code</td>
      <td>Visual Studio Code</td>
      <td>MacOS</td>
      <td>Visit Stack Overflow;Google it;Do other work a...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>No, not really</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Woman</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>I have a concentration and/or memory disorder ...</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>8000000.0</td>
      <td>Visit Stack Overflow;Google it;Do other work a...</td>
    </tr>
    <tr>
      <th>66013</th>
      <td>66014</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>Virginia</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>5 - 10 years</td>
      <td>School;Books / Physical media</td>
      <td>30</td>
      <td>20</td>
      <td>Developer, front-end;Developer, desktop or ent...</td>
      <td>1,000 to 4,999 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>1.600000e+05</td>
      <td>Weekly</td>
      <td>C#;HTML/CSS;JavaScript;SQL;TypeScript</td>
      <td>C#;HTML/CSS;JavaScript;Node.js;Python;SQL;Type...</td>
      <td>Microsoft SQL Server;MySQL</td>
      <td>Microsoft SQL Server;MySQL</td>
      <td>AWS;Microsoft Azure</td>
      <td>AWS;Microsoft Azure</td>
      <td>Angular;Angular.js;ASP.NET;jQuery</td>
      <td>Angular;Angular.js;ASP.NET;ASP.NET Core ;Drupa...</td>
      <td>...</td>
      <td>.NET Framework;.NET Core / .NET 5;Hadoop</td>
      <td>Git</td>
      <td>Docker;Flow;Git</td>
      <td>Notepad++;PyCharm;Visual Studio;Visual Studio ...</td>
      <td>Android Studio;Eclipse;Notepad++;PyCharm;Visua...</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Multiple times per day</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>Yes, somewhat</td>
      <td>Yes</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent;Indigenous (such ...</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Too long</td>
      <td>Easy</td>
      <td>8000000.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>77060</th>
      <td>77061</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>New York</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Friend or family member</td>
      <td>16</td>
      <td>6</td>
      <td>Developer, full-stack;Data scientist or machin...</td>
      <td>10,000 or more employees</td>
      <td>USD\tUnited States dollar</td>
      <td>1.600000e+05</td>
      <td>Weekly</td>
      <td>HTML/CSS;Java;JavaScript;Node.js;Python;Swift;...</td>
      <td>Bash/Shell;HTML/CSS;Java;Python;Swift;TypeScript</td>
      <td>DynamoDB;Elasticsearch;PostgreSQL</td>
      <td>DynamoDB;PostgreSQL</td>
      <td>AWS</td>
      <td>AWS</td>
      <td>React.js</td>
      <td>React.js</td>
      <td>...</td>
      <td>NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>Docker;Git</td>
      <td>Docker;Git</td>
      <td>IntelliJ;IPython/Jupyter;NetBeans;PyCharm;Vim;...</td>
      <td>IntelliJ;IPython/Jupyter;NetBeans;PyCharm;Vim;...</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>Neutral</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>I have a concentration and/or memory disorder ...</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>8000000.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>78554</th>
      <td>78555</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>INDONESIA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>18 - 24 years</td>
      <td>School</td>
      <td>10</td>
      <td>5</td>
      <td>Developer, front-end;Developer, full-stack;Dev...</td>
      <td>10 to 19 employees</td>
      <td>IDR\tIndonesian rupiah</td>
      <td>9.000000e+09</td>
      <td>Monthly</td>
      <td>Delphi;Go;Java;JavaScript;Node.js;PHP;TypeScript</td>
      <td>Go;Java;JavaScript;Node.js;Swift;TypeScript</td>
      <td>Couchbase;Firebase;MongoDB;MySQL;PostgreSQL;Redis</td>
      <td>Couchbase;Firebase;MongoDB;Redis;SQLite</td>
      <td>AWS;DigitalOcean;Google Cloud Platform;Heroku</td>
      <td>AWS;Google Cloud Platform;Heroku</td>
      <td>Express;Gatsby;jQuery;React.js;Spring</td>
      <td>Express;Gatsby;React.js;Spring</td>
      <td>...</td>
      <td>Qt;React Native;TensorFlow</td>
      <td>Docker;Git;Yarn</td>
      <td>Docker;Git;Yarn</td>
      <td>Neovim;Vim</td>
      <td>Neovim;Vim</td>
      <td>Linux-based</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
      <td>Stack Overflow</td>
      <td>Multiple times per day</td>
      <td>True</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>No, not really</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Southeast Asian</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Too long</td>
      <td>Easy</td>
      <td>7903704.0</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
    </tr>
    <tr>
      <th>4395</th>
      <td>4396</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>Tennessee</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>18 - 24 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>15</td>
      <td>11</td>
      <td>Developer, back-end;Product manager</td>
      <td>500 to 999 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>1.580000e+05</td>
      <td>Weekly</td>
      <td>Bash/Shell;C++;Go;JavaScript;Node.js;Python;SQ...</td>
      <td>Rust</td>
      <td>DynamoDB;MongoDB;MySQL;Redis;SQLite</td>
      <td>NaN</td>
      <td>AWS</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>Docker;Git;Kubernetes;Terraform</td>
      <td>NaN</td>
      <td>IntelliJ;Visual Studio Code</td>
      <td>NaN</td>
      <td>MacOS</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>No, not really</td>
      <td>Yes</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Prefer not to say</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>Prefer not to say</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>7900000.0</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
    </tr>
    <tr>
      <th>54701</th>
      <td>54702</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>New York</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>18 - 24 years</td>
      <td>Coding Bootcamp;School;Online Courses or Certi...</td>
      <td>10</td>
      <td>6</td>
      <td>Developer, front-end;Developer, full-stack;Dev...</td>
      <td>1,000 to 4,999 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>1.580000e+05</td>
      <td>Weekly</td>
      <td>HTML/CSS;JavaScript;Ruby;SQL</td>
      <td>HTML/CSS;JavaScript;Python;Ruby;SQL;TypeScript</td>
      <td>MySQL;PostgreSQL</td>
      <td>MySQL;PostgreSQL;Redis</td>
      <td>AWS;Heroku</td>
      <td>AWS;Microsoft Azure</td>
      <td>jQuery;React.js;Ruby on Rails</td>
      <td>React.js;Ruby on Rails</td>
      <td>...</td>
      <td>NaN</td>
      <td>Chef;Git;Yarn</td>
      <td>Docker;Git;Yarn</td>
      <td>Sublime Text;Visual Studio Code</td>
      <td>Visual Studio Code</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per month or weekly</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Neutral</td>
      <td>Yes</td>
      <td>25-34 years old</td>
      <td>Woman</td>
      <td>No</td>
      <td>Prefer to self-describe:</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>I have a mood or emotional disorder (e.g. depr...</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>7900000.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>25102</th>
      <td>25103</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>CANADA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Some college/university study without earning ...</td>
      <td>11 - 17 years</td>
      <td>School</td>
      <td>6</td>
      <td>1</td>
      <td>Developer, front-end;Developer, full-stack;Dev...</td>
      <td>Just me - I am a freelancer, sole proprietor, ...</td>
      <td>CAD\tCanadian dollar</td>
      <td>1.000000e+07</td>
      <td>Yearly</td>
      <td>Bash/Shell;HTML/CSS;JavaScript;Python;SQL</td>
      <td>NaN</td>
      <td>MongoDB;PostgreSQL;Redis;SQLite</td>
      <td>NaN</td>
      <td>AWS;Heroku</td>
      <td>NaN</td>
      <td>FastAPI;Svelte</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>Git;Yarn</td>
      <td>NaN</td>
      <td>Sublime Text</td>
      <td>NaN</td>
      <td>MacOS</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
      <td>Stack Overflow;Stack Exchange;Stack Overflow f...</td>
      <td>Multiple times per day</td>
      <td>True</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>No, not really</td>
      <td>Yes</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>NaN</td>
      <td>None of the above</td>
      <td>I have autism / an autism spectrum disorder (e...</td>
      <td>Too long</td>
      <td>Easy</td>
      <td>7563129.0</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
    </tr>
    <tr>
      <th>1931</th>
      <td>1932</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>Idaho</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>18 - 24 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>22</td>
      <td>20</td>
      <td>Developer, front-end;Developer, full-stack;Dev...</td>
      <td>20 to 99 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>1.500000e+05</td>
      <td>Weekly</td>
      <td>Bash/Shell;HTML/CSS;Java;JavaScript;Node.js;PH...</td>
      <td>Bash/Shell;Go;HTML/CSS;JavaScript;Node.js;PHP;...</td>
      <td>MySQL;Redis;SQLite</td>
      <td>MySQL;Oracle;Redis;SQLite</td>
      <td>AWS;Google Cloud Platform;Microsoft Azure</td>
      <td>Google Cloud Platform</td>
      <td>Laravel;Symfony;Vue.js</td>
      <td>Laravel;Svelte;Symfony;Vue.js</td>
      <td>...</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>Git</td>
      <td>Android Studio;Atom;Eclipse;Sublime Text;Visua...</td>
      <td>Visual Studio Code</td>
      <td>Linux-based</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>Yes, definitely</td>
      <td>No</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>I have a concentration and/or memory disorder ...</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>7500000.0</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
    </tr>
    <tr>
      <th>5000</th>
      <td>5001</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>Washington</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>18 - 24 years</td>
      <td>School;Books / Physical media</td>
      <td>12</td>
      <td>9</td>
      <td>Developer, full-stack;Developer, back-end;DevO...</td>
      <td>10 to 19 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>1.500000e+05</td>
      <td>Weekly</td>
      <td>Assembly;Bash/Shell;HTML/CSS;Java;JavaScript;K...</td>
      <td>JavaScript;Kotlin;Node.js;Python;Rust;Swift;Ty...</td>
      <td>MySQL;PostgreSQL</td>
      <td>PostgreSQL</td>
      <td>AWS;Google Cloud Platform</td>
      <td>AWS</td>
      <td>Express;jQuery;React.js;Ruby on Rails;Spring</td>
      <td>Express;jQuery;React.js</td>
      <td>...</td>
      <td>NaN</td>
      <td>Docker;Git;Kubernetes;Pulumi;Yarn</td>
      <td>Deno;Docker;Git;Pulumi;Yarn</td>
      <td>Android Studio;IntelliJ;Vim;Visual Studio Code...</td>
      <td>Android Studio;IntelliJ;Vim;Visual Studio Code</td>
      <td>MacOS</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>No, not really</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>Prefer not to say</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>7500000.0</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
    </tr>
    <tr>
      <th>46391</th>
      <td>46392</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>Ohio</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>School</td>
      <td>13</td>
      <td>9</td>
      <td>Developer, mobile</td>
      <td>1,000 to 4,999 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>1.500000e+05</td>
      <td>Weekly</td>
      <td>JavaScript;Ruby;Swift</td>
      <td>JavaScript;Ruby;Swift;TypeScript</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Microsoft Azure</td>
      <td>NaN</td>
      <td>Ruby on Rails;Vue.js</td>
      <td>React.js;Ruby on Rails;Vue.js</td>
      <td>...</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>Docker;Git</td>
      <td>Vim;Visual Studio Code;Xcode</td>
      <td>Visual Studio Code;Xcode</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>No, not really</td>
      <td>Yes</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>I have a concentration and/or memory disorder ...</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>7500000.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>59563</th>
      <td>59564</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>Illinois</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>18 - 24 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>9</td>
      <td>6</td>
      <td>Developer, back-end;DevOps specialist;Engineer...</td>
      <td>10,000 or more employees</td>
      <td>USD\tUnited States dollar</td>
      <td>1.500000e+05</td>
      <td>Weekly</td>
      <td>Clojure;Go</td>
      <td>Clojure;Go</td>
      <td>Elasticsearch</td>
      <td>Elasticsearch</td>
      <td>AWS</td>
      <td>AWS</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>Ansible;Docker;Git;Kubernetes;Terraform</td>
      <td>Docker;Git;Kubernetes;Terraform</td>
      <td>Emacs;Vim</td>
      <td>Emacs;Vim</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Go for a walk or oth...</td>
      <td>Stack Overflow</td>
      <td>A few times per week</td>
      <td>False</td>
      <td>NaN</td>
      <td>No, not really</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>7500000.0</td>
      <td>Call a coworker or friend;Go for a walk or oth...</td>
    </tr>
    <tr>
      <th>77655</th>
      <td>77656</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>Illinois</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>25 - 34 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>5</td>
      <td>3</td>
      <td>Developer, full-stack;Developer, back-end</td>
      <td>10,000 or more employees</td>
      <td>USD\tUnited States dollar</td>
      <td>1.500000e+05</td>
      <td>Weekly</td>
      <td>Java;JavaScript;Python;Ruby;SQL</td>
      <td>Go;Ruby;SQL</td>
      <td>PostgreSQL</td>
      <td>PostgreSQL</td>
      <td>AWS</td>
      <td>AWS;Google Cloud Platform</td>
      <td>React.js;Ruby on Rails</td>
      <td>Ruby on Rails</td>
      <td>...</td>
      <td>NaN</td>
      <td>Git;Kubernetes</td>
      <td>Git;Kubernetes</td>
      <td>IntelliJ;Sublime Text;Vim</td>
      <td>RubyMine;Vim;Visual Studio Code</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>A few times per week</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>I have a concentration and/or memory disorder ...</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>7500000.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>36552</th>
      <td>36553</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>New Jersey</td>
      <td>NaN</td>
      <td>Some college/university study without earning ...</td>
      <td>11 - 17 years</td>
      <td>School</td>
      <td>12</td>
      <td>10</td>
      <td>Developer, back-end</td>
      <td>1,000 to 4,999 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>1.476500e+05</td>
      <td>Weekly</td>
      <td>C#;Dart;Java;JavaScript;Kotlin;Node.js;Ruby;SQL</td>
      <td>Kotlin;SQL;TypeScript</td>
      <td>DynamoDB;Firebase;MySQL;PostgreSQL;Redis</td>
      <td>PostgreSQL;Redis</td>
      <td>AWS</td>
      <td>NaN</td>
      <td>Express;React.js;Ruby on Rails;Spring</td>
      <td>Express;Spring;Svelte</td>
      <td>...</td>
      <td>Flutter</td>
      <td>Docker;Git;Yarn</td>
      <td>Git</td>
      <td>Android Studio;Eclipse;IntelliJ;Notepad++;Visu...</td>
      <td>IntelliJ;Visual Studio Code</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Google it</td>
      <td>Stack Overflow</td>
      <td>Daily or almost daily</td>
      <td>False</td>
      <td>NaN</td>
      <td>No, not really</td>
      <td>Yes</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Or, in your own words:</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Too short</td>
      <td>Easy</td>
      <td>7382500.0</td>
      <td>Call a coworker or friend;Google it Stack Over...</td>
    </tr>
    <tr>
      <th>27561</th>
      <td>27562</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>Florida</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>25 - 34 years</td>
      <td>Coding Bootcamp;Other online resources (ex: vi...</td>
      <td>5</td>
      <td>5</td>
      <td>Developer, full-stack</td>
      <td>20 to 99 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>1.450000e+05</td>
      <td>Weekly</td>
      <td>C#;Go;HTML/CSS;JavaScript;Node.js;Python;SQL;T...</td>
      <td>Go;JavaScript;Node.js;Python;Rust;Scala;SQL;Ty...</td>
      <td>Microsoft SQL Server;MongoDB;MySQL;PostgreSQL;...</td>
      <td>Elasticsearch;MySQL;PostgreSQL</td>
      <td>AWS;Google Cloud Platform;Heroku;Microsoft Azure</td>
      <td>AWS;Google Cloud Platform;Heroku</td>
      <td>Angular;Angular.js;ASP.NET;ASP.NET Core ;Expre...</td>
      <td>Django;Flask;React.js;Vue.js</td>
      <td>...</td>
      <td>NaN</td>
      <td>Docker;Git;Terraform</td>
      <td>Docker;Git;Terraform</td>
      <td>Visual Studio Code</td>
      <td>Visual Studio Code</td>
      <td>MacOS</td>
      <td>Visit Stack Overflow;Do other work and come ba...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per month or weekly</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>Neutral</td>
      <td>No</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>7250000.0</td>
      <td>Visit Stack Overflow;Do other work and come ba...</td>
    </tr>
    <tr>
      <th>30569</th>
      <td>30570</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>Washington</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>25 - 34 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>10</td>
      <td>3</td>
      <td>Developer, front-end;Developer, desktop or ent...</td>
      <td>10,000 or more employees</td>
      <td>USD\tUnited States dollar</td>
      <td>1.400000e+05</td>
      <td>Weekly</td>
      <td>C;C#;C++;HTML/CSS;JavaScript;Node.js;Rust</td>
      <td>Rust;TypeScript</td>
      <td>MongoDB;MySQL</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>ASP.NET;ASP.NET Core ;jQuery;Vue.js</td>
      <td>Vue.js</td>
      <td>...</td>
      <td>NaN</td>
      <td>Docker;Git;Yarn</td>
      <td>Deno;Git;Yarn</td>
      <td>Notepad++;Visual Studio;Visual Studio Code</td>
      <td>Notepad++;Visual Studio;Visual Studio Code</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Google it;Watch help / tu...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Multiple times per day</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>No, not really</td>
      <td>No</td>
      <td>35-44 years old</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>7000000.0</td>
      <td>Visit Stack Overflow;Google it;Watch help / tu...</td>
    </tr>
    <tr>
      <th>50225</th>
      <td>50226</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>Illinois</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>18 - 24 years</td>
      <td>School</td>
      <td>10</td>
      <td>7</td>
      <td>Developer, desktop or enterprise applications;...</td>
      <td>20 to 99 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>1.400000e+05</td>
      <td>Weekly</td>
      <td>Bash/Shell;C;Node.js;Python;TypeScript</td>
      <td>C;Python;TypeScript</td>
      <td>MySQL</td>
      <td>NaN</td>
      <td>AWS</td>
      <td>Microsoft Azure</td>
      <td>Vue.js</td>
      <td>Vue.js</td>
      <td>...</td>
      <td>NaN</td>
      <td>Docker;Git;Yarn</td>
      <td>Docker;Git</td>
      <td>IPython/Jupyter;Vim;Visual Studio Code</td>
      <td>Visual Studio Code</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Google it;Do other w...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Multiple times per day</td>
      <td>True</td>
      <td>A few times per week</td>
      <td>Neutral</td>
      <td>Yes</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>7000000.0</td>
      <td>Call a coworker or friend;Google it;Do other w...</td>
    </tr>
  </tbody>
</table>
<p>50 rows × 49 columns</p>
</div>




```python
datos["CONVERTEDCOMPYEARLY"].nlargest(25)
```




    66910    45241312.0
    65399    30468516.0
    40586    21822250.0
    28791    20000000.0
    12700    19200000.0
    9608     17500000.0
    5305     15000000.0
    12903    14411628.0
    66488    12750000.0
    7205     12500000.0
    47563    12500000.0
    3733     11250000.0
    33255    11250000.0
    35779    11000000.0
    7904     10500000.0
    10372    10350000.0
    9189     10200000.0
    20908    10000000.0
    52070    10000000.0
    53028    10000000.0
    64111    10000000.0
    66323    10000000.0
    82156     9975060.0
    7134      9500000.0
    60701     9500000.0
    Name: CONVERTEDCOMPYEARLY, dtype: float64




```python
datos.nlargest(25, "CONVERTEDCOMPYEARLY")
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>RESPONSEID</th>
      <th>MAINBRANCH</th>
      <th>EMPLOYMENT</th>
      <th>COUNTRY</th>
      <th>USSTATE</th>
      <th>UKCOUNTRY</th>
      <th>EDLEVEL</th>
      <th>AGE1STCODE</th>
      <th>LEARNCODE</th>
      <th>YEARSCODE</th>
      <th>YEARSCODEPRO</th>
      <th>DEVTYPE</th>
      <th>ORGSIZE</th>
      <th>CURRENCY</th>
      <th>COMPTOTAL</th>
      <th>COMPFREQ</th>
      <th>LANGUAGEHAVEWORKEDWITH</th>
      <th>LANGUAGEWANTTOWORKWITH</th>
      <th>DATABASEHAVEWORKEDWITH</th>
      <th>DATABASEWANTTOWORKWITH</th>
      <th>PLATFORMHAVEWORKEDWITH</th>
      <th>PLATFORMWANTTOWORKWITH</th>
      <th>WEBFRAMEHAVEWORKEDWITH</th>
      <th>WEBFRAMEWANTTOWORKWITH</th>
      <th>...</th>
      <th>MISCTECHWANTTOWORKWITH</th>
      <th>TOOLSTECHHAVEWORKEDWITH</th>
      <th>TOOLSTECHWANTTOWORKWITH</th>
      <th>NEWCOLLABTOOLSHAVEWORKEDWITH</th>
      <th>NEWCOLLABTOOLSWANTTOWORKWITH</th>
      <th>OPSYS</th>
      <th>NEWSTUCK</th>
      <th>NEWSOSITES</th>
      <th>SOVISITFREQ</th>
      <th>SOACCOUNT</th>
      <th>SOPARTFREQ</th>
      <th>SOCOMM</th>
      <th>NEWOTHERCOMMS</th>
      <th>AGE</th>
      <th>GENDER</th>
      <th>TRANS</th>
      <th>SEXUALITY</th>
      <th>ETHNICITY</th>
      <th>ACCESSIBILITY</th>
      <th>MENTALHEALTH</th>
      <th>SURVEYLENGTH</th>
      <th>SURVEYEASE</th>
      <th>CONVERTEDCOMPYEARLY</th>
      <th>AYUDA</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>66910</th>
      <td>66911</td>
      <td>I am a developer by profession</td>
      <td>I prefer not to say</td>
      <td>BELGIUM</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Primary/elementary school</td>
      <td>55 - 64 years</td>
      <td>Books / Physical media</td>
      <td>1</td>
      <td>21</td>
      <td>NaN</td>
      <td>Just me - I am a freelancer, sole proprietor, ...</td>
      <td>ALL\tAlbanian lek</td>
      <td>5.123468e+09</td>
      <td>Yearly</td>
      <td>APL</td>
      <td>NaN</td>
      <td>Couchbase</td>
      <td>NaN</td>
      <td>AWS</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>IntelliJ;PyCharm</td>
      <td>NaN</td>
      <td>Other (please specify):</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
      <td>Stack Overflow for Teams (private knowledge sh...</td>
      <td>Less than once per month or monthly</td>
      <td>True</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>No, not at all</td>
      <td>Yes</td>
      <td>55-64 years old</td>
      <td>NaN</td>
      <td>Yes</td>
      <td>NaN</td>
      <td>Black or of African descent</td>
      <td>I am blind / have difficulty seeing</td>
      <td>I have a concentration and/or memory disorder ...</td>
      <td>Too short</td>
      <td>NaN</td>
      <td>45241312.0</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
    </tr>
    <tr>
      <th>65399</th>
      <td>65400</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>AFGHANISTAN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>25 - 34 years</td>
      <td>Online Courses or Certification</td>
      <td>7</td>
      <td>3</td>
      <td>Developer, desktop or enterprise applications;...</td>
      <td>500 to 999 employees</td>
      <td>ANG Netherlands Antillean guilder</td>
      <td>4.544242e+06</td>
      <td>Monthly</td>
      <td>Bash/Shell;C++;Elixir;LISP;Node.js;Ruby;Rust;S...</td>
      <td>Clojure;Crystal;Dart;Matlab;Node.js;Python;R</td>
      <td>Couchbase;Elasticsearch;MariaDB</td>
      <td>MySQL;Oracle</td>
      <td>AWS;IBM Cloud or Watson</td>
      <td>Oracle Cloud Infrastructure</td>
      <td>ASP.NET;Drupal;Laravel;Svelte</td>
      <td>Angular;ASP.NET;Django;Express;Flask;jQuery;Ru...</td>
      <td>...</td>
      <td>Flutter;Pandas;Qt</td>
      <td>Docker;Flow;Terraform</td>
      <td>Chef;Docker;Git</td>
      <td>NetBeans;PHPStorm;RubyMine</td>
      <td>Eclipse;NetBeans</td>
      <td>Linux-based</td>
      <td>Watch help / tutorial videos;Play games</td>
      <td>Stack Overflow;Stack Overflow for Teams (priva...</td>
      <td>A few times per month or weekly</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>No, not at all</td>
      <td>Yes</td>
      <td>35-44 years old</td>
      <td>Man;Non-binary, genderqueer, or gender non-con...</td>
      <td>Yes</td>
      <td>Bisexual;Prefer to self-describe:;Gay or Lesbi...</td>
      <td>South Asian;Hispanic or Latino/a/x;Black or of...</td>
      <td>I am unable to / find it difficult to walk or ...</td>
      <td>I have a mood or emotional disorder (e.g. depr...</td>
      <td>Too short</td>
      <td>Difficult</td>
      <td>30468516.0</td>
      <td>Watch help / tutorial videos;Play games Stack ...</td>
    </tr>
    <tr>
      <th>40586</th>
      <td>40587</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>California</td>
      <td>NaN</td>
      <td>Some college/university study without earning ...</td>
      <td>Younger than 5 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>37</td>
      <td>13</td>
      <td>Other (please specify):</td>
      <td>10,000 or more employees</td>
      <td>USD\tUnited States dollar</td>
      <td>4.364450e+05</td>
      <td>Weekly</td>
      <td>Bash/Shell;HTML/CSS;Java;JavaScript;Node.js;Py...</td>
      <td>Bash/Shell;Haskell;HTML/CSS;Java;JavaScript;No...</td>
      <td>MariaDB;MySQL;SQLite</td>
      <td>MariaDB;MySQL;SQLite</td>
      <td>Microsoft Azure</td>
      <td>Microsoft Azure</td>
      <td>Flask</td>
      <td>Express;Flask;React.js;Svelte</td>
      <td>...</td>
      <td>NaN</td>
      <td>Git</td>
      <td>Docker;Git</td>
      <td>IntelliJ;Visual Studio Code</td>
      <td>IntelliJ;Visual Studio;Visual Studio Code</td>
      <td>MacOS</td>
      <td>Visit Stack Overflow;Google it;Do other work a...</td>
      <td>Stack Overflow;Stack Exchange;Stack Overflow f...</td>
      <td>Multiple times per day</td>
      <td>True</td>
      <td>Daily or almost daily</td>
      <td>Yes, somewhat</td>
      <td>Yes</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Bisexual</td>
      <td>White or of European descent</td>
      <td>I am blind / have difficulty seeing</td>
      <td>I have a concentration and/or memory disorder ...</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>21822250.0</td>
      <td>Visit Stack Overflow;Google it;Do other work a...</td>
    </tr>
    <tr>
      <th>28791</th>
      <td>28792</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>INDIA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>35 - 44 years</td>
      <td>Coding Bootcamp;Other online resources (ex: vi...</td>
      <td>11</td>
      <td>9</td>
      <td>Developer, desktop or enterprise applications;...</td>
      <td>100 to 499 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>2.000000e+07</td>
      <td>Yearly</td>
      <td>C#;C++;Groovy;HTML/CSS;Java;JavaScript;Node.js...</td>
      <td>Ruby;Swift</td>
      <td>Microsoft SQL Server;MySQL;Oracle;PostgreSQL;S...</td>
      <td>MongoDB</td>
      <td>AWS;DigitalOcean;Heroku</td>
      <td>IBM Cloud or Watson;Microsoft Azure</td>
      <td>Angular.js;Drupal;Laravel;Ruby on Rails;Symfony</td>
      <td>Angular;ASP.NET</td>
      <td>...</td>
      <td>.NET Framework</td>
      <td>Git</td>
      <td>Chef;Docker;Kubernetes;Puppet</td>
      <td>Android Studio;Atom;Eclipse;IPython/Jupyter;Ne...</td>
      <td>Visual Studio Code</td>
      <td>MacOS</td>
      <td>Visit Stack Overflow;Google it;Visit another d...</td>
      <td>Stack Overflow;Stack Exchange;Stack Overflow f...</td>
      <td>A few times per month or weekly</td>
      <td>True</td>
      <td>A few times per month or weekly</td>
      <td>Neutral</td>
      <td>Yes</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>20000000.0</td>
      <td>Visit Stack Overflow;Google it;Visit another d...</td>
    </tr>
    <tr>
      <th>12700</th>
      <td>12701</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>INDIA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>25 - 34 years</td>
      <td>Online Forum</td>
      <td>5</td>
      <td>5</td>
      <td>Developer, full-stack</td>
      <td>100 to 499 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>1.600000e+06</td>
      <td>Monthly</td>
      <td>JavaScript</td>
      <td>JavaScript</td>
      <td>MongoDB;MySQL;PostgreSQL</td>
      <td>MongoDB;MySQL;PostgreSQL</td>
      <td>AWS;Heroku</td>
      <td>AWS;Heroku</td>
      <td>React.js</td>
      <td>React.js</td>
      <td>...</td>
      <td>NaN</td>
      <td>Git</td>
      <td>Git</td>
      <td>Eclipse;Visual Studio Code</td>
      <td>Eclipse;Visual Studio Code</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Google it;Visit another d...</td>
      <td>Stack Exchange</td>
      <td>A few times per week</td>
      <td>True</td>
      <td>A few times per week</td>
      <td>Neutral</td>
      <td>Yes</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>South Asian</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>19200000.0</td>
      <td>Visit Stack Overflow;Google it;Visit another d...</td>
    </tr>
    <tr>
      <th>9608</th>
      <td>9609</td>
      <td>I am not primarily a developer, but I write co...</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>New York</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>18 - 24 years</td>
      <td>School</td>
      <td>25</td>
      <td>21</td>
      <td>Senior Executive (C-Suite, VP, etc.)</td>
      <td>20 to 99 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>3.500000e+05</td>
      <td>Weekly</td>
      <td>Bash/Shell;Go;HTML/CSS;Java;JavaScript;Kotlin;...</td>
      <td>NaN</td>
      <td>Elasticsearch;IBM DB2;MariaDB;MongoDB;MySQL;Or...</td>
      <td>NaN</td>
      <td>AWS;DigitalOcean</td>
      <td>NaN</td>
      <td>Angular;jQuery;Spring</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>Git;Kubernetes</td>
      <td>NaN</td>
      <td>Android Studio;IntelliJ;Notepad++;PHPStorm;Vim...</td>
      <td>NaN</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Google it</td>
      <td>Stack Overflow</td>
      <td>Less than once per month or monthly</td>
      <td>False</td>
      <td>NaN</td>
      <td>Neutral</td>
      <td>Yes</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>17500000.0</td>
      <td>Call a coworker or friend;Google it Stack Over...</td>
    </tr>
    <tr>
      <th>5305</th>
      <td>5306</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>New Jersey</td>
      <td>NaN</td>
      <td>Professional degree (JD, MD, etc.)</td>
      <td>11 - 17 years</td>
      <td>Friend or family member;Books / Physical media</td>
      <td>25</td>
      <td>5</td>
      <td>Developer, full-stack;DevOps specialist</td>
      <td>Just me - I am a freelancer, sole proprietor, ...</td>
      <td>USD\tUnited States dollar</td>
      <td>3.000000e+05</td>
      <td>Weekly</td>
      <td>Python</td>
      <td>Python;Rust;SQL</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>AWS;Google Cloud Platform</td>
      <td>NaN</td>
      <td>Flask</td>
      <td>Django</td>
      <td>...</td>
      <td>NaN</td>
      <td>Ansible;Docker;Git;Terraform</td>
      <td>Docker;Git</td>
      <td>Vim</td>
      <td>Vim</td>
      <td>Linux-based</td>
      <td>Other (please specify):</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>Yes, somewhat</td>
      <td>Yes</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>NaN</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Too long</td>
      <td>Easy</td>
      <td>15000000.0</td>
      <td>Other (please specify): Stack Overflow;Stack E...</td>
    </tr>
    <tr>
      <th>12903</th>
      <td>12904</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>SERBIA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>6</td>
      <td>1</td>
      <td>Developer, front-end;Developer, full-stack;Dev...</td>
      <td>100 to 499 employees</td>
      <td>EUR European Euro</td>
      <td>1.111000e+06</td>
      <td>Monthly</td>
      <td>C#;JavaScript;Node.js;Python</td>
      <td>C#;Python</td>
      <td>MySQL;PostgreSQL</td>
      <td>MySQL;PostgreSQL</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Angular;ASP.NET;ASP.NET Core ;Django;jQuery;Re...</td>
      <td>Angular;ASP.NET Core ;Django;React.js</td>
      <td>...</td>
      <td>.NET Core / .NET 5</td>
      <td>Docker;Git</td>
      <td>Docker;Git</td>
      <td>PyCharm;Visual Studio;Visual Studio Code</td>
      <td>PyCharm;Visual Studio;Visual Studio Code</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Google it;Watch help / tu...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>False</td>
      <td>NaN</td>
      <td>Neutral</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Too long</td>
      <td>Neither easy nor difficult</td>
      <td>14411628.0</td>
      <td>Visit Stack Overflow;Google it;Watch help / tu...</td>
    </tr>
    <tr>
      <th>66488</th>
      <td>66489</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>Washington</td>
      <td>NaN</td>
      <td>Some college/university study without earning ...</td>
      <td>18 - 24 years</td>
      <td>School;Online Courses or Certification;Books /...</td>
      <td>5</td>
      <td>3</td>
      <td>Developer, desktop or enterprise applications;...</td>
      <td>20 to 99 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>2.550000e+05</td>
      <td>Weekly</td>
      <td>Bash/Shell;Go;HTML/CSS;Java;JavaScript;Kotlin;...</td>
      <td>Node.js;SQL;TypeScript</td>
      <td>DynamoDB;Elasticsearch;Firebase;MySQL;PostgreS...</td>
      <td>DynamoDB;Redis</td>
      <td>AWS;Google Cloud Platform</td>
      <td>AWS</td>
      <td>Express;React.js;Spring</td>
      <td>Express;React.js</td>
      <td>...</td>
      <td>NumPy;Pandas</td>
      <td>Docker;Git;Yarn</td>
      <td>Git</td>
      <td>Atom;IntelliJ;PyCharm;Sublime Text;Visual Stud...</td>
      <td>Visual Studio Code</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Google it;Meditate</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>No, not really</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>12750000.0</td>
      <td>Call a coworker or friend;Google it;Meditate S...</td>
    </tr>
    <tr>
      <th>7205</th>
      <td>7206</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>South Carolina</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>5 - 10 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>30</td>
      <td>20</td>
      <td>Developer, front-end;Developer, desktop or ent...</td>
      <td>Just me - I am a freelancer, sole proprietor, ...</td>
      <td>USD\tUnited States dollar</td>
      <td>2.500000e+05</td>
      <td>Weekly</td>
      <td>Bash/Shell;C#;HTML/CSS;JavaScript;PHP;PowerShe...</td>
      <td>Bash/Shell;C#;HTML/CSS;JavaScript;SQL</td>
      <td>Microsoft SQL Server;MySQL;Oracle</td>
      <td>Microsoft SQL Server;PostgreSQL</td>
      <td>Microsoft Azure</td>
      <td>Microsoft Azure</td>
      <td>ASP.NET;ASP.NET Core ;jQuery</td>
      <td>Angular;ASP.NET;ASP.NET Core ;jQuery</td>
      <td>...</td>
      <td>.NET Framework;.NET Core / .NET 5</td>
      <td>Git</td>
      <td>NaN</td>
      <td>Notepad++;Visual Studio</td>
      <td>Notepad++;Visual Studio;Visual Studio Code</td>
      <td>Windows</td>
      <td>Go for a walk or other physical activity;Googl...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per month or weekly</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>Yes, somewhat</td>
      <td>Yes</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>12500000.0</td>
      <td>Go for a walk or other physical activity;Googl...</td>
    </tr>
    <tr>
      <th>47563</th>
      <td>47564</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>Colorado</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Books / Physical media</td>
      <td>24</td>
      <td>13</td>
      <td>Developer, front-end</td>
      <td>10,000 or more employees</td>
      <td>USD\tUnited States dollar</td>
      <td>2.500000e+05</td>
      <td>Weekly</td>
      <td>Go;HTML/CSS;JavaScript;Python;TypeScript</td>
      <td>HTML/CSS;JavaScript;Python;Rust;TypeScript</td>
      <td>PostgreSQL</td>
      <td>PostgreSQL</td>
      <td>AWS</td>
      <td>NaN</td>
      <td>React.js;Vue.js</td>
      <td>React.js;Vue.js</td>
      <td>...</td>
      <td>NaN</td>
      <td>Docker;Git;Kubernetes;Yarn</td>
      <td>Git;Yarn</td>
      <td>Visual Studio Code</td>
      <td>Visual Studio Code</td>
      <td>MacOS</td>
      <td>Go for a walk or other physical activity;Googl...</td>
      <td>Stack Overflow</td>
      <td>A few times per month or weekly</td>
      <td>True</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>Neutral</td>
      <td>No</td>
      <td>35-44 years old</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>None of the above</td>
      <td>I have an anxiety disorder</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>12500000.0</td>
      <td>Go for a walk or other physical activity;Googl...</td>
    </tr>
    <tr>
      <th>3733</th>
      <td>3734</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>Virginia</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Friend or family member</td>
      <td>28</td>
      <td>19</td>
      <td>Developer, back-end</td>
      <td>Just me - I am a freelancer, sole proprietor, ...</td>
      <td>USD\tUnited States dollar</td>
      <td>2.250000e+05</td>
      <td>Weekly</td>
      <td>Bash/Shell;Groovy;HTML/CSS;Java;JavaScript;Nod...</td>
      <td>Bash/Shell;Groovy;HTML/CSS;Java;JavaScript;Nod...</td>
      <td>MariaDB;MongoDB;Oracle</td>
      <td>MariaDB;MongoDB;PostgreSQL</td>
      <td>AWS</td>
      <td>AWS</td>
      <td>Spring</td>
      <td>React.js;Spring;Vue.js</td>
      <td>...</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>Docker;Git</td>
      <td>Eclipse;IntelliJ;Visual Studio Code</td>
      <td>IntelliJ</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>No, not really</td>
      <td>No</td>
      <td>35-44 years old</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>11250000.0</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
    </tr>
    <tr>
      <th>33255</th>
      <td>33256</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>Florida</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>School;Other (please specify):;Books / Physica...</td>
      <td>37</td>
      <td>33</td>
      <td>Developer, mobile;Developer, front-end;Develop...</td>
      <td>100 to 499 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>2.250000e+05</td>
      <td>Weekly</td>
      <td>Bash/Shell;C;C#;C++;Go;HTML/CSS;Java;JavaScrip...</td>
      <td>Bash/Shell;C;Go;HTML/CSS;Kotlin;Node.js;TypeSc...</td>
      <td>DynamoDB;Elasticsearch;Firebase;Microsoft SQL ...</td>
      <td>Elasticsearch;Microsoft SQL Server;Redis</td>
      <td>AWS;DigitalOcean;Google Cloud Platform;Microso...</td>
      <td>AWS;DigitalOcean;Microsoft Azure</td>
      <td>ASP.NET;ASP.NET Core ;Express;jQuery;Spring;Vu...</td>
      <td>Express;jQuery;Svelte;Vue.js</td>
      <td>...</td>
      <td>NaN</td>
      <td>Docker;Git;Kubernetes;Yarn</td>
      <td>Docker;Git;Kubernetes;Yarn</td>
      <td>Eclipse;IntelliJ;Notepad++;Vim;Visual Studio;V...</td>
      <td>Vim;Visual Studio Code</td>
      <td>MacOS</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>False</td>
      <td>NaN</td>
      <td>Neutral</td>
      <td>Yes</td>
      <td>55-64 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Too long</td>
      <td>Easy</td>
      <td>11250000.0</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
    </tr>
    <tr>
      <th>35779</th>
      <td>35780</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>Pennsylvania</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>18 - 24 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>13</td>
      <td>13</td>
      <td>Developer, full-stack</td>
      <td>20 to 99 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>2.200000e+05</td>
      <td>Weekly</td>
      <td>Bash/Shell;HTML/CSS;JavaScript;Node.js;Ruby;SQL</td>
      <td>Bash/Shell;HTML/CSS;JavaScript;Node.js;Ruby;SQL</td>
      <td>DynamoDB;Elasticsearch;PostgreSQL;Redis</td>
      <td>DynamoDB;Elasticsearch;PostgreSQL;Redis</td>
      <td>AWS;Google Cloud Platform;Heroku</td>
      <td>AWS;Heroku</td>
      <td>Express;React.js;Ruby on Rails</td>
      <td>React.js;Ruby on Rails</td>
      <td>...</td>
      <td>React Native;TensorFlow</td>
      <td>Yarn</td>
      <td>Yarn</td>
      <td>Android Studio;TextMate;Visual Studio Code;Xcode</td>
      <td>Android Studio;Visual Studio Code</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Multiple times per day</td>
      <td>False</td>
      <td>NaN</td>
      <td>No, not really</td>
      <td>No</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>11000000.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>7904</th>
      <td>7905</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>Washington</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>18 - 24 years</td>
      <td>School;Books / Physical media</td>
      <td>11</td>
      <td>7</td>
      <td>Developer, mobile</td>
      <td>5,000 to 9,999 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>2.100000e+05</td>
      <td>Weekly</td>
      <td>Bash/Shell;C++;Objective-C;Swift</td>
      <td>Objective-C;Swift</td>
      <td>SQLite</td>
      <td>SQLite</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>Git</td>
      <td>Git</td>
      <td>Sublime Text;Vim;Visual Studio Code;Xcode</td>
      <td>Sublime Text;Vim;Visual Studio Code;Xcode</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Go for a walk or oth...</td>
      <td>Stack Overflow;Stack Overflow for Teams (priva...</td>
      <td>Multiple times per day</td>
      <td>True</td>
      <td>A few times per month or weekly</td>
      <td>Neutral</td>
      <td>Yes</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>10500000.0</td>
      <td>Call a coworker or friend;Go for a walk or oth...</td>
    </tr>
    <tr>
      <th>10372</th>
      <td>10373</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>Connecticut</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>5 - 10 years</td>
      <td>School;Books / Physical media</td>
      <td>35</td>
      <td>21</td>
      <td>Developer, front-end;Developer, full-stack</td>
      <td>10,000 or more employees</td>
      <td>USD\tUnited States dollar</td>
      <td>2.070000e+05</td>
      <td>Weekly</td>
      <td>HTML/CSS;Java;JavaScript;Node.js;SQL;TypeScript</td>
      <td>Java;Node.js;TypeScript</td>
      <td>Microsoft SQL Server;PostgreSQL</td>
      <td>NaN</td>
      <td>AWS</td>
      <td>NaN</td>
      <td>Angular</td>
      <td>Angular</td>
      <td>...</td>
      <td>NaN</td>
      <td>Docker</td>
      <td>Docker</td>
      <td>IntelliJ</td>
      <td>IntelliJ;Visual Studio Code</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Go for a walk or oth...</td>
      <td>Stack Overflow</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>A few times per month or weekly</td>
      <td>Yes, somewhat</td>
      <td>Yes</td>
      <td>45-54 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual;Prefer to self-describe:</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>Or, in your own words:</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>10350000.0</td>
      <td>Call a coworker or friend;Go for a walk or oth...</td>
    </tr>
    <tr>
      <th>9189</th>
      <td>9190</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>Washington</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>5 - 10 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>35</td>
      <td>24</td>
      <td>Developer, back-end;Engineering manager</td>
      <td>10,000 or more employees</td>
      <td>USD\tUnited States dollar</td>
      <td>8.500000e+05</td>
      <td>Monthly</td>
      <td>Bash/Shell;Go;Java;Kotlin;Node.js;TypeScript</td>
      <td>Bash/Shell;Go;Kotlin;Node.js;TypeScript</td>
      <td>MariaDB;SQLite</td>
      <td>MariaDB;SQLite</td>
      <td>AWS;Google Cloud Platform;Microsoft Azure</td>
      <td>AWS;Google Cloud Platform;Microsoft Azure</td>
      <td>Express;jQuery</td>
      <td>Express;jQuery</td>
      <td>...</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>Git</td>
      <td>Android Studio;IntelliJ;RStudio;Visual Studio;...</td>
      <td>Android Studio;IntelliJ;Visual Studio;Visual S...</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Go for a walk or oth...</td>
      <td>Stack Overflow</td>
      <td>A few times per month or weekly</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>No, not really</td>
      <td>Yes</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent;Southeast Asian</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>10200000.0</td>
      <td>Call a coworker or friend;Go for a walk or oth...</td>
    </tr>
    <tr>
      <th>20908</th>
      <td>20909</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>Texas</td>
      <td>NaN</td>
      <td>Some college/university study without earning ...</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>20</td>
      <td>20</td>
      <td>Developer, front-end;Developer, desktop or ent...</td>
      <td>5,000 to 9,999 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>2.000000e+05</td>
      <td>Weekly</td>
      <td>C#;HTML/CSS;JavaScript;PowerShell;Python;SQL;T...</td>
      <td>C#;HTML/CSS;JavaScript;PowerShell;Python;SQL;T...</td>
      <td>Microsoft SQL Server;MySQL;Redis</td>
      <td>Microsoft SQL Server;MySQL;Redis</td>
      <td>Microsoft Azure</td>
      <td>Microsoft Azure</td>
      <td>Angular;ASP.NET Core ;React.js;Vue.js</td>
      <td>Angular;ASP.NET Core ;React.js;Vue.js</td>
      <td>...</td>
      <td>.NET Core / .NET 5</td>
      <td>Docker;Git;Kubernetes</td>
      <td>Docker;Git;Kubernetes;Unity 3D</td>
      <td>Notepad++;Visual Studio;Visual Studio Code</td>
      <td>Notepad++;Visual Studio;Visual Studio Code</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Do other work and come ba...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>True</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>Yes, definitely</td>
      <td>No</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>Or, in your own words:</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>10000000.0</td>
      <td>Visit Stack Overflow;Do other work and come ba...</td>
    </tr>
    <tr>
      <th>52070</th>
      <td>52071</td>
      <td>I am not primarily a developer, but I write co...</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>California</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>5 - 10 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>20</td>
      <td>10</td>
      <td>Developer, front-end;Data scientist or machine...</td>
      <td>1,000 to 4,999 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>2.000000e+05</td>
      <td>Weekly</td>
      <td>Bash/Shell;C++;JavaScript;Python;Rust</td>
      <td>Bash/Shell;JavaScript;Python;Rust</td>
      <td>SQLite</td>
      <td>NaN</td>
      <td>AWS</td>
      <td>NaN</td>
      <td>Angular.js;jQuery</td>
      <td>jQuery</td>
      <td>...</td>
      <td>NumPy;Pandas;TensorFlow;Torch/PyTorch</td>
      <td>Docker;Git</td>
      <td>Docker;Git</td>
      <td>Atom;Vim;Visual Studio Code</td>
      <td>Atom;Vim;Visual Studio Code</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>A few times per week</td>
      <td>Yes, somewhat</td>
      <td>Yes</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Too short</td>
      <td>Easy</td>
      <td>10000000.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>53028</th>
      <td>53029</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>Missouri</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>5 - 10 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>20</td>
      <td>15</td>
      <td>Developer, full-stack</td>
      <td>10,000 or more employees</td>
      <td>USD\tUnited States dollar</td>
      <td>2.000000e+05</td>
      <td>Weekly</td>
      <td>C;C++;Go;HTML/CSS;Java;JavaScript;Node.js;Pyth...</td>
      <td>C;C++;Go;HTML/CSS;Java;JavaScript;Node.js;Pyth...</td>
      <td>DynamoDB;Elasticsearch;MySQL;Oracle;PostgreSQL...</td>
      <td>Cassandra;DynamoDB;Elasticsearch;PostgreSQL;Redis</td>
      <td>AWS;DigitalOcean;Google Cloud Platform;Heroku;...</td>
      <td>AWS;Google Cloud Platform</td>
      <td>Express;React.js</td>
      <td>Express</td>
      <td>...</td>
      <td>TensorFlow</td>
      <td>Docker;Flow;Git</td>
      <td>Terraform;Unreal Engine</td>
      <td>IntelliJ;Vim;Visual Studio Code</td>
      <td>Vim</td>
      <td>MacOS</td>
      <td>Go for a walk or other physical activity;Do ot...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>Neutral</td>
      <td>Yes</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>10000000.0</td>
      <td>Go for a walk or other physical activity;Do ot...</td>
    </tr>
    <tr>
      <th>64111</th>
      <td>64112</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>California</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>12</td>
      <td>7</td>
      <td>Developer, back-end</td>
      <td>20 to 99 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>2.000000e+05</td>
      <td>Weekly</td>
      <td>Go;Java</td>
      <td>Go</td>
      <td>PostgreSQL</td>
      <td>PostgreSQL</td>
      <td>Google Cloud Platform</td>
      <td>Google Cloud Platform</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>Docker;Git;Kubernetes</td>
      <td>Docker;Git;Kubernetes</td>
      <td>IntelliJ;Visual Studio Code</td>
      <td>IntelliJ;Visual Studio Code</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>No, not really</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Too short</td>
      <td>Easy</td>
      <td>10000000.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>66323</th>
      <td>66324</td>
      <td>I am not primarily a developer, but I write co...</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>Indiana</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>5 - 10 years</td>
      <td>Coding Bootcamp;School</td>
      <td>33</td>
      <td>23</td>
      <td>Developer, embedded applications or devices</td>
      <td>10,000 or more employees</td>
      <td>USD\tUnited States dollar</td>
      <td>2.000000e+05</td>
      <td>Weekly</td>
      <td>C</td>
      <td>C;Python</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>Git</td>
      <td>Git</td>
      <td>Eclipse;Notepad++</td>
      <td>Eclipse;Notepad++</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Google it</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per month or weekly</td>
      <td>False</td>
      <td>NaN</td>
      <td>No, not at all</td>
      <td>Yes</td>
      <td>45-54 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>10000000.0</td>
      <td>Visit Stack Overflow;Google it Stack Overflow;...</td>
    </tr>
    <tr>
      <th>82156</th>
      <td>82157</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>IRAN, ISLAMIC REPUBLIC OF...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>25 - 34 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>NaN</td>
      <td>5</td>
      <td>Developer, back-end</td>
      <td>10 to 19 employees</td>
      <td>IRR\tIranian rial</td>
      <td>3.500000e+10</td>
      <td>Monthly</td>
      <td>HTML/CSS;JavaScript;PHP</td>
      <td>HTML/CSS;JavaScript;PHP;SQL</td>
      <td>MySQL</td>
      <td>MySQL</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>jQuery</td>
      <td>Angular;Django;jQuery;Laravel;Vue.js</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Android Studio;PHPStorm</td>
      <td>PHPStorm</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>A few times per week</td>
      <td>Yes, definitely</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Woman</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Middle Eastern</td>
      <td>NaN</td>
      <td>None of the above</td>
      <td>Too long</td>
      <td>Neither easy nor difficult</td>
      <td>9975060.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>7134</th>
      <td>7135</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>California</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>School;Friend or family member;Online Courses ...</td>
      <td>13</td>
      <td>9</td>
      <td>Developer, full-stack</td>
      <td>2 to 9 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>1.900000e+05</td>
      <td>Weekly</td>
      <td>Bash/Shell;JavaScript;Node.js;Rust;SQL;Swift;T...</td>
      <td>Node.js;Rust;SQL;TypeScript</td>
      <td>Microsoft SQL Server;MongoDB;MySQL;PostgreSQL;...</td>
      <td>PostgreSQL;Redis</td>
      <td>AWS;Google Cloud Platform;Microsoft Azure</td>
      <td>AWS;Google Cloud Platform</td>
      <td>Angular;Angular.js</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>Docker;Git;Kubernetes</td>
      <td>Docker;Git;Kubernetes</td>
      <td>IntelliJ;Webstorm;Xcode</td>
      <td>IntelliJ;Neovim;Webstorm</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>Multiple times per day</td>
      <td>False</td>
      <td>NaN</td>
      <td>No, not really</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man;Non-binary, genderqueer, or gender non-con...</td>
      <td>Prefer not to say</td>
      <td>Bisexual;Queer</td>
      <td>White or of European descent;Southeast Asian;B...</td>
      <td>None of the above</td>
      <td>I have a concentration and/or memory disorder ...</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>9500000.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>60701</th>
      <td>60702</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>Colorado</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Coding Bootcamp;School;Friend or family member...</td>
      <td>14</td>
      <td>11</td>
      <td>Engineer, data;Data scientist or machine learn...</td>
      <td>100 to 499 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>1.900000e+05</td>
      <td>Weekly</td>
      <td>Bash/Shell;Java;Python;Ruby;SQL</td>
      <td>Python;Scala;SQL</td>
      <td>DynamoDB;PostgreSQL</td>
      <td>PostgreSQL</td>
      <td>AWS</td>
      <td>AWS</td>
      <td>Flask;Ruby on Rails</td>
      <td>Flask;Ruby on Rails</td>
      <td>...</td>
      <td>Apache Spark;NumPy;Pandas;TensorFlow;Torch/PyT...</td>
      <td>Docker;Git;Kubernetes;Yarn</td>
      <td>Docker;Git;Kubernetes;Terraform</td>
      <td>IPython/Jupyter;Vim</td>
      <td>IPython/Jupyter;Vim</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>Yes, somewhat</td>
      <td>Yes</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>NaN</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>9500000.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
  </tbody>
</table>
<p>25 rows × 49 columns</p>
</div>




```python
datos.nsmallest(25, "CONVERTEDCOMPYEARLY")
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>RESPONSEID</th>
      <th>MAINBRANCH</th>
      <th>EMPLOYMENT</th>
      <th>COUNTRY</th>
      <th>USSTATE</th>
      <th>UKCOUNTRY</th>
      <th>EDLEVEL</th>
      <th>AGE1STCODE</th>
      <th>LEARNCODE</th>
      <th>YEARSCODE</th>
      <th>YEARSCODEPRO</th>
      <th>DEVTYPE</th>
      <th>ORGSIZE</th>
      <th>CURRENCY</th>
      <th>COMPTOTAL</th>
      <th>COMPFREQ</th>
      <th>LANGUAGEHAVEWORKEDWITH</th>
      <th>LANGUAGEWANTTOWORKWITH</th>
      <th>DATABASEHAVEWORKEDWITH</th>
      <th>DATABASEWANTTOWORKWITH</th>
      <th>PLATFORMHAVEWORKEDWITH</th>
      <th>PLATFORMWANTTOWORKWITH</th>
      <th>WEBFRAMEHAVEWORKEDWITH</th>
      <th>WEBFRAMEWANTTOWORKWITH</th>
      <th>...</th>
      <th>MISCTECHWANTTOWORKWITH</th>
      <th>TOOLSTECHHAVEWORKEDWITH</th>
      <th>TOOLSTECHWANTTOWORKWITH</th>
      <th>NEWCOLLABTOOLSHAVEWORKEDWITH</th>
      <th>NEWCOLLABTOOLSWANTTOWORKWITH</th>
      <th>OPSYS</th>
      <th>NEWSTUCK</th>
      <th>NEWSOSITES</th>
      <th>SOVISITFREQ</th>
      <th>SOACCOUNT</th>
      <th>SOPARTFREQ</th>
      <th>SOCOMM</th>
      <th>NEWOTHERCOMMS</th>
      <th>AGE</th>
      <th>GENDER</th>
      <th>TRANS</th>
      <th>SEXUALITY</th>
      <th>ETHNICITY</th>
      <th>ACCESSIBILITY</th>
      <th>MENTALHEALTH</th>
      <th>SURVEYLENGTH</th>
      <th>SURVEYEASE</th>
      <th>CONVERTEDCOMPYEARLY</th>
      <th>AYUDA</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1924</th>
      <td>1925</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>Pennsylvania</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>11 - 17 years</td>
      <td>School;Other (please specify):</td>
      <td>30</td>
      <td>25</td>
      <td>Developer, mobile;Developer, front-end;Develop...</td>
      <td>1,000 to 4,999 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>1.0</td>
      <td>Yearly</td>
      <td>C#;HTML/CSS;JavaScript;PowerShell;SQL</td>
      <td>C#;HTML/CSS;JavaScript;PowerShell;SQL</td>
      <td>Microsoft SQL Server</td>
      <td>Microsoft SQL Server</td>
      <td>AWS;Microsoft Azure</td>
      <td>NaN</td>
      <td>Angular;Angular.js;ASP.NET;ASP.NET Core ;jQuery</td>
      <td>Angular;Angular.js;ASP.NET;ASP.NET Core ;jQuery</td>
      <td>...</td>
      <td>.NET Framework;.NET Core / .NET 5</td>
      <td>Docker;Git;Kubernetes</td>
      <td>Docker;Git;Kubernetes</td>
      <td>Notepad++;Visual Studio;Visual Studio Code</td>
      <td>Notepad++;Visual Studio;Visual Studio Code</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>True</td>
      <td>A few times per week</td>
      <td>Yes, definitely</td>
      <td>No</td>
      <td>45-54 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>NaN</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Too long</td>
      <td>Neither easy nor difficult</td>
      <td>1.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>24285</th>
      <td>24286</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>California</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Books / Physical media</td>
      <td>16</td>
      <td>9</td>
      <td>Other (please specify):;Data scientist or mach...</td>
      <td>2 to 9 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>1.0</td>
      <td>Yearly</td>
      <td>Python;SQL</td>
      <td>Python</td>
      <td>PostgreSQL;Redis</td>
      <td>PostgreSQL;Redis</td>
      <td>AWS</td>
      <td>AWS</td>
      <td>Django;Flask</td>
      <td>Django;Flask</td>
      <td>...</td>
      <td>NumPy;Pandas;TensorFlow</td>
      <td>Docker;Git;Terraform</td>
      <td>Docker;Git;Terraform</td>
      <td>IPython/Jupyter;PyCharm</td>
      <td>IPython/Jupyter;PyCharm</td>
      <td>MacOS</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>True</td>
      <td>A few times per week</td>
      <td>Yes, somewhat</td>
      <td>Yes</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Prefer to self-describe:</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>1.0</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
    </tr>
    <tr>
      <th>46464</th>
      <td>46465</td>
      <td>I am not primarily a developer, but I write co...</td>
      <td>Employed full-time</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>Washington</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Coding Bootcamp;Other online resources (ex: vi...</td>
      <td>27</td>
      <td>12</td>
      <td>Engineer, data;Data scientist or machine learn...</td>
      <td>10 to 19 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>1.0</td>
      <td>Yearly</td>
      <td>Perl;Python</td>
      <td>JavaScript;Node.js;Python</td>
      <td>SQLite</td>
      <td>NaN</td>
      <td>Google Cloud Platform</td>
      <td>NaN</td>
      <td>Flask</td>
      <td>Flask</td>
      <td>...</td>
      <td>NaN</td>
      <td>Git</td>
      <td>Git</td>
      <td>Android Studio;IntelliJ;PyCharm;Sublime Text</td>
      <td>PyCharm;Sublime Text</td>
      <td>MacOS</td>
      <td>Go for a walk or other physical activity;Do ot...</td>
      <td>Stack Overflow</td>
      <td>Less than once per month or monthly</td>
      <td>False</td>
      <td>NaN</td>
      <td>No, not at all</td>
      <td>No</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>Too long</td>
      <td>Easy</td>
      <td>1.0</td>
      <td>Go for a walk or other physical activity;Do ot...</td>
    </tr>
    <tr>
      <th>15163</th>
      <td>15164</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>CHINA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Primary/elementary school</td>
      <td>Younger than 5 years</td>
      <td>Books / Physical media</td>
      <td>5</td>
      <td>1</td>
      <td>Academic researcher</td>
      <td>2 to 9 employees</td>
      <td>CNY\tChinese Yuan Renminbi</td>
      <td>11.0</td>
      <td>Yearly</td>
      <td>Objective-C</td>
      <td>NaN</td>
      <td>MySQL</td>
      <td>NaN</td>
      <td>Microsoft Azure</td>
      <td>NaN</td>
      <td>Vue.js</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>MacOS</td>
      <td>Google it</td>
      <td>Stack Overflow for Teams (private knowledge sh...</td>
      <td>Less than once per month or monthly</td>
      <td>True</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>No, not at all</td>
      <td>Yes</td>
      <td>35-44 years old</td>
      <td>Woman</td>
      <td>Yes</td>
      <td>Bisexual</td>
      <td>Black or of African descent</td>
      <td>I am blind / have difficulty seeing</td>
      <td>I have a concentration and/or memory disorder ...</td>
      <td>Too short</td>
      <td>Easy</td>
      <td>2.0</td>
      <td>Google it Stack Overflow for Teams (private kn...</td>
    </tr>
    <tr>
      <th>56790</th>
      <td>56791</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>TAIWAN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>11 - 17 years</td>
      <td>School</td>
      <td>12</td>
      <td>2</td>
      <td>Developer, full-stack;Database administrator;S...</td>
      <td>100 to 499 employees</td>
      <td>TWD\tNew Taiwan dollar</td>
      <td>50.0</td>
      <td>Yearly</td>
      <td>HTML/CSS;JavaScript;Node.js;Python;SQL</td>
      <td>NaN</td>
      <td>MySQL;PostgreSQL;SQLite</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Django;jQuery</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>NaN</td>
      <td>PyCharm</td>
      <td>NaN</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>No, not really</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Woman</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>East Asian</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>2.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>22032</th>
      <td>22033</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>REPUBLIC OF KOREA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Associate degree (A.A., A.S., etc.)</td>
      <td>18 - 24 years</td>
      <td>Coding Bootcamp;Other online resources (ex: vi...</td>
      <td>5</td>
      <td>Less than 1 year</td>
      <td>Developer, front-end</td>
      <td>20 to 99 employees</td>
      <td>KRW\tSouth Korean won</td>
      <td>3800.0</td>
      <td>Yearly</td>
      <td>JavaScript;TypeScript</td>
      <td>JavaScript;TypeScript</td>
      <td>MySQL;PostgreSQL;Redis</td>
      <td>MySQL;PostgreSQL;Redis</td>
      <td>AWS;Google Cloud Platform</td>
      <td>AWS;Google Cloud Platform</td>
      <td>React.js</td>
      <td>React.js;Svelte;Vue.js</td>
      <td>...</td>
      <td>Flutter;Hadoop;React Native</td>
      <td>Docker;Git;Kubernetes;Yarn</td>
      <td>Deno;Docker;Git;Kubernetes;Yarn</td>
      <td>Visual Studio Code;Webstorm</td>
      <td>Visual Studio Code;Webstorm</td>
      <td>MacOS</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
      <td>Stack Overflow</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>NaN</td>
      <td>East Asian</td>
      <td>None of the above</td>
      <td>I have an anxiety disorder</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>3.0</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
    </tr>
    <tr>
      <th>59043</th>
      <td>59044</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>TAIWAN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>18 - 24 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>20</td>
      <td>NaN</td>
      <td>Developer, front-end</td>
      <td>100 to 499 employees</td>
      <td>TWD\tNew Taiwan dollar</td>
      <td>90.0</td>
      <td>Yearly</td>
      <td>HTML/CSS;JavaScript;Node.js;PowerShell;TypeScript</td>
      <td>HTML/CSS;JavaScript;Node.js;TypeScript</td>
      <td>Elasticsearch;Firebase;MongoDB;MySQL;Redis</td>
      <td>Firebase</td>
      <td>DigitalOcean;Microsoft Azure</td>
      <td>NaN</td>
      <td>Angular;Express</td>
      <td>Angular</td>
      <td>...</td>
      <td>NaN</td>
      <td>Ansible;Docker;Git</td>
      <td>Docker;Git</td>
      <td>IntelliJ;Notepad++;Vim;Visual Studio Code;Webs...</td>
      <td>IntelliJ;Notepad++;Vim;Visual Studio Code;Webs...</td>
      <td>MacOS</td>
      <td>Go for a walk or other physical activity;Googl...</td>
      <td>Stack Overflow</td>
      <td>Multiple times per day</td>
      <td>True</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Prefer not to say</td>
      <td>Southeast Asian</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>3.0</td>
      <td>Go for a walk or other physical activity;Googl...</td>
    </tr>
    <tr>
      <th>22453</th>
      <td>22454</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>JAPAN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Secondary school (e.g. American high school, G...</td>
      <td>5 - 10 years</td>
      <td>Other online resources (ex: videos, blogs, etc)</td>
      <td>Less than 1 year</td>
      <td>6</td>
      <td>Developer, full-stack</td>
      <td>20 to 99 employees</td>
      <td>JPY\tJapanese yen</td>
      <td>450.0</td>
      <td>Yearly</td>
      <td>C#;HTML/CSS;SQL;TypeScript</td>
      <td>C#;HTML/CSS;SQL;TypeScript</td>
      <td>Oracle</td>
      <td>Oracle</td>
      <td>AWS;Microsoft Azure</td>
      <td>AWS;Microsoft Azure</td>
      <td>Angular;ASP.NET Core</td>
      <td>Angular;ASP.NET Core</td>
      <td>...</td>
      <td>.NET Core / .NET 5</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Visual Studio;Visual Studio Code</td>
      <td>Visual Studio;Visual Studio Code</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Meditate</td>
      <td>Stack Overflow</td>
      <td>A few times per month or weekly</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>No, not at all</td>
      <td>No</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>NaN</td>
      <td>East Asian</td>
      <td>None of the above</td>
      <td>NaN</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>4.0</td>
      <td>Call a coworker or friend;Meditate Stack Overflow</td>
    </tr>
    <tr>
      <th>41440</th>
      <td>41441</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>UNITED STATES OF AMERICA</td>
      <td>California</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>18 - 24 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>10</td>
      <td>3</td>
      <td>Developer, mobile;Developer, full-stack</td>
      <td>Just me - I am a freelancer, sole proprietor, ...</td>
      <td>USD\tUnited States dollar</td>
      <td>5.0</td>
      <td>Yearly</td>
      <td>Java;JavaScript;Kotlin;Swift</td>
      <td>Kotlin;Swift</td>
      <td>SQLite</td>
      <td>DynamoDB;Firebase</td>
      <td>AWS</td>
      <td>AWS;Google Cloud Platform</td>
      <td>Angular;React.js</td>
      <td>Angular;React.js</td>
      <td>...</td>
      <td>React Native;TensorFlow</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Android Studio;Sublime Text;Visual Studio Code...</td>
      <td>Android Studio;Visual Studio Code;Webstorm;Xcode</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Do other work and come ba...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>True</td>
      <td>A few times per week</td>
      <td>Yes, somewhat</td>
      <td>Yes</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>East Asian</td>
      <td>NaN</td>
      <td>I have a concentration and/or memory disorder ...</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>5.0</td>
      <td>Visit Stack Overflow;Do other work and come ba...</td>
    </tr>
    <tr>
      <th>45141</th>
      <td>45142</td>
      <td>I am not primarily a developer, but I write co...</td>
      <td>Employed full-time</td>
      <td>CHINA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>12</td>
      <td>1</td>
      <td>Scientist</td>
      <td>1,000 to 4,999 employees</td>
      <td>CNY\tChinese Yuan Renminbi</td>
      <td>35.0</td>
      <td>Yearly</td>
      <td>C++;Java;Python;R;Scala;SQL</td>
      <td>C++;Python</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NumPy;Pandas;Torch/PyTorch</td>
      <td>Git</td>
      <td>Git</td>
      <td>IntelliJ;PyCharm;RStudio;Visual Studio;Visual ...</td>
      <td>Visual Studio Code</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Google it;Do other work a...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>A few times per month or weekly</td>
      <td>Yes, somewhat</td>
      <td>Yes</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>East Asian</td>
      <td>None of the above</td>
      <td>I have a mood or emotional disorder (e.g. depr...</td>
      <td>Too long</td>
      <td>Easy</td>
      <td>5.0</td>
      <td>Visit Stack Overflow;Google it;Do other work a...</td>
    </tr>
    <tr>
      <th>53306</th>
      <td>53307</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>JAPAN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Some college/university study without earning ...</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>25</td>
      <td>17</td>
      <td>Developer, mobile;Data scientist or machine le...</td>
      <td>10,000 or more employees</td>
      <td>JPY\tJapanese yen</td>
      <td>600.0</td>
      <td>Yearly</td>
      <td>Bash/Shell;HTML/CSS;Java;JavaScript;Kotlin;Nod...</td>
      <td>Bash/Shell;C#;HTML/CSS;Java;Kotlin;Python;SQL;...</td>
      <td>Firebase;MySQL;PostgreSQL;SQLite</td>
      <td>MariaDB;PostgreSQL;SQLite</td>
      <td>AWS</td>
      <td>AWS</td>
      <td>Angular;Express;Flask;Laravel;Spring;Vue.js</td>
      <td>Angular;ASP.NET Core ;FastAPI;Laravel</td>
      <td>...</td>
      <td>.NET Core / .NET 5;NumPy;Pandas;Torch/PyTorch</td>
      <td>Docker;Git</td>
      <td>Git;Unity 3D;Unreal Engine</td>
      <td>Android Studio;IntelliJ;IPython/Jupyter;PHPSto...</td>
      <td>Android Studio;IntelliJ;PHPStorm;PyCharm;Vim;V...</td>
      <td>Linux-based</td>
      <td>Visit Stack Overflow;Google it;Watch help / tu...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>False</td>
      <td>NaN</td>
      <td>Neutral</td>
      <td>No</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>East Asian</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>5.0</td>
      <td>Visit Stack Overflow;Google it;Watch help / tu...</td>
    </tr>
    <tr>
      <th>37761</th>
      <td>37762</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>SOUTH KOREA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>19</td>
      <td>14</td>
      <td>Developer, front-end</td>
      <td>500 to 999 employees</td>
      <td>KRW\tSouth Korean won</td>
      <td>7600.0</td>
      <td>Yearly</td>
      <td>HTML/CSS;JavaScript;Node.js;TypeScript</td>
      <td>HTML/CSS;JavaScript;Node.js;TypeScript</td>
      <td>MariaDB;MySQL</td>
      <td>MariaDB;MySQL</td>
      <td>Oracle Cloud Infrastructure</td>
      <td>AWS;Google Cloud Platform;Microsoft Azure;Orac...</td>
      <td>Express;jQuery;React.js;Vue.js</td>
      <td>Express;React.js;Svelte</td>
      <td>...</td>
      <td>NaN</td>
      <td>Git;Kubernetes;Yarn</td>
      <td>Git;Kubernetes;Yarn</td>
      <td>Visual Studio Code</td>
      <td>Vim;Visual Studio Code;Webstorm</td>
      <td>MacOS</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
      <td>Stack Overflow</td>
      <td>Multiple times per day</td>
      <td>True</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>No, not at all</td>
      <td>Yes</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>East Asian</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>NaN</td>
      <td>Difficult</td>
      <td>6.0</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
    </tr>
    <tr>
      <th>22162</th>
      <td>22163</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>TURKEY</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Something else</td>
      <td>35 - 44 years</td>
      <td>Online Forum</td>
      <td>1</td>
      <td>21</td>
      <td>Other (please specify):</td>
      <td>100 to 499 employees</td>
      <td>USD\tUnited States dollar</td>
      <td>10.0</td>
      <td>Yearly</td>
      <td>APL;Dart;JavaScript;PowerShell;Swift;TypeScript</td>
      <td>NaN</td>
      <td>Cassandra;SQLite</td>
      <td>NaN</td>
      <td>AWS;Google Cloud Platform</td>
      <td>NaN</td>
      <td>Angular;Angular.js</td>
      <td>NaN</td>
      <td>...</td>
      <td>.NET Core / .NET 5</td>
      <td>Ansible</td>
      <td>NaN</td>
      <td>Android Studio;PyCharm;TextMate;Vim</td>
      <td>Atom;Xcode</td>
      <td>Windows</td>
      <td>Google it;Meditate;Panic;Visit another develop...</td>
      <td>Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>Daily or almost daily</td>
      <td>No, not at all</td>
      <td>Yes</td>
      <td>35-44 years old</td>
      <td>Woman</td>
      <td>Yes</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent;South Asian</td>
      <td>I am unable to / find it difficult to type</td>
      <td>I have a mood or emotional disorder (e.g. depr...</td>
      <td>Too long</td>
      <td>Easy</td>
      <td>10.0</td>
      <td>Google it;Meditate;Panic;Visit another develop...</td>
    </tr>
    <tr>
      <th>12290</th>
      <td>12291</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>IRAN, ISLAMIC REPUBLIC OF...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Associate degree (A.A., A.S., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>10</td>
      <td>6</td>
      <td>Developer, full-stack;Developer, back-end;Engi...</td>
      <td>2 to 9 employees</td>
      <td>IRR\tIranian rial</td>
      <td>50000.0</td>
      <td>Monthly</td>
      <td>HTML/CSS;JavaScript;Node.js;PHP;SQL;TypeScript</td>
      <td>HTML/CSS;JavaScript;Node.js;PHP;Python;SQL;Typ...</td>
      <td>MySQL</td>
      <td>MongoDB;MySQL;PostgreSQL;Redis</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Angular;Express;jQuery;Laravel</td>
      <td>Express;jQuery;Laravel;Vue.js</td>
      <td>...</td>
      <td>NaN</td>
      <td>Git</td>
      <td>Git</td>
      <td>IntelliJ;Visual Studio Code</td>
      <td>IntelliJ;Visual Studio Code</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Google it;Watch help / tu...</td>
      <td>Stack Overflow</td>
      <td>Multiple times per day</td>
      <td>True</td>
      <td>Daily or almost daily</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent;Middle Eastern</td>
      <td>None of the above</td>
      <td>I have a concentration and/or memory disorder ...</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>12.0</td>
      <td>Visit Stack Overflow;Google it;Watch help / tu...</td>
    </tr>
    <tr>
      <th>16621</th>
      <td>16622</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>CHINA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Associate degree (A.A., A.S., etc.)</td>
      <td>18 - 24 years</td>
      <td>Coding Bootcamp;Other online resources (ex: vi...</td>
      <td>6</td>
      <td>3</td>
      <td>Developer, back-end</td>
      <td>500 to 999 employees</td>
      <td>CNY\tChinese Yuan Renminbi</td>
      <td>8.0</td>
      <td>Monthly</td>
      <td>Java;Rust</td>
      <td>Rust</td>
      <td>MySQL;Redis</td>
      <td>MySQL;Redis</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Vue.js</td>
      <td>Vue.js</td>
      <td>...</td>
      <td>Flutter</td>
      <td>Docker;Git;Yarn</td>
      <td>Docker;Git;Yarn</td>
      <td>IntelliJ;Vim;Visual Studio Code</td>
      <td>IntelliJ;Vim;Visual Studio Code</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>A few times per week</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>No, not at all</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>East Asian</td>
      <td>None of the above</td>
      <td>I have a concentration and/or memory disorder ...</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>12.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>18322</th>
      <td>18323</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>INDIA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Something else</td>
      <td>18 - 24 years</td>
      <td>Other online resources (ex: videos, blogs, etc)</td>
      <td>5</td>
      <td>3</td>
      <td>Developer, mobile;Other (please specify):</td>
      <td>20 to 99 employees</td>
      <td>INR\tIndian rupee</td>
      <td>60.0</td>
      <td>Monthly</td>
      <td>C;C++;Java;PHP</td>
      <td>JavaScript;TypeScript</td>
      <td>MySQL;SQLite</td>
      <td>Firebase</td>
      <td>Oracle Cloud Infrastructure</td>
      <td>AWS;Google Cloud Platform;Microsoft Azure</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Atom;Notepad++;Sublime Text</td>
      <td>Android Studio;Visual Studio Code;Xcode</td>
      <td>MacOS</td>
      <td>NaN</td>
      <td>Stack Overflow</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>NaN</td>
      <td>Yes, definitely</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>NaN</td>
      <td>Straight / Heterosexual</td>
      <td>NaN</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Too long</td>
      <td>NaN</td>
      <td>12.0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>33043</th>
      <td>33044</td>
      <td>I am a developer by profession</td>
      <td>Employed part-time</td>
      <td>LIBERIA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Secondary school (e.g. American high school, G...</td>
      <td>11 - 17 years</td>
      <td>Coding Bootcamp;Other online resources (ex: vi...</td>
      <td>5</td>
      <td>5</td>
      <td>Developer, desktop or enterprise applications;...</td>
      <td>500 to 999 employees</td>
      <td>LRD\tLiberian dollar</td>
      <td>136.0</td>
      <td>Monthly</td>
      <td>JavaScript;Python;Ruby;SQL;TypeScript;VBA</td>
      <td>NaN</td>
      <td>Microsoft SQL Server;MySQL;PostgreSQL;SQLite</td>
      <td>NaN</td>
      <td>DigitalOcean;Heroku</td>
      <td>NaN</td>
      <td>Angular;Angular.js;Django;Drupal;Flask;jQuery;...</td>
      <td>NaN</td>
      <td>...</td>
      <td>.NET Framework;.NET Core / .NET 5</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Android Studio;Atom;Eclipse;IPython/Jupyter;Su...</td>
      <td>NaN</td>
      <td>Linux-based</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>A few times per month or weekly</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Black or of African descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>12.0</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
    </tr>
    <tr>
      <th>33504</th>
      <td>33505</td>
      <td>I am not primarily a developer, but I write co...</td>
      <td>Employed full-time</td>
      <td>KENYA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>18 - 24 years</td>
      <td>School</td>
      <td>5</td>
      <td>2</td>
      <td>DevOps specialist</td>
      <td>100 to 499 employees</td>
      <td>KES\tKenyan shilling</td>
      <td>90.0</td>
      <td>Monthly</td>
      <td>Go</td>
      <td>Go;Rust</td>
      <td>Elasticsearch;MariaDB;MongoDB;PostgreSQL;Redis</td>
      <td>Elasticsearch;MariaDB;MongoDB;PostgreSQL;Redis</td>
      <td>AWS;Google Cloud Platform</td>
      <td>AWS;Google Cloud Platform</td>
      <td>Django;Vue.js</td>
      <td>Vue.js</td>
      <td>...</td>
      <td>NaN</td>
      <td>Ansible;Docker;Git;Kubernetes;Terraform;Yarn</td>
      <td>Ansible;Docker;Git;Kubernetes;Terraform;Yarn</td>
      <td>IntelliJ;Vim;Visual Studio Code</td>
      <td>IntelliJ;Vim;Visual Studio Code</td>
      <td>Linux-based</td>
      <td>Visit Stack Overflow;Google it</td>
      <td>Stack Overflow</td>
      <td>A few times per week</td>
      <td>True</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>12.0</td>
      <td>Visit Stack Overflow;Google it Stack Overflow</td>
    </tr>
    <tr>
      <th>33930</th>
      <td>33931</td>
      <td>I am a developer by profession</td>
      <td>Employed part-time</td>
      <td>HUNGARY</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>18 - 24 years</td>
      <td>School</td>
      <td>5</td>
      <td>3</td>
      <td>Developer, QA or test</td>
      <td>100 to 499 employees</td>
      <td>HUF\tHungarian forint</td>
      <td>400.0</td>
      <td>Monthly</td>
      <td>Python</td>
      <td>Python</td>
      <td>MySQL;Oracle;PostgreSQL</td>
      <td>MySQL;Oracle;PostgreSQL</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Django</td>
      <td>Django</td>
      <td>...</td>
      <td>NaN</td>
      <td>Xamarin</td>
      <td>NaN</td>
      <td>Android Studio;Notepad++;Xcode</td>
      <td>Notepad++;PyCharm</td>
      <td>Windows</td>
      <td>Google it</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Multiple times per day</td>
      <td>True</td>
      <td>A few times per week</td>
      <td>Yes, somewhat</td>
      <td>Yes</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>12.0</td>
      <td>Google it Stack Overflow;Stack Exchange</td>
    </tr>
    <tr>
      <th>62386</th>
      <td>62387</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>COLOMBIA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>18 - 24 years</td>
      <td>Coding Bootcamp;School;Online Courses or Certi...</td>
      <td>13</td>
      <td>8</td>
      <td>Developer, mobile;Developer, desktop or enterp...</td>
      <td>1,000 to 4,999 employees</td>
      <td>COP\tColombian peso</td>
      <td>5000.0</td>
      <td>Monthly</td>
      <td>Swift</td>
      <td>Swift</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>AWS</td>
      <td>AWS</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>Git</td>
      <td>Git</td>
      <td>Sublime Text;Xcode</td>
      <td>Sublime Text;Xcode</td>
      <td>MacOS</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Hispanic or Latino/a/x</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>12.0</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
    </tr>
    <tr>
      <th>69262</th>
      <td>69263</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>EGYPT</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>25 - 34 years</td>
      <td>School</td>
      <td>12</td>
      <td>4</td>
      <td>Developer, full-stack;DevOps specialist</td>
      <td>NaN</td>
      <td>EGP\tEgyptian pound</td>
      <td>20.0</td>
      <td>Monthly</td>
      <td>C#;JavaScript;SQL</td>
      <td>C#;JavaScript;SQL</td>
      <td>Microsoft SQL Server;MySQL;Oracle</td>
      <td>Microsoft SQL Server</td>
      <td>AWS;Microsoft Azure</td>
      <td>Microsoft Azure</td>
      <td>ASP.NET;ASP.NET Core ;jQuery</td>
      <td>Angular;ASP.NET;ASP.NET Core ;jQuery</td>
      <td>...</td>
      <td>.NET Framework;.NET Core / .NET 5</td>
      <td>Docker;Git</td>
      <td>Docker;Git</td>
      <td>Visual Studio;Visual Studio Code</td>
      <td>Visual Studio;Visual Studio Code</td>
      <td>Windows</td>
      <td>Google it</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>Yes, somewhat</td>
      <td>Yes</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Too long</td>
      <td>Easy</td>
      <td>12.0</td>
      <td>Google it Stack Overflow;Stack Exchange</td>
    </tr>
    <tr>
      <th>82173</th>
      <td>82174</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>INDIA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>18 - 24 years</td>
      <td>Colleague</td>
      <td>6</td>
      <td>Less than 1 year</td>
      <td>Developer, back-end</td>
      <td>20 to 99 employees</td>
      <td>INR\tIndian rupee</td>
      <td>75.0</td>
      <td>Monthly</td>
      <td>HTML/CSS;JavaScript;Ruby</td>
      <td>HTML/CSS;JavaScript;Ruby</td>
      <td>MongoDB;MySQL;PostgreSQL</td>
      <td>MongoDB;MySQL;PostgreSQL;Redis</td>
      <td>AWS;DigitalOcean;Heroku</td>
      <td>AWS;DigitalOcean;Heroku</td>
      <td>Ruby on Rails</td>
      <td>Django;React.js;Ruby on Rails</td>
      <td>...</td>
      <td>NaN</td>
      <td>Git;Yarn</td>
      <td>Docker;Git;Kubernetes;Yarn</td>
      <td>Sublime Text</td>
      <td>Sublime Text;Visual Studio Code</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>Neutral</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>South Asian</td>
      <td>None of the above</td>
      <td>I have a concentration and/or memory disorder ...</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>12.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>82198</th>
      <td>82199</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>INDIA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>18 - 24 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>16</td>
      <td>10</td>
      <td>Developer, full-stack</td>
      <td>20 to 99 employees</td>
      <td>UGX\tUgandan shilling</td>
      <td>3500.0</td>
      <td>Monthly</td>
      <td>HTML/CSS;JavaScript;Ruby;SQL</td>
      <td>Python</td>
      <td>MySQL;PostgreSQL;Redis;SQLite</td>
      <td>Elasticsearch</td>
      <td>AWS;Heroku</td>
      <td>Microsoft Azure</td>
      <td>jQuery;Ruby on Rails</td>
      <td>React.js</td>
      <td>...</td>
      <td>NaN</td>
      <td>Ansible;Docker;Git;Yarn</td>
      <td>Kubernetes</td>
      <td>Sublime Text;Visual Studio Code</td>
      <td>NaN</td>
      <td>MacOS</td>
      <td>Visit Stack Overflow;Google it</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>Yes, definitely</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Prefer not to say</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Too long</td>
      <td>Easy</td>
      <td>12.0</td>
      <td>Visit Stack Overflow;Google it Stack Overflow;...</td>
    </tr>
    <tr>
      <th>43572</th>
      <td>43573</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>IRAN, ISLAMIC REPUBLIC OF...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Secondary school (e.g. American high school, G...</td>
      <td>18 - 24 years</td>
      <td>Coding Bootcamp;Other online resources (ex: vi...</td>
      <td>3</td>
      <td>1</td>
      <td>Developer, front-end;Developer, back-end;Datab...</td>
      <td>Just me - I am a freelancer, sole proprietor, ...</td>
      <td>DJF\tDjiboutian franc</td>
      <td>3750.0</td>
      <td>Yearly</td>
      <td>HTML/CSS;JavaScript;Python;SQL</td>
      <td>C;C#;HTML/CSS;JavaScript;Python;SQL</td>
      <td>Firebase;MySQL;PostgreSQL;Redis;SQLite</td>
      <td>MariaDB;MongoDB;MySQL;PostgreSQL;Redis;SQLite</td>
      <td>DigitalOcean;Google Cloud Platform</td>
      <td>DigitalOcean;Google Cloud Platform;Heroku</td>
      <td>Django;FastAPI;jQuery</td>
      <td>ASP.NET;ASP.NET Core ;Django;FastAPI;jQuery</td>
      <td>...</td>
      <td>.NET Framework;.NET Core / .NET 5;Apache Spark...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Atom;IPython/Jupyter;Notepad++;PyCharm;Visual ...</td>
      <td>IPython/Jupyter;Visual Studio;Visual Studio Code</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Google it;Watch help / tu...</td>
      <td>Stack Overflow</td>
      <td>Multiple times per day</td>
      <td>True</td>
      <td>A few times per week</td>
      <td>No, not really</td>
      <td>Yes</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>NaN</td>
      <td>East Asian</td>
      <td>None of the above</td>
      <td>Prefer not to say</td>
      <td>Too long</td>
      <td>Easy</td>
      <td>21.0</td>
      <td>Visit Stack Overflow;Google it;Watch help / tu...</td>
    </tr>
    <tr>
      <th>17680</th>
      <td>17681</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>UNITED KINGDOM OF GREAT BRITAIN AND NORTHERN I...</td>
      <td>NaN</td>
      <td>England</td>
      <td>Some college/university study without earning ...</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc)</td>
      <td>6</td>
      <td>1</td>
      <td>Developer, full-stack;Student</td>
      <td>2 to 9 employees</td>
      <td>GBP\tPound sterling</td>
      <td>18.0</td>
      <td>Yearly</td>
      <td>Bash/Shell;C#;Java;JavaScript;Node.js;Python</td>
      <td>Bash/Shell;JavaScript;Node.js;Python;TypeScript</td>
      <td>Couchbase;Elasticsearch;IBM DB2;MongoDB</td>
      <td>Elasticsearch;MongoDB</td>
      <td>DigitalOcean;Heroku;IBM Cloud or Watson</td>
      <td>DigitalOcean;Heroku;Microsoft Azure</td>
      <td>Django;Express;Flask;Gatsby;React.js</td>
      <td>Express;Flask;Gatsby;React.js;Spring</td>
      <td>...</td>
      <td>NaN</td>
      <td>Docker;Git;Kubernetes;Unity 3D;Yarn</td>
      <td>Docker;Git;Kubernetes</td>
      <td>IntelliJ;PyCharm;Visual Studio Code</td>
      <td>PyCharm;Visual Studio Code</td>
      <td>Windows Subsystem for Linux (WSL)</td>
      <td>Visit Stack Overflow</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Multiple times per day</td>
      <td>True</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>No, not at all</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>23.0</td>
      <td>Visit Stack Overflow Stack Overflow;Stack Exch...</td>
    </tr>
  </tbody>
</table>
<p>25 rows × 49 columns</p>
</div>




```python
datos.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>RESPONSEID</th>
      <th>COMPTOTAL</th>
      <th>CONVERTEDCOMPYEARLY</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>83439.000000</td>
      <td>4.718300e+04</td>
      <td>4.684400e+04</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>41720.000000</td>
      <td>2.119407e+69</td>
      <td>1.184262e+05</td>
    </tr>
    <tr>
      <th>std</th>
      <td>24086.908893</td>
      <td>4.603702e+71</td>
      <td>5.272944e+05</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>0.000000e+00</td>
      <td>1.000000e+00</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>20860.500000</td>
      <td>1.600000e+04</td>
      <td>2.702500e+04</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>41720.000000</td>
      <td>6.700000e+04</td>
      <td>5.621100e+04</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>62579.500000</td>
      <td>1.400000e+05</td>
      <td>1.000000e+05</td>
    </tr>
    <tr>
      <th>max</th>
      <td>83439.000000</td>
      <td>1.000000e+74</td>
      <td>4.524131e+07</td>
    </tr>
  </tbody>
</table>
</div>




```python
datos["CONVERTEDCOMPYEARLY"].mean()
```




    118426.15289044488




```python
datos.median()
```

    C:\Users\rjyanez\AppData\Local\Temp/ipykernel_11460/44699025.py:1: FutureWarning: Dropping of nuisance columns in DataFrame reductions (with 'numeric_only=None') is deprecated; in a future version this will raise TypeError.  Select only valid columns before calling the reduction.
      datos.median()
    




    RESPONSEID             41720.0
    COMPTOTAL              67000.0
    SOACCOUNT                  1.0
    CONVERTEDCOMPYEARLY    56211.0
    dtype: float64




```python
datos["MAINBRANCH"].value_counts()
```




    I am a developer by profession                                                   58153
    I am a student who is learning to code                                           12029
    I am not primarily a developer, but I write code sometimes as part of my work     6578
    I code primarily as a hobby                                                       4929
    I used to be a developer by profession, but no longer am                          1237
    None of these                                                                      513
    Name: MAINBRANCH, dtype: int64




```python
# datos["NEWOTHERCOMMS"].value_counts()
# normalize=True convierte a porcentaje los valores
datos["NEWOTHERCOMMS"].value_counts(normalize=True)
```




    No     0.644275
    Yes    0.355725
    Name: NEWOTHERCOMMS, dtype: float64




```python
pais = datos.groupby(["COUNTRY"])
```


```python
pais.get_group("ESPAÑA")
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>RESPONSEID</th>
      <th>MAINBRANCH</th>
      <th>EMPLOYMENT</th>
      <th>COUNTRY</th>
      <th>USSTATE</th>
      <th>UKCOUNTRY</th>
      <th>EDLEVEL</th>
      <th>AGE1STCODE</th>
      <th>LEARNCODE</th>
      <th>YEARSCODE</th>
      <th>YEARSCODEPRO</th>
      <th>DEVTYPE</th>
      <th>ORGSIZE</th>
      <th>CURRENCY</th>
      <th>COMPTOTAL</th>
      <th>COMPFREQ</th>
      <th>LANGUAGEHAVEWORKEDWITH</th>
      <th>LANGUAGEWANTTOWORKWITH</th>
      <th>DATABASEHAVEWORKEDWITH</th>
      <th>DATABASEWANTTOWORKWITH</th>
      <th>PLATFORMHAVEWORKEDWITH</th>
      <th>PLATFORMWANTTOWORKWITH</th>
      <th>WEBFRAMEHAVEWORKEDWITH</th>
      <th>WEBFRAMEWANTTOWORKWITH</th>
      <th>...</th>
      <th>MISCTECHWANTTOWORKWITH</th>
      <th>TOOLSTECHHAVEWORKEDWITH</th>
      <th>TOOLSTECHWANTTOWORKWITH</th>
      <th>NEWCOLLABTOOLSHAVEWORKEDWITH</th>
      <th>NEWCOLLABTOOLSWANTTOWORKWITH</th>
      <th>OPSYS</th>
      <th>NEWSTUCK</th>
      <th>NEWSOSITES</th>
      <th>SOVISITFREQ</th>
      <th>SOACCOUNT</th>
      <th>SOPARTFREQ</th>
      <th>SOCOMM</th>
      <th>NEWOTHERCOMMS</th>
      <th>AGE</th>
      <th>GENDER</th>
      <th>TRANS</th>
      <th>SEXUALITY</th>
      <th>ETHNICITY</th>
      <th>ACCESSIBILITY</th>
      <th>MENTALHEALTH</th>
      <th>SURVEYLENGTH</th>
      <th>SURVEYEASE</th>
      <th>CONVERTEDCOMPYEARLY</th>
      <th>AYUDA</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>11</th>
      <td>12</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>ESPAÑA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>12</td>
      <td>5</td>
      <td>Developer, back-end</td>
      <td>10 to 19 employees</td>
      <td>EUR European Euro</td>
      <td>43000.0</td>
      <td>Yearly</td>
      <td>Bash/Shell;HTML/CSS;JavaScript;Node.js;SQL;Typ...</td>
      <td>C++;Clojure;JavaScript;Node.js;Rust;SQL;TypeSc...</td>
      <td>PostgreSQL</td>
      <td>MongoDB;PostgreSQL;Redis</td>
      <td>AWS</td>
      <td>NaN</td>
      <td>Express;React.js;Vue.js</td>
      <td>Express;Vue.js</td>
      <td>...</td>
      <td>NaN</td>
      <td>Git</td>
      <td>Git</td>
      <td>Atom</td>
      <td>Atom</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>Yes, somewhat</td>
      <td>Yes</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent;Hispanic or Latin...</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Too long</td>
      <td>Easy</td>
      <td>46482.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>68</th>
      <td>69</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>ESPAÑA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>11 - 17 years</td>
      <td>School</td>
      <td>20</td>
      <td>10</td>
      <td>Developer, back-end</td>
      <td>10,000 or more employees</td>
      <td>EUR European Euro</td>
      <td>54000.0</td>
      <td>Yearly</td>
      <td>Bash/Shell;JavaScript;Node.js;TypeScript</td>
      <td>JavaScript;Node.js;Python;TypeScript</td>
      <td>DynamoDB</td>
      <td>DynamoDB;Firebase</td>
      <td>AWS</td>
      <td>AWS;Microsoft Azure</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>Terraform</td>
      <td>Terraform</td>
      <td>Notepad++;Vim;Visual Studio Code</td>
      <td>Vim;Visual Studio Code</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>A few times per week</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>NaN</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>58373.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>79</th>
      <td>80</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>ESPAÑA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Associate degree (A.A., A.S., etc.)</td>
      <td>11 - 17 years</td>
      <td>Online Courses or Certification</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Developer, back-end</td>
      <td>100 to 499 employees</td>
      <td>EUR European Euro</td>
      <td>20000.0</td>
      <td>Yearly</td>
      <td>C#;Go;Java;Python</td>
      <td>C++;Clojure;Go;Rust</td>
      <td>Elasticsearch;Firebase;MariaDB;MySQL;PostgreSQ...</td>
      <td>PostgreSQL</td>
      <td>AWS;Google Cloud Platform;Heroku</td>
      <td>AWS;Heroku</td>
      <td>Angular;Django;FastAPI;Flask</td>
      <td>React.js</td>
      <td>...</td>
      <td>NumPy;Pandas</td>
      <td>Docker;Git;Terraform;Unity 3D</td>
      <td>Deno;Kubernetes;Yarn</td>
      <td>Android Studio;IntelliJ;NetBeans;Visual Studio...</td>
      <td>Emacs;Neovim</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>No, not at all</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Hispanic or Latino/a/x</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>21620.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>108</th>
      <td>109</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>ESPAÑA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Associate degree (A.A., A.S., etc.)</td>
      <td>25 - 34 years</td>
      <td>Coding Bootcamp;School</td>
      <td>10</td>
      <td>8</td>
      <td>Developer, full-stack;Developer, back-end;Prod...</td>
      <td>100 to 499 employees</td>
      <td>EUR European Euro</td>
      <td>36000.0</td>
      <td>Yearly</td>
      <td>HTML/CSS;Java;JavaScript;Node.js;Python;SQL</td>
      <td>HTML/CSS;Java;JavaScript;Node.js;Python;SQL;Ty...</td>
      <td>Microsoft SQL Server;MongoDB;PostgreSQL</td>
      <td>MongoDB;PostgreSQL</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>jQuery;Spring</td>
      <td>Angular;Angular.js;Express;Spring</td>
      <td>...</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>Ansible;Docker;Git</td>
      <td>Eclipse;Notepad++</td>
      <td>Eclipse;Notepad++</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
      <td>Stack Overflow</td>
      <td>Multiple times per day</td>
      <td>True</td>
      <td>A few times per week</td>
      <td>Yes, definitely</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>38915.0</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
    </tr>
    <tr>
      <th>267</th>
      <td>268</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>ESPAÑA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other (please specify):</td>
      <td>27</td>
      <td>13</td>
      <td>Developer, full-stack</td>
      <td>1,000 to 4,999 employees</td>
      <td>EUR European Euro</td>
      <td>NaN</td>
      <td>Monthly</td>
      <td>HTML/CSS;Java;JavaScript;Node.js;SQL</td>
      <td>HTML/CSS;Java;JavaScript;Node.js;Python;SQL</td>
      <td>MongoDB;Oracle</td>
      <td>MongoDB;Oracle</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Express;jQuery;Spring</td>
      <td>Express;jQuery;Spring</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Eclipse;Notepad++</td>
      <td>Eclipse;Notepad++</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Google it;Do other work a...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>A few times per month or weekly</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>NaN</td>
      <td>Visit Stack Overflow;Google it;Do other work a...</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>83097</th>
      <td>83098</td>
      <td>I am a student who is learning to code</td>
      <td>Student, part-time</td>
      <td>ESPAÑA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Secondary school (e.g. American high school, G...</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>3</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>HTML/CSS;Java;SQL</td>
      <td>C#;HTML/CSS;Java;JavaScript;Kotlin;PHP;Python;SQL</td>
      <td>MariaDB;MySQL</td>
      <td>MySQL;SQLite</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>Git</td>
      <td>Git;Unity 3D</td>
      <td>Eclipse;Notepad++</td>
      <td>Android Studio;Eclipse;Notepad++;Visual Studio...</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>Yes, somewhat</td>
      <td>Yes</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>83133</th>
      <td>83134</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>ESPAÑA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>8</td>
      <td>3</td>
      <td>Engineer, data;Data scientist or machine learn...</td>
      <td>20 to 99 employees</td>
      <td>EUR European Euro</td>
      <td>50000.0</td>
      <td>Yearly</td>
      <td>C;C++;Go;HTML/CSS;JavaScript;Node.js;Python</td>
      <td>C;C++;Go;Haskell;HTML/CSS;Python;Rust;Scala</td>
      <td>Cassandra;PostgreSQL;Redis;SQLite</td>
      <td>Cassandra;PostgreSQL;Redis;SQLite</td>
      <td>AWS;Google Cloud Platform</td>
      <td>AWS;Google Cloud Platform</td>
      <td>Flask;React.js</td>
      <td>FastAPI;Flask;React.js</td>
      <td>...</td>
      <td>Apache Spark;NumPy;Torch/PyTorch</td>
      <td>Docker;Git;Kubernetes;Terraform</td>
      <td>Docker;Git;Kubernetes;Puppet;Terraform</td>
      <td>Emacs;Vim;Visual Studio Code</td>
      <td>Emacs;Vim;Visual Studio Code</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>I have a concentration and/or memory disorder ...</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>54049.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>83137</th>
      <td>83138</td>
      <td>I am a developer by profession</td>
      <td>Not employed, but looking for work</td>
      <td>ESPAÑA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Some college/university study without earning ...</td>
      <td>5 - 10 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>30</td>
      <td>NaN</td>
      <td>Developer, mobile;Developer, front-end;Develop...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bash/Shell;F#;HTML/CSS;Java;JavaScript;Kotlin;...</td>
      <td>F#;HTML/CSS;Kotlin;TypeScript</td>
      <td>Firebase;MySQL;Redis;SQLite</td>
      <td>Firebase;MySQL;Redis;SQLite</td>
      <td>AWS</td>
      <td>NaN</td>
      <td>jQuery;Svelte;Symfony;Vue.js</td>
      <td>Svelte;Vue.js</td>
      <td>...</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>Deno;Docker;Git</td>
      <td>Android Studio;Atom;NetBeans;Notepad++;Sublime...</td>
      <td>Android Studio;Visual Studio Code</td>
      <td>Linux-based</td>
      <td>Visit Stack Overflow;Google it;Do other work a...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>A few times per week</td>
      <td>True</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>No, not really</td>
      <td>No</td>
      <td>35-44 years old</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>Prefer not to say</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>NaN</td>
      <td>Visit Stack Overflow;Google it;Do other work a...</td>
    </tr>
    <tr>
      <th>83159</th>
      <td>83160</td>
      <td>I am a developer by profession</td>
      <td>Student, full-time</td>
      <td>ESPAÑA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc)</td>
      <td>10</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Assembly;Bash/Shell;C;C#;C++;HTML/CSS;Java;Jav...</td>
      <td>Assembly;Bash/Shell;C;C#;C++;Clojure;Crystal;E...</td>
      <td>Cassandra;MariaDB;MongoDB;MySQL;SQLite</td>
      <td>Couchbase;Elasticsearch;MongoDB;MySQL;PostgreS...</td>
      <td>AWS</td>
      <td>AWS</td>
      <td>Express;Flask;React.js</td>
      <td>Angular;Express;Flask;Gatsby;jQuery;Laravel;Re...</td>
      <td>...</td>
      <td>.NET Framework;Apache Spark;Cordova;Flutter;Ke...</td>
      <td>Docker;Git;Kubernetes;Unity 3D;Unreal Engine</td>
      <td>Ansible;Docker;Git;Unity 3D;Xamarin</td>
      <td>Android Studio;Atom;Eclipse;IPython/Jupyter;Ne...</td>
      <td>Atom;IPython/Jupyter;Notepad++;Visual Studio Code</td>
      <td>Linux-based</td>
      <td>Go for a walk or other physical activity;Play ...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>A few times per month or weekly</td>
      <td>Yes, definitely</td>
      <td>Yes</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>NaN</td>
      <td>Go for a walk or other physical activity;Play ...</td>
    </tr>
    <tr>
      <th>83313</th>
      <td>83314</td>
      <td>I am a developer by profession</td>
      <td>Independent contractor, freelancer, or self-em...</td>
      <td>ESPAÑA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Professional degree (JD, MD, etc.)</td>
      <td>11 - 17 years</td>
      <td>Coding Bootcamp;Other online resources (ex: vi...</td>
      <td>10</td>
      <td>5</td>
      <td>Developer, front-end;Developer, full-stack;Dev...</td>
      <td>2 to 9 employees</td>
      <td>EUR European Euro</td>
      <td>2300.0</td>
      <td>Monthly</td>
      <td>Elixir;JavaScript;Ruby</td>
      <td>Elixir;Ruby</td>
      <td>Firebase;PostgreSQL;Redis</td>
      <td>Firebase;PostgreSQL;Redis</td>
      <td>AWS;DigitalOcean;Google Cloud Platform</td>
      <td>AWS;DigitalOcean;Google Cloud Platform</td>
      <td>jQuery;Ruby on Rails</td>
      <td>Django;Ruby on Rails;Vue.js</td>
      <td>...</td>
      <td>NaN</td>
      <td>Ansible;Docker;Git;Yarn</td>
      <td>Ansible;Docker;Git;Kubernetes;Yarn</td>
      <td>RubyMine;Visual Studio Code</td>
      <td>Visual Studio Code</td>
      <td>MacOS</td>
      <td>Visit Stack Overflow;Google it</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Multiple times per day</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Hispanic or Latino/a/x</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>29832.0</td>
      <td>Visit Stack Overflow;Google it Stack Overflow;...</td>
    </tr>
  </tbody>
</table>
<p>1485 rows × 49 columns</p>
</div>




```python
pais["MAINBRANCH"].value_counts().head(20)
```




    COUNTRY      MAINBRANCH                                                                   
    AFGHANISTAN  I am a developer by profession                                                   27
                 I am a student who is learning to code                                           15
                 None of these                                                                    11
                 I code primarily as a hobby                                                       9
                 I am not primarily a developer, but I write code sometimes as part of my work     3
    ALBANIA      I am a developer by profession                                                   52
                 I am a student who is learning to code                                           17
                 I am not primarily a developer, but I write code sometimes as part of my work     4
    ALGERIA      I am a developer by profession                                                   27
                 I am a student who is learning to code                                            8
                 I code primarily as a hobby                                                       7
                 I am not primarily a developer, but I write code sometimes as part of my work     3
                 None of these                                                                     1
    ANDORRA      I am a developer by profession                                                    6
                 I code primarily as a hobby                                                       3
                 I am a student who is learning to code                                            2
                 None of these                                                                     1
    ANGOLA       I am a developer by profession                                                   16
                 I am a student who is learning to code                                            5
                 None of these                                                                     3
    Name: MAINBRANCH, dtype: int64




```python
pais["CONVERTEDCOMPYEARLY"].median().head(20)
```




    COUNTRY
    AFGHANISTAN     9792.0
    ALBANIA        15900.0
    ALGERIA         9875.0
    ANDORRA        94045.5
    ANGOLA          9750.0
    ARGENTINA      35712.0
    ARMENIA        25080.0
    AUSTRALIA      80172.0
    AUSTRIA        54049.0
    AZERBAIJAN     18324.0
    BAHAMAS            NaN
    BAHRAIN        44688.0
    BANGLADESH      7776.0
    BARBADOS       18000.0
    BELARUS        32676.0
    BELGIUM        49170.0
    BELIZE         22625.0
    BENIN           4800.0
    BHUTAN         14718.0
    BOLIVIA        17676.0
    Name: CONVERTEDCOMPYEARLY, dtype: float64




```python
pais["CONVERTEDCOMPYEARLY"].agg(["median", "mean", "count"])
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>median</th>
      <th>mean</th>
      <th>count</th>
    </tr>
    <tr>
      <th>COUNTRY</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>AFGHANISTAN</th>
      <td>9792.0</td>
      <td>2.794748e+06</td>
      <td>11</td>
    </tr>
    <tr>
      <th>ALBANIA</th>
      <td>15900.0</td>
      <td>4.499814e+04</td>
      <td>35</td>
    </tr>
    <tr>
      <th>ALGERIA</th>
      <td>9875.0</td>
      <td>1.446114e+04</td>
      <td>14</td>
    </tr>
    <tr>
      <th>ANDORRA</th>
      <td>94045.5</td>
      <td>8.928200e+04</td>
      <td>4</td>
    </tr>
    <tr>
      <th>ANGOLA</th>
      <td>9750.0</td>
      <td>2.155680e+04</td>
      <td>10</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>VENEZUELA, BOLIVARIAN REPUBLIC OF...</th>
      <td>12000.0</td>
      <td>2.246505e+04</td>
      <td>62</td>
    </tr>
    <tr>
      <th>VIET NAM</th>
      <td>12678.0</td>
      <td>1.995289e+04</td>
      <td>148</td>
    </tr>
    <tr>
      <th>YEMEN</th>
      <td>3954.0</td>
      <td>5.628667e+03</td>
      <td>6</td>
    </tr>
    <tr>
      <th>ZAMBIA</th>
      <td>9816.0</td>
      <td>1.991491e+04</td>
      <td>11</td>
    </tr>
    <tr>
      <th>ZIMBABWE</th>
      <td>7200.0</td>
      <td>1.141477e+04</td>
      <td>13</td>
    </tr>
  </tbody>
</table>
<p>181 rows × 3 columns</p>
</div>




```python
filtro = datos['COUNTRY'] == 'ESPAÑA'
datos_españa = datos.loc[filtro]
datos_españa.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>RESPONSEID</th>
      <th>MAINBRANCH</th>
      <th>EMPLOYMENT</th>
      <th>COUNTRY</th>
      <th>USSTATE</th>
      <th>UKCOUNTRY</th>
      <th>EDLEVEL</th>
      <th>AGE1STCODE</th>
      <th>LEARNCODE</th>
      <th>YEARSCODE</th>
      <th>YEARSCODEPRO</th>
      <th>DEVTYPE</th>
      <th>ORGSIZE</th>
      <th>CURRENCY</th>
      <th>COMPTOTAL</th>
      <th>COMPFREQ</th>
      <th>LANGUAGEHAVEWORKEDWITH</th>
      <th>LANGUAGEWANTTOWORKWITH</th>
      <th>DATABASEHAVEWORKEDWITH</th>
      <th>DATABASEWANTTOWORKWITH</th>
      <th>PLATFORMHAVEWORKEDWITH</th>
      <th>PLATFORMWANTTOWORKWITH</th>
      <th>WEBFRAMEHAVEWORKEDWITH</th>
      <th>WEBFRAMEWANTTOWORKWITH</th>
      <th>...</th>
      <th>MISCTECHWANTTOWORKWITH</th>
      <th>TOOLSTECHHAVEWORKEDWITH</th>
      <th>TOOLSTECHWANTTOWORKWITH</th>
      <th>NEWCOLLABTOOLSHAVEWORKEDWITH</th>
      <th>NEWCOLLABTOOLSWANTTOWORKWITH</th>
      <th>OPSYS</th>
      <th>NEWSTUCK</th>
      <th>NEWSOSITES</th>
      <th>SOVISITFREQ</th>
      <th>SOACCOUNT</th>
      <th>SOPARTFREQ</th>
      <th>SOCOMM</th>
      <th>NEWOTHERCOMMS</th>
      <th>AGE</th>
      <th>GENDER</th>
      <th>TRANS</th>
      <th>SEXUALITY</th>
      <th>ETHNICITY</th>
      <th>ACCESSIBILITY</th>
      <th>MENTALHEALTH</th>
      <th>SURVEYLENGTH</th>
      <th>SURVEYEASE</th>
      <th>CONVERTEDCOMPYEARLY</th>
      <th>AYUDA</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>11</th>
      <td>12</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>ESPAÑA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other online resources (ex: videos, blogs, etc...</td>
      <td>12</td>
      <td>5</td>
      <td>Developer, back-end</td>
      <td>10 to 19 employees</td>
      <td>EUR European Euro</td>
      <td>43000.0</td>
      <td>Yearly</td>
      <td>Bash/Shell;HTML/CSS;JavaScript;Node.js;SQL;Typ...</td>
      <td>C++;Clojure;JavaScript;Node.js;Rust;SQL;TypeSc...</td>
      <td>PostgreSQL</td>
      <td>MongoDB;PostgreSQL;Redis</td>
      <td>AWS</td>
      <td>NaN</td>
      <td>Express;React.js;Vue.js</td>
      <td>Express;Vue.js</td>
      <td>...</td>
      <td>NaN</td>
      <td>Git</td>
      <td>Git</td>
      <td>Atom</td>
      <td>Atom</td>
      <td>Linux-based</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>Less than once per month or monthly</td>
      <td>Yes, somewhat</td>
      <td>Yes</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent;Hispanic or Latin...</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Too long</td>
      <td>Easy</td>
      <td>46482.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>68</th>
      <td>69</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>ESPAÑA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Master’s degree (M.A., M.S., M.Eng., MBA, etc.)</td>
      <td>11 - 17 years</td>
      <td>School</td>
      <td>20</td>
      <td>10</td>
      <td>Developer, back-end</td>
      <td>10,000 or more employees</td>
      <td>EUR European Euro</td>
      <td>54000.0</td>
      <td>Yearly</td>
      <td>Bash/Shell;JavaScript;Node.js;TypeScript</td>
      <td>JavaScript;Node.js;Python;TypeScript</td>
      <td>DynamoDB</td>
      <td>DynamoDB;Firebase</td>
      <td>AWS</td>
      <td>AWS;Microsoft Azure</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>Terraform</td>
      <td>Terraform</td>
      <td>Notepad++;Vim;Visual Studio Code</td>
      <td>Vim;Visual Studio Code</td>
      <td>Windows</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>A few times per week</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>NaN</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>58373.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>79</th>
      <td>80</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>ESPAÑA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Associate degree (A.A., A.S., etc.)</td>
      <td>11 - 17 years</td>
      <td>Online Courses or Certification</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Developer, back-end</td>
      <td>100 to 499 employees</td>
      <td>EUR European Euro</td>
      <td>20000.0</td>
      <td>Yearly</td>
      <td>C#;Go;Java;Python</td>
      <td>C++;Clojure;Go;Rust</td>
      <td>Elasticsearch;Firebase;MariaDB;MySQL;PostgreSQ...</td>
      <td>PostgreSQL</td>
      <td>AWS;Google Cloud Platform;Heroku</td>
      <td>AWS;Heroku</td>
      <td>Angular;Django;FastAPI;Flask</td>
      <td>React.js</td>
      <td>...</td>
      <td>NumPy;Pandas</td>
      <td>Docker;Git;Terraform;Unity 3D</td>
      <td>Deno;Kubernetes;Yarn</td>
      <td>Android Studio;IntelliJ;NetBeans;Visual Studio...</td>
      <td>Emacs;Neovim</td>
      <td>MacOS</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>I have never participated in Q&amp;A on Stack Over...</td>
      <td>No, not at all</td>
      <td>No</td>
      <td>18-24 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>Hispanic or Latino/a/x</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Appropriate in length</td>
      <td>Easy</td>
      <td>21620.0</td>
      <td>Call a coworker or friend;Visit Stack Overflow...</td>
    </tr>
    <tr>
      <th>108</th>
      <td>109</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>ESPAÑA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Associate degree (A.A., A.S., etc.)</td>
      <td>25 - 34 years</td>
      <td>Coding Bootcamp;School</td>
      <td>10</td>
      <td>8</td>
      <td>Developer, full-stack;Developer, back-end;Prod...</td>
      <td>100 to 499 employees</td>
      <td>EUR European Euro</td>
      <td>36000.0</td>
      <td>Yearly</td>
      <td>HTML/CSS;Java;JavaScript;Node.js;Python;SQL</td>
      <td>HTML/CSS;Java;JavaScript;Node.js;Python;SQL;Ty...</td>
      <td>Microsoft SQL Server;MongoDB;PostgreSQL</td>
      <td>MongoDB;PostgreSQL</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>jQuery;Spring</td>
      <td>Angular;Angular.js;Express;Spring</td>
      <td>...</td>
      <td>NaN</td>
      <td>Docker;Git</td>
      <td>Ansible;Docker;Git</td>
      <td>Eclipse;Notepad++</td>
      <td>Eclipse;Notepad++</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
      <td>Stack Overflow</td>
      <td>Multiple times per day</td>
      <td>True</td>
      <td>A few times per week</td>
      <td>Yes, definitely</td>
      <td>No</td>
      <td>25-34 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>38915.0</td>
      <td>Visit Stack Overflow;Go for a walk or other ph...</td>
    </tr>
    <tr>
      <th>267</th>
      <td>268</td>
      <td>I am a developer by profession</td>
      <td>Employed full-time</td>
      <td>ESPAÑA</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Bachelor’s degree (B.A., B.S., B.Eng., etc.)</td>
      <td>11 - 17 years</td>
      <td>Other (please specify):</td>
      <td>27</td>
      <td>13</td>
      <td>Developer, full-stack</td>
      <td>1,000 to 4,999 employees</td>
      <td>EUR European Euro</td>
      <td>NaN</td>
      <td>Monthly</td>
      <td>HTML/CSS;Java;JavaScript;Node.js;SQL</td>
      <td>HTML/CSS;Java;JavaScript;Node.js;Python;SQL</td>
      <td>MongoDB;Oracle</td>
      <td>MongoDB;Oracle</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Express;jQuery;Spring</td>
      <td>Express;jQuery;Spring</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Eclipse;Notepad++</td>
      <td>Eclipse;Notepad++</td>
      <td>Windows</td>
      <td>Visit Stack Overflow;Google it;Do other work a...</td>
      <td>Stack Overflow;Stack Exchange</td>
      <td>Daily or almost daily</td>
      <td>True</td>
      <td>A few times per month or weekly</td>
      <td>Yes, somewhat</td>
      <td>No</td>
      <td>35-44 years old</td>
      <td>Man</td>
      <td>No</td>
      <td>Straight / Heterosexual</td>
      <td>White or of European descent</td>
      <td>None of the above</td>
      <td>None of the above</td>
      <td>Appropriate in length</td>
      <td>Neither easy nor difficult</td>
      <td>NaN</td>
      <td>Visit Stack Overflow;Google it;Do other work a...</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 49 columns</p>
</div>




```python
# exportar a .csv
datos_españa.to_csv('datos_españa.csv')
```


```python
pip install openpyxl
```

    Requirement already satisfied: openpyxl in d:\curso_python\codigo\cursopython2021\lib\site-packages (3.0.9)Note: you may need to restart the kernel to use updated packages.
    
    Requirement already satisfied: et-xmlfile in d:\curso_python\codigo\cursopython2021\lib\site-packages (from openpyxl) (1.1.0)
    


```python
datos_españa.to_excel('datos_españa.xlsx')
```


```python

```
